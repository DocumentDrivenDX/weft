from pathlib import Path
import os,json,hashlib,subprocess,time
R=Path(__file__).resolve().parent;root=R/'reconstructed';out=R/'replays';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={str(p.relative_to(root)):sha(p)for p in sorted(root.rglob('*'))if p.is_file()}
(R/'source-before.json').write_text(json.dumps(sources,indent=2)+'\n')
commands=[];python='/private/tmp/truss-practical-performance-env/bin/python'
for mode in ['combined','candidate','legacy','runtime-only']:
 commands.append((mode,[python,str(root/'tests/current-query-presence/python-bridge.py'),str(R/'wheels'/mode/'installed'),mode,str(out/(mode+'.json'))],{}))
env={**os.environ,'PATH':'/Users/erik/.rustup/toolchains/1.90.0-aarch64-apple-darwin/bin:'+os.environ['PATH'],'CARGO_HOME':'/private/tmp/weft-toolchain/cargo','CARGO_TARGET_DIR':str(R/'target')}
for label,args in [('runtime',['--lib']),('runtime-doc',['--doc'])]:commands.append((label,['cargo','test','--offline','--locked','-p','weft-runtime','--features','current-presence-candidate']+args,env))
executions=[]
for label,args,extra in commands:
 start=time.monotonic();p=subprocess.run(args,cwd=root,env=extra or None,text=True,capture_output=True,timeout=600);wall=time.monotonic()-start
 (out/(label+'.stdout')).write_text(p.stdout);(out/(label+'.stderr')).write_text(p.stderr)
 executions.append({'id':label,'command':args,'cwd':str(root),'exitCode':p.returncode,'elapsedSeconds':wall,'stdoutSha256':sha(out/(label+'.stdout')),'stderrSha256':sha(out/(label+'.stderr'))})
 (out/'executions.json').write_text(json.dumps(executions,indent=2)+'\n');print(json.dumps(executions[-1]),flush=True)
 if p.returncode:break
changed=[n for n,h in sources.items()if not(root/n).is_file()or sha(root/n)!=h]
(R/'source-after.json').write_text(json.dumps({'changed':changed,'sourceCount':len(sources),'pins':{n:sha(root/n)for n in sources if(root/n).is_file()}},indent=2)+'\n')
assert not changed,changed
