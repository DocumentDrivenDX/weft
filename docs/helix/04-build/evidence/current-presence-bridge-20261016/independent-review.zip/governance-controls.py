from pathlib import Path
import shutil,json,hashlib,subprocess,os,time
R=Path(__file__).resolve().parent;root=R/'reconstructed';owner=Path('/private/tmp/weft-presence-bridge-owner-20261016');d=root/'node_modules';d.mkdir(exist_ok=True)
for name in ['ajv','yaml','fast-deep-equal','fast-uri','json-schema-traverse','require-from-string']:
 shutil.copytree(owner/'node_modules'/name,d/name,dirs_exist_ok=True)
pins={str(p.relative_to(d)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(d.rglob('*'))if p.is_file()};(R/'governance-runtime-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
env={**os.environ,'WEFT_CARGO':'/Users/erik/.rustup/toolchains/1.90.0-aarch64-apple-darwin/bin/cargo','PATH':'/Users/erik/.rustup/toolchains/1.90.0-aarch64-apple-darwin/bin:'+os.environ['PATH'],'CARGO_HOME':'/private/tmp/weft-toolchain/cargo','CARGO_TARGET_DIR':str(R/'target')};records=[]
for name,cmd in [('specs',['/opt/homebrew/bin/bun','scripts/check-specs.ts']),('cargo-boundaries',['python3','scripts/checks/check-module-boundaries.py']),('module-boundaries',['/opt/homebrew/bin/bun','scripts/module-boundaries.ts']),('boundary-tests',['/opt/homebrew/bin/bun','test','scripts/module-boundaries.test.ts'])]:
 t=time.monotonic();p=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True,timeout=120);(R/'replays'/(name+'.stdout')).write_text(p.stdout);(R/'replays'/(name+'.stderr')).write_text(p.stderr);records.append({'id':name,'command':cmd,'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-t});print(json.dumps(records[-1]),flush=True)
(R/'governance-controls.json').write_text(json.dumps({'status':'passed'if all(x['exitCode']==0 for x in records)else'failed','executions':records,'runtimePackageVersions':{n:json.loads((d/n/'package.json').read_text())['version']for n in ['ajv','yaml']}},indent=2)+'\n')
raise SystemExit(0 if all(x['exitCode']==0 for x in records)else 1)
