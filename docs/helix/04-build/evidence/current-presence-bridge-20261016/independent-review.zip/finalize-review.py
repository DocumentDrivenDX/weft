from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def pin(n):
 p=R/n;return {'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
manifest=json.loads((R/'frozen/manifest.json').read_text());custody=json.loads((R/'custody-audit.json').read_text());rust=json.loads((R/'rust-controls.json').read_text());governance=json.loads((R/'governance-controls.json').read_text());assert custody['status']==rust['status']==governance['status']=='passed'
for n in ['combined','all-features']:assert json.loads((R/('independent-python-'+n+'.json')).read_text())['status']=='passed'
wheelbuild=json.loads((R/'independent-wheel-build.json').read_text())
review={
 'status':'completed',
 'verdict':'No actionable finding in the exact optional runtime/Python presence bridge component.',
 'reviewer':'Retained user-requested independent Astra Ultra reviewer /root/astra_retirement_review',
 'date':'2026-10-16',
 'scope':'Separate optional issued CurrentPresencePreparation runtime/Python bridge over the previously reviewed Core/PG presence component. Source, native C-extension type/lifetime/refusal/feature boundaries and exact data correspondence only.',
 'nativeDatabaseExecutedByReviewer':False,
 'findings':[],
 'remainingFindings':[],
 'frozenInputs':{
  'reviewPacket':pin('frozen/review.zip'),
  'manifest':pin('frozen/manifest.json'),
  'baseCommit':manifest['baseCommit'],
  'baseRepository':'/Users/erik/Projects/weft',
  'changedFiles':manifest['sourceFiles'],
  'reconstruction':pin('reconstruction.json'),
  'sourceDiff':pin('source.diff'),
  'compilerTestSourceArchive':pin('reviewed-source-inputs.zip'),
  'governanceSourceArchive':pin('governance-source-inputs.zip'),
  'externalGovernanceJsRuntimeArchive':pin('external-js-runtime.zip'),
  'suppliedWheels':manifest['wheels'],
  'laterCandidateOnlyFinalReceipt':pin('frozen/candidate-later-final-receipt.json'),
 },
 'sourceAssessment':[
  'The exact base-relative change consists of eight declared files. Runtime/Python production code is additive: an explicit feature, actual-parent factory and distinct new type. Existing scalar method implementations, public backend registrations, default Python feature configuration and WASM source are unchanged.',
  'Runtime issuance calls the actual Core presence factory on the retained ApplicationLineage object and retains Arc ownership of that same original. is_from uses Arc::ptr_eq, so equal source bytes do not substitute another original. Private fields, no serde/clone constructor and a private scoped consumer prevent importing success data or exporting the borrowed Core context.',
  'Each runtime native-request/lower/check operation re-derives the Core presence context from the retained immutable original and compares the exact issued preparation JSON before dispatch. This does not accept a replacement SQL/AST/context/report. The inherited Core preparation reads its own retained original source data; no claim is made that it performs zero internal JSON parsing.',
  'The native Python class retains the actual Python parent plus the runtime child. Every new method checks their pointer custody. source_preparation returns that actual parent. Frozen non-subclassable native instances have no constructor, mutable instance fields, instance dictionary, copy/pickle reconstruction or class substitution.',
  'Binding/frame entrypoints require exact native builtin PyString objects before length/extraction. No user __str__, __len__ or spoofed __class__ callback runs. Conversion rejects surrogate-containing Python strings; raw UTF8 byte bounds are 4,000,000 and 16,000,000. Exact-size valid inputs pass and size-plus-one inputs refuse.',
  'Old/new raw method descriptors reject the wrong actual class. Old designation/factory paths still refuse .4. Legacy wheels expose neither the new class nor factory. Enabling the runtime feature alone does not expose the Python class/factory.',
  'The bridge exposes compiler/data reports only, with authority:false, securityReady:false and nativeAdmission:required. The invalid selected-occurrence control intentionally still matches structural transport, demonstrating that whole UMF semantic/source/current-cut validation remains a separate required host barrier.',
  'Errors remain scoped fixed messages without supplied private sentinel values or partial success. The contract correctly distinguishes lowering failure from later checking failure: a later refusal cannot erase previously issued SQL; the host must release nothing and clean up its owned stage.'
 ],
 'independentExecution':{
  'runtimeSourceBuild':{'libraryTests':7,'compileFailDoctests':4,'status':'passed','records':pin('replays/executions.json'),'qualification':'Executed from the exact reconstructed frozen sources, with the optional presence feature. Four compile-fail examples are distinct from the additional explicit diagnostics controls.'},
  'suppliedWheelCorpusReplays':[
   {'wheel':'combined','checks':415,'status':'passed','receipt':pin('replays/combined.json')},
   {'wheel':'candidate','checks':410,'status':'passed','receipt':pin('replays/candidate.json')},
   {'wheel':'legacy','checks':7,'status':'passed','receipt':pin('replays/legacy.json')},
   {'wheel':'runtime-only','checks':12,'status':'passed','receipt':pin('replays/runtime-only.json')}
  ],
  'independentSourceBuiltWheel':{
   'build':pin('independent-wheel-build.json'),'wheel':wheelbuild['wheel'],'members':wheelbuild['members'],
   'features':'Explicit pyproject baseline plus current-presence-candidate, bounded-current-string-candidate and current-spark-scalar-candidate.',
   'corpusChecks':415,'corpusReceipt':pin('replays/independent-wheel-corpus.json'),
   'qualification':'Separate locally built dev abi3 macOS ARM wheel, not a replacement/relabeling of any supplied wheel and not a publication artifact. No source edits were needed.'
  },
  'adversarialPython':[
   {'wheel':'supplied combined','checks':298,'oldLowerCheckDescriptors':11,'status':'passed','receipt':pin('independent-python-combined.json')},
   {'wheel':'independently source-built expanded-feature wheel','checks':314,'oldLowerCheckDescriptors':19,'status':'passed','receipt':pin('independent-python-all-features.json')}
  ],
  'adversarialCoverage':[
   'Exact actual parent identity, equal-byte distinct parents, parent lifetime after dropping caller handle, retained original source bytes including whitespace, stale original binding refusal and correct newly pinned binding success.',
   'No report/native-input/artifact/check-report import as a lineage or presence object; direct native descriptors reject fake __class__, mappings, parent objects and old current-query objects.',
   'All enabled old lower/check descriptors refuse the new type before backend handling: 11 on the supplied combined wheel and 19 on the separately built expanded-feature wheel.',
   'No arbitrary-object or str-subclass coercion/callbacks across lower binding, checker binding and checker frame channels; bytes, bytearray, memoryview and mappings refuse.',
   'Constructor, subclassing, instance state/class mutation, copy/deepcopy and every supported pickle protocol refuse.',
   'Lone high/low/mixed/paired-surrogate-codepoint strings refuse; ASCII/BMP/supplementary UTF8 over-bounds refuse. Valid 4,000,000-byte binding and 16,000,000-byte frame succeed with exact raw-body SHA pins; plus-one boundaries refuse.',
   'Duplicate/unknown JSON fields, NUL/nonfinite/deep bodies, old versions, stale pins, noncanonical counts, missing rows and SQL-null collapse refuse with private diagnostics suppressed.',
   'Structurally matching selected occurrence 999/999 retains false authority and requires whole UMF validation; no authority is inferred from possessing the class or receiving a matched report.'
  ],
  'explicitRustBoundaries':{'controls':8,'status':'passed','report':pin('rust-controls.json'),'diagnostics':{'deserialize':'E0277','serialize':'E0277','clone':'E0308','private-callback':'E0624','old-receiver':'E0308','private-ownership':'E0616','feature-off-type':'E0432','lineage-only-factory':'E0599'},'qualification':'Each negative was checked for its intended Rust diagnostic, not merely a failed cargo exit.'},
  'governance':{'status':'passed','artifacts':73,'schemas':96,'workspacePackages':11,'boundaryUnitTests':16,'report':pin('governance-controls.json'),'qualification':'Specification/boundary checks do not execute a database or close planned requirements.'}
 },
 'custody':{
  'checks':6525,'status':'passed','report':pin('custody-audit.json'),
  'originalReconstructedFiles':4412,'selectedSourceFiles':1306,
  'governanceSourceFiles':len(json.loads((R/'governance-source-pins.json').read_text())),
  'finalSourceEndpoints':pin('final-source-endpoints.json'),
  'findings':'All original reconstructed file hashes remain unchanged. Selected current owner source endpoints match the exact reconstructed base+overlay. All four supplied wheel/native/shim pins match their frozen manifest, and the independent wheel has its own build/member pins.',
  'fixtureCustody':'The actual 66-packet corpus and 41 emitted rendered artifacts retain their previously independently reviewed hashes. The 25 refused packets remain data/refusal evidence; the bridge does not relabel them as successful compiled operations.',
  'sourceSnapshotQualification':'Endpoint equality is not held-file/ABA proof. Captured source/fixture/governance bytes and Cargo.lock identify the reviewed build inputs; external compiler/Python/OS dependency closure is not hermetic.',
  'runtime':pin('runtime.json'),
  'retention':'The final manifest covers the compact retained evidence set. Reconstructed checkout, Cargo target cache, redundant full Git base tar and extracted wheel installations are scratch copies excluded from that manifest; exact source/governance/runtime archives and wheel ZIPs with restoration mappings are included.'
 },
 'historicalEvidence':{
  'frozenR1Unmodified':True,
  'candidate396':'The frozen R1 packet retains the earlier candidate-only 396-check receipt as an earlier harness cohort. The separately supplied later 410-check receipt and this review’s fresh 410 replay are retained separately; the original archive/manifest is unchanged.',
  'ownerInitialRuntimeFailure':'The supplied first runtime log records the initial wrong outer version test setup; current frozen source uses interfaceVersion and passes. This historical failure log is retained and not counted as current successful evidence or independently reproduced.',
  'reviewerSetupAttempts':[
   {'path':'reconstruction.json','qualification':'Initial git archive attempt targeted the owner source export without .git and failed before reconstruction. Retried against the authoritative /Users/erik/Projects/weft Git object; no owner source edits.'},
   {'path':'reviewer-attempts/first-independent-python-combined.json','qualification':'Initial reviewer harness incorrectly expected 19 old Python descriptors in the supplied combined wheel. All actual 11 already refused correctly. Corrected scope; separately rebuilt an expanded-feature wheel to exercise all 19.'},
   {'path':'reviewer-attempts/rust-first/','qualification':'Initial external Rust control crate omitted the baseline workspace ahash path patch and failed offline resolution before the intended type controls. No such failures counted as passing. Corrected only the external probe setup and checked eight intended diagnostics.'},
   {'path':'reviewer-attempts/governance-first/','qualification':'Initial reviewer environment omitted required WEFT_CARGO for the module-boundary script. Corrected the environment and reran; source unchanged. Initial logs and scripts retained.'}
  ],
  'productFindingFromTheseAttempts':False
 },
 'scopeLimits':[
  'No SQL, Docker or native database campaign was executed for this bridge review. The prior native supplied-campaign audit remains a separate immutable report; it does not automatically qualify these Python wheel binaries for native execution.',
  'These are local development ABI3 macOS ARM artifacts tested with the recorded Python 3.11.17 runtime and Rust toolchain. No Windows/Linux/x86/Python-version matrix, public release, default-feature enablement or WASM bridge is qualified.',
  'The held context and exact source hashes do not authenticate the source, caller, Subject, native role/mapping or current cut. Read-purpose metadata is not a grant; fixture bindings remain explicitly unadmitted.',
  'The bridge does not invoke the UMF producer, perform whole V2 semantic validation, authenticate complete native population or enforce closing current-authority checks/guarded release. Those host obligations remain mandatory, including empty results.',
  'Input/output bounds and observed local boundary timings are component checks, not process-memory limits, hard deadlines, cancellation guarantees or an unbounded proof. Hosts retain their execution, resource, cleanup and release obligations.',
  'No original Weft132 or UMF158 security requirement is promoted. The 34 UMF criteria and existing 45-implemented/113-missing status are unchanged; the full security acceptance gate was not rerun in this review.',
  'Counts include repeated fixture/control assertions on multiple wheel configurations; they are not additional unique acceptance requirements or formal proofs.'
 ],
 'disposition':'No correction is required for this exact bridge component before its owner’s scoped integration. Any subsequent source/ABI/platform/native admission change needs its own qualified evidence.'
}
(R/'review.json').write_text(json.dumps(review,indent=2)+'\n')
restoration={'sourceArchive':'reviewed-source-inputs.zip','sourceDestination':'reconstructed/','governanceArchive':'governance-source-inputs.zip','governanceDestination':'reconstructed/','externalJsRuntimeArchive':'external-js-runtime.zip','externalJsRuntimeDestination':'reconstructed/node_modules/','wheels':{n:{'archive':str(Path(v['path']).name),'directory':'wheels/'+n,'extractDestination':'wheels/'+n+'/installed'}for n,v in manifest['wheels'].items()},'independentWheel':{'archive':Path(wheelbuild['wheel']['path']).name,'directory':'wheels/all-features','extractDestination':'wheels/all-features/installed'},'qualification':'Archives preserve source bytes and exact tested wheels. External Rust/toolchain/OS runtime remains separately required and not hermetic. Full original Git base is named by immutable commit in reconstruction.json; unrelated historical evidence/distributions are not required to replay this component.'}
(R/'restoration.json').write_text(json.dumps(restoration,indent=2)+'\n')
(R/'README.md').write_text('Independent bridge R1 review — 2026-10-16\n\nVerdict: no actionable finding within the optional runtime/Python component. No database execution or acceptance promotion.\n\nExact Git base plus eight overlays was reconstructed. Source build passes seven runtime tests and four compile-fail examples. Supplied wheels independently replay 415/410/7/12 controls. An additional independently source-built wheel with baseline, presence, bounded and Spark features passes 415 fixture controls and 314 adversarial checks; the supplied combined wheel passes 298 independent checks. Eight Rust negatives fail for their intended diagnostics. Specs/boundaries pass.\n\nreview.json provides pins, qualifications and retained reviewer setup failures. manifest.json covers the compact evidence set; it intentionally excludes build/reconstruction scratch. restoration.json maps the captured source/governance/runtime/wheel archives back to replay locations.\n')
files={}
for p in sorted(R.rglob('*')):
 if not p.is_file()or p==R/'manifest.json':continue
 rel=p.relative_to(R);parts=rel.parts
 if parts[0]in ['target','reconstructed']or str(rel)=='frozen/base.tar'or ('installed'in parts and parts[0]=='wheels')or '__pycache__'in parts:continue
 files[str(rel)]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
m={'version':'independent-review-evidence-manifest/1','root':str(R),'files':files,'fileCount':len(files),'exclusions':['target/**','reconstructed/**','frozen/base.tar','wheels/*/installed/**','**/__pycache__/**','manifest.json'],'qualification':'Compact exact retained evidence. Source/governance/external-JS-runtime archives and all five tested wheel ZIPs are included; excluded paths are redundant reconstruction/build scratch, not additional qualified evidence.'}
(R/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'review':pin('review.json'),'manifest':pin('manifest.json'),'fileCount':len(files),'findings':[]},indent=2))
