use weft_runtime::CurrentPresencePreparation;pub fn f(_:CurrentPresencePreparation){}
