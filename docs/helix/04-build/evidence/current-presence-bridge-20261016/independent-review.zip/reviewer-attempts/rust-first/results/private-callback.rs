use weft_runtime::CurrentPresencePreparation; pub fn f(p:&CurrentPresencePreparation){let _=p.with_context(|_|Ok(()));}
