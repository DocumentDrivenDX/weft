from pathlib import Path
import os,json,subprocess,time,hashlib
R=Path(__file__).resolve().parent;project=R/'rust-controls';(project/'src').mkdir(parents=True,exist_ok=True);out=R/'rust-control-results';out.mkdir(exist_ok=True)
(project/'Cargo.toml').write_text('[package]\nname="presence-bridge-independent-controls"\nversion="0.0.0"\nedition="2024"\n[workspace]\n[dependencies]\nweft-runtime={path="'+str(R/'reconstructed/crates/weft-runtime')+'",default-features=false}\nserde_json="1"\n[features]\nenabled=["weft-runtime/current-presence-candidate","weft-runtime/bounded-current-string-candidate","weft-runtime/current-spark-scalar-candidate"]\nlineage=["weft-runtime/application-lineage-candidate"]\n')
cases=[
 ('deserialize','enabled','E0277','use weft_runtime::CurrentPresencePreparation; pub fn f(s:&str)->CurrentPresencePreparation{serde_json::from_str(s).unwrap()}'),
 ('serialize','enabled','E0277','use weft_runtime::CurrentPresencePreparation; pub fn f(p:&CurrentPresencePreparation)->String{serde_json::to_string(p).unwrap()}'),
 ('clone','enabled','E0308','use weft_runtime::CurrentPresencePreparation; pub fn f(p:&CurrentPresencePreparation)->CurrentPresencePreparation{p.clone()}'),
 ('private-callback','enabled','E0624','use weft_runtime::CurrentPresencePreparation; pub fn f(p:&CurrentPresencePreparation){let _=p.with_context(|_|Ok(()));}'),
 ('old-receiver','enabled','E0308','use weft_runtime::{CurrentPresencePreparation,CurrentQueryPreparation};pub fn f(p:&CurrentPresencePreparation){let _=CurrentQueryPreparation::lower_postgresql_current_rows_candidate_json(p,"{}");}'),
 ('private-ownership','enabled','E0616','use weft_runtime::{CurrentPresencePreparation,ApplicationLineagePreparation};pub fn f(p:&ApplicationLineagePreparation)->CurrentPresencePreparation{CurrentPresencePreparation{original:p.inner.clone(),preparation_json:"{}".into()}}'),
 ('feature-off-type','','E0432','use weft_runtime::CurrentPresencePreparation;pub fn f(_:CurrentPresencePreparation){}'),
 ('lineage-only-factory','lineage','E0599','use weft_runtime::ApplicationLineagePreparation;pub fn f(p:&ApplicationLineagePreparation){let _=p.prepare_current_presence();}')]
env={**os.environ,'PATH':'/Users/erik/.rustup/toolchains/1.90.0-aarch64-apple-darwin/bin:'+os.environ['PATH'],'CARGO_HOME':'/private/tmp/weft-toolchain/cargo','CARGO_TARGET_DIR':str(R/'target')};results=[]
for name,feature,code,source in cases:
 (project/'src/lib.rs').write_text(source+'\n');(out/(name+'.rs')).write_text(source+'\n')
 cmd=['cargo','check','--offline','--manifest-path',str(project/'Cargo.toml'),'--message-format=json']+(['--features',feature]if feature else[])
 t=time.monotonic();p=subprocess.run(cmd,cwd=project,env=env,text=True,capture_output=True,timeout=300);codes=[]
 for line in p.stdout.splitlines():
  try:x=json.loads(line)
  except:continue
  if x.get('reason')=='compiler-message'and x['message'].get('code'):codes.append(x['message']['code']['code'])
 (out/(name+'.stdout')).write_text(p.stdout);(out/(name+'.stderr')).write_text(p.stderr)
 results.append({'id':name,'command':cmd,'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-t,'expectedDiagnostic':code,'actualDiagnostics':codes,'passed':p.returncode!=0 and code in codes})
 (R/'rust-controls.json').write_text(json.dumps({'status':'passed'if all(x['passed']for x in results)else'failed','count':len(results),'controls':results,'scope':'Compile-time public runtime type/ownership/feature boundaries; no native database'},indent=2)+'\n');print(json.dumps(results[-1]),flush=True)
