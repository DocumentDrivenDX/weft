use weft_runtime::ApplicationLineagePreparation;pub fn f(p:&ApplicationLineagePreparation){let _=p.prepare_current_presence();}
