use weft_runtime::CurrentPresencePreparation; pub fn f(p:&CurrentPresencePreparation)->String{serde_json::to_string(p).unwrap()}
