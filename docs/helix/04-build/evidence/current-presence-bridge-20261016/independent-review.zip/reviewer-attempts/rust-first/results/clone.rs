use weft_runtime::CurrentPresencePreparation; pub fn f(p:&CurrentPresencePreparation)->CurrentPresencePreparation{p.clone()}
