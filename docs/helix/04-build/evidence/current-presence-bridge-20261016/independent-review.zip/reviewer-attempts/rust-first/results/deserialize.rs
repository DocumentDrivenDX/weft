use weft_runtime::CurrentPresencePreparation; pub fn f(s:&str)->CurrentPresencePreparation{serde_json::from_str(s).unwrap()}
