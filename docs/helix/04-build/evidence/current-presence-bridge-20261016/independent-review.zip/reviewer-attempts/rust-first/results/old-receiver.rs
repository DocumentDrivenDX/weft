use weft_runtime::{CurrentPresencePreparation,CurrentQueryPreparation};pub fn f(p:&CurrentPresencePreparation){let _=CurrentQueryPreparation::lower_postgresql_current_rows_candidate_json(p,"{}");}
