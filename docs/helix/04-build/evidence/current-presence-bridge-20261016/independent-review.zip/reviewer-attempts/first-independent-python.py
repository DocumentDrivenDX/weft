import sys,json,hashlib,time,copy,pickle,gc,types,weakref,inspect
from pathlib import Path
R=Path(__file__).resolve().parent;mode=sys.argv[1];sys.path.insert(0,str(R/'wheels'/mode/'installed'));import weft
root=R/'reconstructed';cases={c['id']:c['request']for c in json.loads((root/'tests/current-query-presence/fixtures/actual-atomic-transport.json').read_text())['cases']};emitted={c['id']:c for c in json.loads((root/'tests/current-query-presence/fixtures/actual-atomic-transport-emitted.json').read_text())}
def enc(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def sha(s):return hashlib.sha256(s.encode()).hexdigest()
checks=[];errors=[];calls=[]
def ck(n,a,e=True):checks.append({'id':n,'passed':type(a)==type(e)and a==e,'actual':a,'expected':e})
def reject(n,f,prefix=None):
 start=time.monotonic()
 try:f()
 except (TypeError,ValueError,AttributeError)as e:
  msg=str(e);ck(n+':refused',True);ck(n+':no-private-diagnostic','review-private-sentinel'not in msg)
  if prefix:ck(n+':scoped-message',msg.startswith(prefix))
  errors.append({'id':n,'type':type(e).__name__,'message':msg,'elapsedSeconds':time.monotonic()-start});return msg
 ck(n+':refused',False);return ''
first=emitted['allowed:string'];request=enc(cases['allowed:string']);parent=weft.prepare_application_lineage(request);child=parent.prepare_current_presence();binding=enc(first['binding']);frame=enc(first['frame']);T=weft.CurrentPresencePreparation
ck('class-is-native-extension',type(child).__module__,'weft');ck('method-is-native-descriptor',inspect.ismethoddescriptor(T.lower_postgresql_current_presence_candidate_json));ck('parent-object-exact',child.source_preparation()is parent)
other=weft.prepare_application_lineage(request);otherchild=other.prepare_current_presence();ck('equal-bytes-distinct-parent',other is not parent);ck('equal-bytes-child-owned-other',otherchild.source_preparation()is other);ck('equal-bytes-no-parent-substitution',child.source_preparation()is not other)
# Exact retained bytes, including whitespace; stale original binding cannot cross contexts.
spaced=' \n'+request+'\n ';sp=weft.prepare_application_lineage(spaced);sc=sp.prepare_current_presence();ck('spaced-native-original',json.loads(sc.native_request_json())['sourceRequestJson'],spaced)
reject('spaced-stale-binding',lambda:sc.lower_postgresql_current_presence_candidate_json(binding),'WFT-CURRENT-PRESENCE-SQL:')
sb=copy.deepcopy(first['binding']);sb['sourceRequestSha256']=sha(spaced);sb['preparationSha256']=sha(sc.json());art=json.loads(sc.lower_postgresql_current_presence_candidate_json(enc(sb)));ck('new-exact-pins-same-sql',art['sql'],first['compiled']['sql']);ck('new-exact-pins-no-authority',[art['authority'],art['securityReady'],art['nativeAdmission']],[False,False,'required'])
# Equal reports may be data-equal, but cannot be imported as an issued object.
for label,data in [('presence-report',child.json()),('native-input',child.native_request_json()),('sql-artifact',child.lower_postgresql_current_presence_candidate_json(binding)),('transport-report',child.check_postgresql_current_presence_candidate_json(binding,frame))]:
 reject(label+'-not-lineage',lambda data=data:weft.prepare_application_lineage(data))
 reject(label+'-not-constructor',lambda data=data:T(data))
# __class__ spoofing can fool Python isinstance, but never the native receiver/type/string checks.
class FakeString:
 @property
 def __class__(self):calls.append('fake-class');return str
 def __str__(self):calls.append('str');raise RuntimeError('callback')
 def __len__(self):calls.append('len');raise RuntimeError('callback')
class FakePresence:
 @property
 def __class__(self):calls.append('presence-class');return T
 def __getattr__(self,key):calls.append(key);raise RuntimeError('callback')
class StrSubclass(str):
 def __str__(self):calls.append('subclass-str');raise RuntimeError('callback')
 def __len__(self):calls.append('subclass-len');raise RuntimeError('callback')
values=[None,True,12,{},[],b'{}',bytearray(b'{}'),memoryview(b'{}'),FakeString(),StrSubclass(binding)]
for i,v in enumerate(values):
 for label,f in [('lower-binding',lambda v=v:child.lower_postgresql_current_presence_candidate_json(v)),('check-binding',lambda v=v:child.check_postgresql_current_presence_candidate_json(v,frame)),('check-frame',lambda v=v:child.check_postgresql_current_presence_candidate_json(binding,v))]:reject(str(i)+':'+label,f,'WFT-CURRENT-PRESENCE-BRIDGE: Current presence bridge refused')
for method,args in [('source_preparation',()),('json',()),('native_request_json',()),('lower_postgresql_current_presence_candidate_json',(binding,)),('check_postgresql_current_presence_candidate_json',(binding,frame))]:
 for label,bad in [('fake',FakePresence()),('dict',{}),('parent',parent),('old-type',weft.prepare_application_lineage((root/'tests/current-query-designation/fixtures/disclosed-token-equality.request.json').read_text()).prepare_current_query())]:reject('raw:'+method+':'+label,lambda method=method,args=args,bad=bad:getattr(T,method)(bad,*args))
ck('zero-user-callbacks',calls,[])
# All enabled old scalar descriptors remain type-closed, before their binding/input work.
old_descriptors=[]
for name in dir(weft.CurrentQueryPreparation):
 if name.startswith(('lower_','check_'))and inspect.ismethoddescriptor(getattr(weft.CurrentQueryPreparation,name)):
  old_descriptors.append(name);args=(binding,frame)if name.startswith('check_')else(binding,)
  reject('old-descriptor:'+name,lambda name=name,args=args:getattr(weft.CurrentQueryPreparation,name)(child,*args))
if mode=='combined':ck('old-descriptor-matrix-present',len(old_descriptors)>=19)
# New native object cannot be reconstructed or have custody overwritten through Python object hooks.
for label,f in [('set-original',lambda:setattr(child,'original',other)),('del-original',lambda:delattr(child,'original')),('dict',lambda:vars(child)),('getstate-import',lambda:T.__new__(T)),('base-new',lambda:object.__new__(T)),('subclass',lambda:type('Forged',(T,),{})),('class-swap',lambda:setattr(child,'__class__',weft.CurrentQueryPreparation)),('shallow-copy',lambda:copy.copy(child)),('deep-copy',lambda:copy.deepcopy(child))]:reject(label,f)
for protocol in range(pickle.HIGHEST_PROTOCOL+1):reject('pickle-protocol:'+str(protocol),lambda protocol=protocol:pickle.dumps(child,protocol=protocol))
# Exact UTF8 boundary is checked before parsing/coercion; exact valid bodies at the limits still work.
for label,s in [('lone-high','\ud800'),('lone-low','\udfff'),('unpaired-mixed','x\ud800y'),('paired-surrogate-codepoints','\ud83d\ude00')]:
 reject(label+':binding',lambda s=s:child.lower_postgresql_current_presence_candidate_json(s),'WFT-CURRENT-PRESENCE-BRIDGE:');reject(label+':frame',lambda s=s:child.check_postgresql_current_presence_candidate_json(binding,s),'WFT-CURRENT-PRESENCE-BRIDGE:')
for label,s,maxsize in [('ascii','x',4_000_000),('bmp','é',4_000_000),('supplementary','😀',4_000_000)]:
 width=len(s.encode());v=s*(maxsize//width+1);reject(label+':binding-utf8-over',lambda v=v:child.lower_postgresql_current_presence_candidate_json(v),'WFT-CURRENT-PRESENCE-BRIDGE:')
for label,s in [('ascii','x'),('bmp','é'),('supplementary','😀')]:
 v=s*(16_000_000//len(s.encode())+1);reject(label+':frame-utf8-over',lambda v=v:child.check_postgresql_current_presence_candidate_json(binding,v),'WFT-CURRENT-PRESENCE-BRIDGE:')
padded_binding=binding+' '*(4_000_000-len(binding.encode()));start=time.monotonic();ba=child.lower_postgresql_current_presence_candidate_json(padded_binding);bd=time.monotonic()-start;ck('exact-4m-binding-byte-length',len(padded_binding.encode()),4_000_000);ck('exact-4m-binding-success',json.loads(ba)['materializationBindingSha256'],sha(padded_binding));ck('exact-4m-binding-sql',json.loads(ba)['sql'],first['compiled']['sql'])
reject('4m-plus1-binding',lambda:child.lower_postgresql_current_presence_candidate_json(padded_binding+' '),'WFT-CURRENT-PRESENCE-BRIDGE:')
padded_frame=frame+' '*(16_000_000-len(frame.encode()));start=time.monotonic();fr=child.check_postgresql_current_presence_candidate_json(binding,padded_frame);fd=time.monotonic()-start;ck('exact-16m-frame-byte-length',len(padded_frame.encode()),16_000_000);ck('exact-16m-frame-success',json.loads(fr)['transportInputSha256'],sha(padded_frame));reject('16m-plus1-frame',lambda:child.check_postgresql_current_presence_candidate_json(binding,padded_frame+' '),'WFT-CURRENT-PRESENCE-BRIDGE:')
# Closed bodies, duplicate keys, non-JSON, and wrong result custody must not produce partial success or leak supplied data.
for label,s in [('duplicate-key','{"version":"review-private-sentinel",'+binding[1:]),('unknown-key',binding[:-1]+',"review-private-sentinel":true}'),('nul','\0'),('nonfinite','NaN'),('depth','['*130+'0'+']'*130)]:reject(label+':binding',lambda s=s:child.lower_postgresql_current_presence_candidate_json(s))
for label,f in [('extra-member',lambda x:x.update({'review-private-sentinel':True})),('old-version',lambda x:x.update({'version':'weft.current-query.refinement-input/0.2-candidate'})),('stale-pin',lambda x:x.update({'preparationSha256':'0'*64})),('count-noncanonical',lambda x:x.update({'expectedRowCount':'01'})),('missing-row',lambda x:x.update({'resultRows':[]})),('sql-null',lambda x:x['resultRows'][0].__setitem__(0,None))]:
 x=copy.deepcopy(first['frame']);f(x);reject('frame:'+label,lambda x=x:child.check_postgresql_current_presence_candidate_json(binding,enc(x)),'WFT-CURRENT-PRESENCE-TRANSPORT:')
# Parent lifetime after source handle deletion; actual Python parent object is retained.
parent_id=id(parent);del parent;gc.collect();ck('retained-parent-id',id(child.source_preparation()),parent_id);ck('retained-parent-source',child.source_preparation().source_request_json(),request);ck('repeated-original-report',child.json(),otherchild.json());ck('lifetime-artifact-unchanged',json.loads(child.lower_postgresql_current_presence_candidate_json(binding)),first['compiled'])
# Scope: a structurally exact invalid selected occurrence still requires whole UMF validation.
tr=emitted['allowed:transformed-null'];tc=weft.prepare_application_lineage(enc(cases['allowed:transformed-null'])).prepare_current_presence();tf=copy.deepcopy(tr['frame']);badcell=json.loads(tf['rows'][0]['cells'][0]);badcell['selection']={'ruleIndex':999,'disclosureIndex':999};badcell=enc(badcell);tf['rows'][0]['cells'][0]=badcell;tf['resultRows'][0][0]=badcell;qualified=json.loads(tc.check_postgresql_current_presence_candidate_json(enc(tr['binding']),enc(tf)));ck('structural-invalid-policy-selection-qualified',[qualified['matched'],qualified['authority'],qualified['securityReady'],qualified['nativeAdmission']],[True,False,False,'required'])
result={'status':'passed'if all(c['passed']for c in checks)else'failed','mode':mode,'checks':checks,'count':len(checks),'errors':errors,'oldDescriptorNames':old_descriptors,'bodyBoundaryTimesSeconds':{'binding4m':bd,'frame16m':fd},'modulePath':weft.__file__,'nativePath':str(R/'wheels'/mode/'installed/weft/weft.abi3.so'),'pythonVersion':sys.version,'scope':'Actual native C-extension embedding controls; no database or authenticated source/caller/current-cut/guarded release claim.'}
(R/('independent-python-'+mode+'.json')).write_text(json.dumps(result,ensure_ascii=True,indent=2)+'\n');print(json.dumps({'status':result['status'],'mode':mode,'checks':len(checks),'oldDescriptors':len(old_descriptors),'failures':[c['id']for c in checks if not c['passed']]}));raise SystemExit(0 if result['status']=='passed'else 1)
