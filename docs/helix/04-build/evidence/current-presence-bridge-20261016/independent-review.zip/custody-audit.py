from pathlib import Path
import json,zipfile,hashlib,shutil
R=Path(__file__).resolve().parent;root=R/'reconstructed';owner=Path('/private/tmp/weft-presence-bridge-owner-20261016');checks=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
def ck(n,a,e):checks.append({'id':n,'passed':type(a)==type(e)and a==e,'actual':a,'expected':e})
before=json.loads((R/'source-before.json').read_text())
for p,h in before.items():ck('original-reconstruction-unchanged:'+p,sha((root/p).read_bytes()),h)
paths=[]
for p in sorted(root.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(root);parts=rel.parts
 if any(x in parts for x in ['target','node_modules','__pycache__','.git']):continue
 if parts[0]in ['crates','tests','vendor','scripts','spec','packages']or str(rel).startswith('docs/helix/02-design/')or str(rel)in ['Cargo.toml','Cargo.lock','package.json','bun.lock','.helix.yml','AGENTS.md','README.md']or parts[0]=='.cargo':paths.append(p)
selected={str(p.relative_to(root)):sha(p.read_bytes())for p in paths}
for p,h in selected.items():
 other=owner/p;ck('owner-source-endpoint:'+p,sha(other.read_bytes())if other.is_file()else None,h)
with zipfile.ZipFile(R/'reviewed-source-inputs.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in paths:z.writestr(str(p.relative_to(root)),p.read_bytes())
 z.writestr('review-source-manifest.json',json.dumps(selected,indent=2)+'\n')
with zipfile.ZipFile(R/'external-js-runtime.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted((root/'node_modules').rglob('*')):
  if p.is_file():z.writestr(str(p.relative_to(root/'node_modules')),p.read_bytes())
 # Local source-pinned third-party package bytes for the governance replay only.
manifest=json.loads((R/'frozen/manifest.json').read_text())
for name,w in manifest['wheels'].items():
 local=R/'wheels'/name/Path(w['path']).name;ck(name+':wheel-hash',sha(local.read_bytes()),w['sha256'])
 for n,h in w['members'].items():ck(name+':installed:'+n,sha((R/'wheels'/name/'installed'/n).read_bytes()),h)
for name,expected in [('combined',415),('candidate',410),('legacy',7),('runtime-only',12)]:
 r=json.loads((R/'replays'/(name+'.json')).read_text());ck(name+':passed',r['passed'],True);ck(name+':count',r['checks'],expected)
 for suf in ['weft/__init__.py','weft/weft.abi3.so']:ck(name+':module-before-after:'+suf,sha((R/'wheels'/name/'installed'/suf).read_bytes()),manifest['wheels'][name]['members'][suf])
supplement=Path('/private/tmp/weft-presence-python-candidate-final-receipt-20261016.json');shutil.copy2(supplement,R/'frozen/candidate-later-final-receipt.json');s=json.loads(supplement.read_text());own=json.loads((R/'replays/candidate.json').read_text());ck('later-candidate-final-receipt-count',s['checks'],410);ck('later-candidate-exact-control-list',s['checksPassed'],own['checksPassed'])
# Current owner fixture is exactly the prior independently qualified actual logical handoff/emitted artifact cohort.
ck('emitted-fixture-prior-pin',selected['tests/current-query-presence/fixtures/actual-atomic-transport-emitted.json'],'9f0f952fa260697bf055ec22d20792565b4db295a86c2f82ca4949f5ee236710')
ck('actual-producer-corpus-prior-pin',selected['tests/current-query-presence/fixtures/actual-atomic-transport.json'],'f19439e8da44419aa2c08252a8155aa2efc2dc807cbb1b90e0cace7297660a53')
# Exact bridge scope: the frozen candidate changes precisely the listed eight paths relative to the base archive.
with __import__('tarfile').open(R/'frozen/base.tar')as t:
 basefiles={m.name:t.extractfile(m).read()for m in t.getmembers()if m.isfile()}
 actualdiff=[p for p in sorted(set(basefiles)|set(before))if basefiles.get(p)!= (root/p).read_bytes()if(root/p).is_file()]
ck('exact-eight-file-delta',actualdiff,sorted(e['path']for e in manifest['sourceFiles']))
jsbefore=json.loads((R/'governance-runtime-pins.json').read_text())
for p,h in jsbefore.items():ck('governance-runtime-unchanged:'+p,sha((root/'node_modules'/p).read_bytes()),h)
report={'status':'passed'if all(c['passed']for c in checks)else'failed','count':len(checks),'checks':checks,'failures':[c for c in checks if not c['passed']],'originalReconstructedFiles':len(before),'selectedSourceFiles':len(selected),'selectedSourcePins':selected,'sourceArchiveSha256':sha((R/'reviewed-source-inputs.zip').read_bytes()),'externalJsArchiveSha256':sha((R/'external-js-runtime.zip').read_bytes()),'qualification':'Reconstructed exact Git base plus eight overlays; independently built/executed from this snapshot, original bytes unchanged, current owner endpoints compared. Source endpoint comparisons do not establish held-file/ABA or hermetic toolchain custody.'}
(R/'custody-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in ['checks','selectedSourcePins']}));raise SystemExit(0 if report['status']=='passed'else 1)
