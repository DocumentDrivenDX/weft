from pathlib import Path
import subprocess,os,time,json,zipfile,hashlib
R=Path(__file__).resolve().parent;out=R/'wheels/all-features';out.mkdir(exist_ok=True)
env={**os.environ,'PATH':'/Users/erik/.rustup/toolchains/1.90.0-aarch64-apple-darwin/bin:'+os.environ['PATH'],'CARGO_HOME':'/private/tmp/weft-toolchain/cargo','CARGO_TARGET_DIR':str(R/'target')}
args=['/private/tmp/weft-toolchain/venv/bin/maturin','build','--offline','--locked','--manifest-path',str(R/'reconstructed/crates/weft-python/Cargo.toml'),'--features','truss-postgresql-pg18,current-postgresql-scalar-candidate,current-databricks-scalar-candidate,current-query-refinement-candidate,current-presence-candidate,bounded-current-string-candidate,current-spark-scalar-candidate','--out',str(out)]
t=time.monotonic();p=subprocess.run(args,cwd=R/'reconstructed/crates/weft-python',env=env,capture_output=True,text=True,timeout=600)
(R/'independent-wheel-build.stdout').write_text(p.stdout);(R/'independent-wheel-build.stderr').write_text(p.stderr)
r={'command':args,'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-t,'qualification':'Independent local source-reconstructed dev abi3 ARM wheel, explicitly enabling baseline plus presence/bounded/Spark solely for cross-feature review; not the supplied wheel or a release artifact.'}
if not p.returncode:
 wheels=list(out.glob('*.whl'));assert len(wheels)==1;w=wheels[0];r['wheel']={'path':str(w),'sha256':hashlib.sha256(w.read_bytes()).hexdigest()};z=zipfile.ZipFile(w);z.extractall(out/'installed');r['members']={n:hashlib.sha256(z.read(n)).hexdigest()for n in z.namelist()};
(R/'independent-wheel-build.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(p.returncode)
