import pathlib,subprocess,tarfile,io,hashlib,json,shutil
R=pathlib.Path(__file__).parent;F=R/'frozen';M=json.loads((F/'review-manifest.json').read_text());repo=pathlib.Path('/Users/erik/Projects/weft');base=M['baseCommit'];root=R/'reconstructed';root.mkdir(exist_ok=True)
paths=subprocess.check_output(['git','ls-tree','--name-only',base],cwd=repo,text=True).splitlines();chosen=[p for p in paths if p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','crates','tests','docs','vendor','spikes','AGENTS.md','.helix.yml']];raw=subprocess.check_output(['git','archive',base,*chosen],cwd=repo);tar=tarfile.open(fileobj=io.BytesIO(raw));selected=[]
for member in tar.getmembers():
 if member.name.startswith('docs/') and not member.name.startswith(('docs/helix/02-design/','docs/helix/README.md')):continue
 assert not member.name.startswith('/') and '..' not in pathlib.PurePosixPath(member.name).parts;selected.append(member)
tar.extractall(root,members=selected)
for f in M['sourceFiles']:
 p=f['path'];data=(F/p).read_bytes();assert hashlib.sha256(data).hexdigest()==f['sha256'];old=root/p
 assert (hashlib.sha256(old.read_bytes()).hexdigest() if old.exists() else None)==f['baselineSha256'],p
 old.parent.mkdir(parents=True,exist_ok=True);old.write_bytes(data)
sourcepins={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()};(R/'source-custody.json').write_text(json.dumps({'base':base,'overlays':M['sourceFiles'],'selectedSourcePins':sourcepins,'scope':'Exact Git base source roots plus ten frozen overlays; docs execution evidence excluded; no owner checkout mutation'},indent=2)+'\n');print(len(sourcepins))
