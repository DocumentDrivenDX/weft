import pathlib,json,hashlib,copy,subprocess
R=pathlib.Path(__file__).parent;ROOT=R/'reconstructed';sha=lambda x:hashlib.sha256(x.encode()).hexdigest();dump=lambda v:json.dumps(v,separators=(',',':'),ensure_ascii=False)
def source(role,identity,raw):return dict(role=role,identity=identity,mediaType='application/json',utf8=raw,sha256=sha(raw))
def fixture():
 r=json.loads((ROOT/'tests/current-query-presence/fixtures/optional-token-lineage.request.json').read_text());pins=[{k:s[k] for k in ['role','identity','sha256']} for s in r['opaqueSources']];o=json.loads(next(s for s in r['opaqueSources'] if s['role']=='ontology')['utf8']);action=next(e['action'] for e in o['actionPurposes'] if 'read' in e['purposes']);b=source('native-binding',dict(documentId='unadmitted-fixture',revision='1'),'{"unadmitted":true}');r['opaqueSources'].append(b);p=dict(version='weft.current-presence.designation-profile/0.1-candidate',id='presence',revision='1',modelPins=[m['pin'] for m in r['modules']],sources=pins,binding=dict(backendId='test',backendVersion='0.1-candidate',targetProfile='unadmitted',source=b['identity'],sha256=b['sha256']),targets=[dict(documentId='domain',moduleId='m',elementId='Resource')],primaryAction=action,capabilities=['tagged-current-projection'],producer=dict(protocol='umf.security.logical-disclosure-batch/0.1-candidate',entrypoint='evaluateCandidateCatalogReadDisclosureBatchWithinOperation'));r['opaqueSources'].append(source('presence-designation',dict(documentId=p['id'],revision=p['revision']),dump(p)));return r
def prof(r,fn):
 s=next(s for s in r['opaqueSources'] if s['role']=='presence-designation');p=json.loads(s['utf8']);fn(p);s['utf8']=dump(p);s['sha256']=sha(s['utf8'])
def repin(r,role,fn):
 s=next(s for s in r['opaqueSources'] if s['role']==role);fn(s);s['sha256']=sha(s['utf8'])
 def update(p):
  if role=='presence-designation':return
  if role=='native-binding':p['binding']['source']=s['identity'];p['binding']['sha256']=s['sha256']
  else:
   q=next(q for q in p['sources'] if q['role']==role);q['identity']=s['identity'];q['sha256']=s['sha256']
 prof(r,update)
cases=[]
def add(id,fn=lambda r:None,expected='prepared'):
 r=fixture();fn(r);cases.append(dict(id=id,request=dump(r),expected=expected))
def pc(id,fn,expected='refused'):add(id,lambda r:prof(r,fn),expected)
add('baseline')
for path in ['version','capabilities','producer','sources','modelPins','binding','targets','primaryAction','id','revision']:
 pc('missing-'+path,lambda p,path=path:p.pop(path))
for key,v in [('version','future'),('capabilities',[]),('capabilities',['tagged-current-projection','tagged-current-projection']),('primaryAction','not-an-action'),('id',''),('revision','')]:pc('bad-'+key+'-'+str(v),lambda p,k=key,v=v:p.update({k:v}))
for location in ['root','producer','binding','binding-source','source-pin','source-identity','model-pin','target']:
 def extra(p,loc=location):
  q={'root':p,'producer':p['producer'],'binding':p['binding'],'binding-source':p['binding']['source'],'source-pin':p['sources'][0],'source-identity':p['sources'][0]['identity'],'model-pin':p['modelPins'][0],'target':p['targets'][0]}[loc];q['unknown']=True
 pc('unknown-'+location,extra)
for path in ['protocol','entrypoint']:pc('wrong-producer-'+path,lambda p,path=path:p['producer'].update({path:'umf.security.logical-disclosure-selection/0.1-candidate'}))
for role in ['policy','ontology','catalog','owner','native-binding','presence-designation']:
 add('missing-role-'+role,lambda r,role=role:r.update(opaqueSources=[s for s in r['opaqueSources'] if s['role']!=role]),'refused')
 def duplicate(r,role=role):
  s=copy.deepcopy(next(s for s in r['opaqueSources'] if s['role']==role));s['identity']['revision']='duplicate-distinct';r['opaqueSources'].append(s)
 add('duplicate-role-'+role,duplicate,'refused')
 add('wrong-hash-'+role,lambda r,role=role:next(s for s in r['opaqueSources'] if s['role']==role).update(sha256='0'*64),'refused')
 add('wrong-media-'+role,lambda r,role=role:next(s for s in r['opaqueSources'] if s['role']==role).update(mediaType='text/plain'),'refused')
for key in ['backendId','backendVersion','targetProfile']:
 for text in ['', 'x\0y','x'*4096,'x'*4097,'é'*2048,'é'*2049]:pc('binding-'+key+'-'+str(len(text.encode()))+'-'+str('\0' in text),lambda p,key=key,text=text:p['binding'].update({key:text}),'prepared' if text and '\0' not in text and len(text.encode())<=4096 else 'refused')
for role in ['policy','native-binding']:
 for text in ['x\0y','é'*2048,'é'*2049]:
  add('identity-'+role+'-'+str(len(text.encode())),lambda r,role=role,text=text:repin(r,role,lambda s:s['identity'].update(documentId=text)),'prepared' if '\0' not in text and len(text.encode())<=4096 else 'refused')
for raw in ['[]','null','1','"text"','{"x":1,"x":2}','{"x":1,}']:
 add('binding-nonobject-'+raw,lambda r,raw=raw:repin(r,'native-binding',lambda s:s.update(utf8=raw)),'refused')
add('unknown-binding-object-preserved',lambda r:repin(r,'native-binding',lambda s:s.update(utf8='{"unknown":{"arbitrary":123}}')))
add('opaque-policy-not-semantically-admitted',lambda r:repin(r,'policy',lambda s:s.update(utf8='uninterpreted non-JSON body')))
add('unrelated-opaque-preserved',lambda r:r['opaqueSources'].append(source('unrelated',dict(documentId='external',revision='1'),'not parsed')))
add('sources-reordered',lambda r:r['opaqueSources'].reverse())
pc('source-pins-reordered',lambda p:p['sources'].reverse(),'prepared')
pc('duplicate-pin-role',lambda p:p['sources'].__setitem__(1,copy.deepcopy(p['sources'][0])))
pc('wrong-target',lambda p:p['targets'][0].update(elementId='Project'))
pc('extra-target',lambda p:p['targets'].append(copy.deepcopy(p['targets'][0])))
pc('missing-model-pin',lambda p:p.update(modelPins=[]))
pc('wrong-model-hash',lambda p:p['modelPins'][0].update(sha256='0'*64))
for version in ['0.1-candidate','0.2-candidate','0.3-candidate','0.5-candidate']:
 add('old-or-unknown-parent-'+version,lambda r,v=version:r.update(interfaceVersion='weft-application-lineage/'+v,sql='SELECT r.resourceId FROM Resource r'),'refused')
for sql in ['', 'SELECT * FROM Resource r','SELECT r.token FROM Resource r WHERE FALSE','SELECT r.token FROM Resource r LIMIT 0']:
 add('parent-sql-'+sql,lambda r,sql=sql:r.update(sql=sql),'refused')
def ontology(r,fn):
 def f(s):o=json.loads(s['utf8']);fn(o);s['utf8']=dump(o)
 repin(r,'ontology',f)
add('purpose-is-not-grant-control',lambda r:repin(r,'policy',lambda s:s.update(utf8='{}')))
add('no-read-purpose',lambda r:ontology(r,lambda o:[e.update(purposes=['other']) for e in o['actionPurposes']]),'refused')
add('unknown-ontology-version',lambda r:ontology(r,lambda o:o.update(version='0.3.0')),'refused')
add('missing-purpose-entry',lambda r:ontology(r,lambda o:o['actionPurposes'].pop()),'refused')
add('duplicate-purpose',lambda r:ontology(r,lambda o:o['actionPurposes'][0]['purposes'].append(o['actionPurposes'][0]['purposes'][0])),'refused')
add('large-unrelated-opaque',lambda r:r['opaqueSources'].append(source('unrelated',dict(documentId='large',revision='1'),'x'*2_500_000)))
add('parent-over4m',lambda r:r['opaqueSources'].append(source('unrelated',dict(documentId='large',revision='1'),'x'*4_000_000)),'refused')
(R/'authored-controls.json').write_text(json.dumps(cases,indent=2,ensure_ascii=False)+'\n');raw=''.join(dump({k:v for k,v in c.items() if k!='expected'})+'\n' for c in cases)
p=subprocess.run([str(R/'target/debug/astra-current-presence-probe')],input=raw,text=True,capture_output=True);(R/'probe-stderr.log').write_text(p.stderr);(R/'observations.jsonl').write_text(p.stdout);assert p.returncode==0,(p.returncode,p.stderr)
observations=[json.loads(x) for x in p.stdout.splitlines()];checks=[]
for c,o in zip(cases,observations):
 v=o['observation'];passed=(v['stage']=='prepared')==(c['expected']=='prepared');checks.append(dict(id=c['id'],passed=passed,stage=v['stage'],expected=c['expected']))
 if v['stage']=='prepared':
  report=v['report'];native=v['native'];checks.append(dict(id=c['id']+':custody',passed=v['sameParent'] and v['oldDesignationRefused'] and report['authority']==False and report['securityReady']==False and report['nativeAdmission']=='required' and report['sourceRequestSha256']==sha(c['request']) and native['sourceRequestJson']==c['request'] and native['preparationSha256']==sha(v['reportJson']) and not v['nativeRefused'] and v['nativeBytes']<=16_000_000))
result=dict(status='passed' if len(observations)==len(cases) and all(c['passed'] for c in checks) else 'failed',scenarios=len(cases),checks=len(checks),controls=checks,nativeAdmission=False);(R/'controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='controls'}));print('FAILURES',[c for c in checks if not c['passed']])
