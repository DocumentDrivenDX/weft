import pathlib,json,copy,hashlib,subprocess
R=pathlib.Path(__file__).parent;baseline=json.loads((R/'authored-controls.json').read_text())[0]['request'];original=json.loads(baseline);cases=[];dump=lambda x:json.dumps(x,separators=(',',':'));sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
for count in [256,257]:
 r=copy.deepcopy(original);r['sql']='SELECT '+','.join('r.token AS t'+str(i) for i in range(count))+' FROM Resource r';cases.append(dict(id='projection-'+str(count),request=dump(r),expected='prepared' if count==256 else 'refused',fields=count))
for count in [16,17]:
 r=copy.deepcopy(original)
 while len(r['opaqueSources'])<count:
  i=len(r['opaqueSources']);r['opaqueSources'].append(dict(role='unrelated-'+str(i),identity=dict(documentId='d',revision='1'),mediaType='application/json',utf8='null',sha256=sha('null')))
 cases.append(dict(id='opaque-count-'+str(count),request=dump(r),expected='prepared' if count==16 else 'refused'))
for size in [4_000_000,4_000_001]:cases.append(dict(id='exact-parent-bytes-'+str(size),request=baseline+' '*(size-len(baseline.encode())),expected='prepared' if size==4_000_000 else 'refused'))
for length in [4096,4097]:
 r=copy.deepcopy(original);s=next(s for s in r['opaqueSources'] if s['role']=='presence-designation');p=json.loads(s['utf8']);p['id']='p'*length;s['identity']['documentId']=p['id'];s['utf8']=dump(p);s['sha256']=sha(s['utf8']);cases.append(dict(id='profile-id-'+str(length),request=dump(r),expected='prepared' if length==4096 else 'refused'))
(R/'boundary-inputs.json').write_text(json.dumps(cases)+'\n');p=subprocess.run([str(R/'target/debug/astra-current-presence-probe')],input=''.join(dump(c)+'\n' for c in cases),text=True,capture_output=True);assert p.returncode==0,p.stderr;(R/'boundary-observations.jsonl').write_text(p.stdout);rows=[json.loads(x) for x in p.stdout.splitlines()];controls=[]
for c,row in zip(cases,rows):
 o=row['observation'];passed=(o['stage']=='prepared')==(c['expected']=='prepared');controls.append(dict(id=c['id'],passed=passed,stage=o['stage']))
 if o['stage']=='prepared':controls.append(dict(id=c['id']+':exact-retention',passed=o['native']['sourceRequestJson']==c['request'] and o['report']['sourceRequestSha256']==sha(c['request']) and o['native']['preparationSha256']==sha(o['reportJson']) and o['sameParent'] and o['oldDesignationRefused'] and ('fields' not in c or len(o['report']['readRequirements']['fields'])==c['fields'])))
r=dict(status='passed' if len(rows)==len(cases) and all(c['passed'] for c in controls) else 'failed',scenarios=len(cases),checks=len(controls),controls=controls);(R/'boundary-controls.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
