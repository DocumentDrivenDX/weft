/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const inspect_security_mapping_subject_key_json: (a: number, b: number, c: number, d: number) => [number, number];
export const prepare_security_mapping_json: (a: number, b: number) => [number, number];
export const compile_json: (a: number, b: number) => [number, number];
export const __wbg_mutationcompiler_free: (a: number, b: number) => void;
export const mutationcompiler_new: (a: number, b: number) => [number, number, number];
export const mutationcompiler_register_browser_selection: (a: number, b: number, c: number) => [number, number, number];
export const mutationcompiler_lower_selection_json: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const mutationcompiler_compile_json: (a: number, b: number, c: number) => [number, number];
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
