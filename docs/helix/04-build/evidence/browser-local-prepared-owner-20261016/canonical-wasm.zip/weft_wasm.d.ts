/* tslint:disable */
/* eslint-disable */
/**
 * Original ontology Subject/Record/Key source selection only; no authority.
 */
export function inspect_security_mapping_subject_key_json(request: string, selection: string): string;
/**
 * Pure logical preparation; never native execution admission.
 */
export function prepare_security_mapping_json(request: string): string;
export function compile_json(request: string): string;
/**
 * Host-installed action preparation. Compiles plans; grants no execution authority.
 */
export class MutationCompiler {
  free(): void;
  [Symbol.dispose](): void;
  constructor(configuration: string);
  register_browser_selection(configuration: string): number;
  lower_selection_json(handle: number, request: string): string;
  compile_json(request: string): string;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly inspect_security_mapping_subject_key_json: (a: number, b: number, c: number, d: number) => [number, number];
  readonly prepare_security_mapping_json: (a: number, b: number) => [number, number];
  readonly compile_json: (a: number, b: number) => [number, number];
  readonly __wbg_mutationcompiler_free: (a: number, b: number) => void;
  readonly mutationcompiler_new: (a: number, b: number) => [number, number, number];
  readonly mutationcompiler_register_browser_selection: (a: number, b: number, c: number) => [number, number, number];
  readonly mutationcompiler_lower_selection_json: (a: number, b: number, c: number, d: number) => [number, number, number, number];
  readonly mutationcompiler_compile_json: (a: number, b: number, c: number) => [number, number];
  readonly __wbindgen_externrefs: WebAssembly.Table;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly __externref_table_dealloc: (a: number) => void;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
