import json,pathlib,hashlib,zipfile,shutil
out=pathlib.Path('/private/tmp/weft-bounded-string-r5-astra-20261016'); source=out/'source'; cohort=pathlib.Path('/private/tmp/weft-bounded-r5-bridge-cohort-20261016'); manifest=json.loads((source/'snapshot-manifest.json').read_text()); evidence=out/'owner-evidence';evidence.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def saved(p):p=pathlib.Path(p);q=evidence/p.name;shutil.copy2(p,q);return {'path':str(p),'retained':str(q),'sha256':sha(q)}
j=json.loads((cohort/'cohort.json').read_text());assert j['status']=='passed'and j['failure']is None and j['sourceInputsUnchanged']is True and j['sourceInputs']==manifest['inputs'];assert len(j['executions'])==26 and all(e['exitCode']==0 and e['timedOut']is False for e in j['executions'])
report={'cohort':saved(cohort/'cohort.json'),'sourceInputsExact':len(j['sourceInputs']),'executionCount':26,'artifacts':{},'receipts':{},'controls':{},'notes':[]}
for e in j['executions']:
 for ext in ['stdout','stderr']:saved(cohort/(e['id']+'.'+ext))
for mode,a in j['artifacts'].items():
 w=list((cohort/(mode+'-wheels')).glob('*.whl'));assert len(w)==1 and sha(w[0])==a['wheelSha256']
 for name in ['weft_wasm.js','weft_wasm_bg.wasm','weft_wasm.d.ts']:assert sha(cohort/(mode+'-web')/name)==a[name]
 assert sha(cohort/(mode+'-raw.wasm'))==a['rawWasmSha256']
 report['artifacts'][mode]={'wheel':str(w[0]),**a}
 with zipfile.ZipFile(w[0])as z:
  native=[n for n in z.namelist()if n.endswith(('.so','.pyd'))];assert len(native)==1
  installed=list((cohort/(mode+'-python/lib')).glob('python*/site-packages/weft/'+pathlib.Path(native[0]).name));assert len(installed)==1 and installed[0].read_bytes()==z.read(native[0]);report['artifacts'][mode]['installedNativeSha256']=sha(installed[0])
  shim=installed[0].parent/'__init__.py';assert shim.read_bytes()==z.read('weft/__init__.py');report['artifacts'][mode]['installedShimSha256']=sha(shim)
 b=json.loads((cohort/(mode+'-browser.json')).read_text());assert b['mode']==mode and b['jsSha256']==a['weft_wasm.js'] and b['wasmSha256']==a['weft_wasm_bg.wasm']and not b['pageErrors'];assert b['nativePacketSha256']==sha(cohort/'native-vectors.json');assert len(set(c['id']for c in b['controls']))==len(b['controls'])and all(c['passed']is True for c in b['controls']);report['controls'][mode+'Browser']=len(b['controls'])
 for name in [mode+'-browser.json',mode+'-legacy-refinement.json']:report['receipts'][name]=saved(cohort/name)
 n=cohort/('native-vectors.json'if mode=='bounded'else'standard-native.json');q=json.loads(n.read_text());report['receipts'][n.name]=saved(n)
 checks=q.get('checks',q.get('controls'));report['controls'][mode+'Native']=len(checks)
 assert len(set(c['id'] if isinstance(c,dict) else c for c in checks))==len(checks)
 for c in checks:
  if isinstance(c,dict):assert c.get('passed',c.get('matched',c.get('refused',True)))is True
 if mode=='bounded':assert len(q['vectors'])==18;report['controls']['vectors']=len(q['vectors'])
core=pathlib.Path('/private/tmp/weft-bounded-main-core-20261016.json');c=json.loads(core.read_text());log=core.with_suffix('.log');assert c['snapshotSha256']==sha(pathlib.Path('/private/tmp/weft-bounded-string-r5-source-review-20261016.zip'))and c['sourceInputsUnchanged']is True and c['sourceInputs']==1157 and not c['changedInputs']and c['logSha256']==sha(log);report['core']={'receipt':saved(core),'log':saved(log),'results':c['results'],'independentReplay':False}
report['scalarLog']=saved('/private/tmp/weft-bounded-r5-frozen-scalars-20261016.log');report['notes'].append('Scalar log is supplied compiler test evidence; no separate full pre/post input receipt was supplied with this log.')
(out/'evidence-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k in ['controls','sourceInputsExact','executionCount']},indent=2))
