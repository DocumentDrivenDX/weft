"""Independent profile routing with facetless strings and signed64-only selection."""
import argparse,copy,hashlib,json,pathlib,sys
import weft
p=argparse.ArgumentParser();p.add_argument('--source',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);p.add_argument('--mode',choices=['bounded','standard'],required=True);a=p.parse_args()
text=lambda x:json.dumps(x,separators=(',',':'),ensure_ascii=False)
sha=lambda x:hashlib.sha256(x.encode()).hexdigest()
base=json.loads((a.source/'tests/current-query-designation/fixtures/disclosed-token-equality.request.json').read_text())
checks=[]
def binding(child,backend,version,cap=False):
 packet=json.loads(child.native_request_json());values=[]
 for op in packet['operations']:
  for operand in op['operands']:
   v=operand['input']
   if v['kind']=='field':values.append(dict(path=operand['path'],scan=v['scan'],field=v['identity'],domain=v['identity'],column=v['identity']['element'],comparisonScope='a'*64,mode='original-authorized'if v['originalAction']else'disclosed',originalAction=v['originalAction'],exposure=None))
 for pr in packet['projections']:values.append(dict(path=pr['path'],scan=pr['scan'],field=pr['field'],domain=pr['field'],column=pr['field']['element'],comparisonScope='a'*64,mode=None,originalAction=None,exposure='original'))
 relation=dict(schema='private_stage',table='current_values',eligibleColumn='eligible',rowKeyColumn='private_key')
 if backend=='databricks':relation.update(catalog='client_dev',uuid='00000000-0000-4000-8000-000000000001',version='0',schemaSha256='e'*64)
 out=dict(version=f'weft.{backend}.current-values/{version}-candidate',sourceRequestSha256=packet['sourceRequestSha256'],designationSha256=packet['designationSha256'],sourceBindingSha256=packet['binding']['sha256'],scans=[dict(scan=s['scan'],target=s['record'],relation=relation)for s in packet['scans']],values=values)
 if cap:out['capabilities']=['bounded-unicode-scalars']
 return text(out)
for field,family in [('token','string'),('salary','integer')]:
 old=copy.deepcopy(base);old.update(sql=f'SELECT r.{field} FROM Resource r',parameters={});new=copy.deepcopy(old);new['interfaceVersion']='weft-application-lineage/0.3-candidate'
 src=next(x for x in new['opaqueSources']if x['role']=='query-designation');profile=json.loads(src['utf8']);profile.update(version='weft.current-query.designation-profile/0.3-candidate',capabilities=['bounded-unicode-scalars'])
 for b in profile['bindings']:b['operation']={'predicate':'equal','order':'order'}[b['operator']]
 src['utf8']=text(profile);src['sha256']=sha(src['utf8'])
 oldchild=weft.prepare_application_lineage(text(old)).prepare_current_query();newchild=weft.prepare_application_lineage(text(new)).prepare_current_query()
 packet=json.loads(newchild.native_request_json());logical=packet['projections'][0]['descriptor'][1][0]['type'];assert logical['family']==family and logical['facets']==({} if family=='string' else {'integerWidth':{'bits':64,'signed':True}})
 checks.append(dict(id=field+'/new-profile-facetless-selection',passed=True,type=logical))
 for backend,kind,version,newver in [('postgresql','rows','0.2','0.5'),('postgresql','contributors','0.3','0.5'),('databricks','contributors','0.1','0.3')]:
  oldname=f'lower_{backend}_current_{kind}_candidate_json';newname=f'lower_{backend}_bounded_current_{kind}_candidate_json';tag=f'{field}/{backend}/{kind}'
  good=getattr(oldchild,oldname)(binding(oldchild,backend,version));assert json.loads(good)['authority']is False;checks.append(dict(id=tag+'/old-control-compiles',passed=True))
  try:getattr(newchild,oldname)(binding(newchild,backend,version))
  except ValueError as e:checks.append(dict(id=tag+'/bounded-context-old-api-refused',passed=True,error=str(e)))
  else:raise AssertionError(tag+'old API widened')
  if a.mode=='bounded':
   good=getattr(newchild,newname)(binding(newchild,backend,newver,True));assert json.loads(good)['capabilities']==['bounded-unicode-scalars'];checks.append(dict(id=tag+'/bounded-api-compiles',passed=True))
   try:getattr(oldchild,newname)(binding(oldchild,backend,newver,True))
   except ValueError as e:checks.append(dict(id=tag+'/old-context-bounded-api-refused',passed=True,error=str(e)))
   else:raise AssertionError(tag+'old context admitted')
  else:assert not hasattr(newchild,newname);checks.append(dict(id=tag+'/bounded-api-absent',passed=True))
r=dict(mode=a.mode,scope='Pure installed compiler routing. No native query/authority acceptance.',controls=len(checks),checks=checks,probeSha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest());a.output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'controls':len(checks),'mode':a.mode}))
