import hashlib,json,os,pathlib,subprocess,tomllib
root=pathlib.Path('/private/tmp/weft-bounded-string-r5-frozen-20261016')
owner=pathlib.Path('/Users/erik/Projects/weft')
out=pathlib.Path('/private/tmp/weft-bounded-string-r5-astra-20261016/runtime-review/feature-controls')
base='1ed81c11fa870d57ba21d4339132ff139b05641d'
sha=lambda b:hashlib.sha256(b).hexdigest()
def original(p):return subprocess.check_output(['git','show',f'{base}:{p}'],cwd=owner)
checks=[]
def check(name,condition):
 assert condition,name
 checks.append(name)
report={'base':base,'frozenRoot':str(root),'scope':'Cargo resolution and source retention only; no runtime/native/security or release acceptance','pins':{},'features':{},'retained':{}}
files=['Cargo.toml','crates/weft-core/Cargo.toml','crates/weft-runtime/Cargo.toml','crates/weft-python/Cargo.toml','crates/weft-postgresql/Cargo.toml','crates/weft-databricks/Cargo.toml','crates/weft-core/src/compile.rs','crates/weft-core/src/exact.rs','crates/weft-core/src/model.rs','crates/weft-core/src/application_resolve.rs','crates/weft-core/src/application_model.rs','crates/weft-core/src/application_lineage.rs','crates/weft-core/src/current_query_designation.rs','crates/weft-core/src/backend.rs','crates/weft-core/src/backend03_registry.rs','crates/weft-core/src/current_string_domain.rs','crates/weft-runtime/src/lib.rs','crates/weft-python/src/lib.rs','crates/weft-postgresql/src/truss_runtime.rs','crates/weft-postgresql/src/current_scalar.rs','crates/weft-databricks/src/current_scalar.rs','tests/truss-decimal12/wheel-smoke.py','tests/current-scalar-spark/python-bridge.py','tests/compile/reports.py','tests/application/reports.py']
for p in files:report['pins'][p]=sha((root/p).read_bytes())
for p in ['Cargo.toml','crates/weft-core/src/compile.rs','crates/weft-postgresql/src/truss_runtime.rs','tests/truss-decimal12/wheel-smoke.py','tests/current-scalar-spark/python-bridge.py','tests/compile/reports.py','tests/application/reports.py']:
 same=(root/p).read_bytes()==original(p);check('unchanged:'+p,same);report['retained'][p]={'unchangedFromBase':same,'sha256':report['pins'][p]}
for p,end in [('crates/weft-runtime/src/lib.rs',' /// Trusted Rust consumer hook'),('crates/weft-python/src/lib.rs',' fn operand_count')]:
 text=(root/p).read_text();start=text.index(' #[cfg(feature="bounded-current-string-candidate")]');stop=text.index(end,start)
 check('all-existing-code-unchanged:'+p,(text[:start]+text[stop:]).encode()==original(p))
for pkg in ['core','runtime','python','postgresql','databricks']:
 p=f'crates/weft-{pkg}/Cargo.toml';now=tomllib.loads((root/p).read_text());old=tomllib.loads(original(p).decode());newfeatures=now.get('features',{});oldfeatures=old.get('features',{})
 check('only-bounded-feature-added:'+pkg,{k:v for k,v in newfeatures.items() if k!='bounded-current-string-candidate'}==oldfeatures)
 check('no-new-default:'+pkg,newfeatures.get('default',[])==oldfeatures.get('default',[]))
 report['features'][pkg]=newfeatures
# String arm changed; Decimal branch and all following code remain byte-identical.
p='crates/weft-core/src/exact.rs';marker='        (LiteralKind::Number, Family::Decimal) => {'
check('decimal-literal-validation-retained',(root/p).read_text().split(marker,1)[1]==original(p).decode().split(marker,1)[1])
p='crates/weft-core/src/model.rs';marker='    pub fn record('
# Name fallback is earlier than bounded preparation; pin its exact resolver helper.
now=(root/p).read_text();old=original(p).decode();a="    pub(crate) fn query_name<'a>";b='    pub fn prepare('
check('identity-name-fallback-helper-retained',now.split(a,1)[1].split(b,1)[0]==old.split(a,1)[1].split(b,1)[0])
env=os.environ.copy();env.update(CARGO_HOME='/private/tmp/weft-toolchain/cargo',RUSTUP_HOME='/private/tmp/weft-toolchain/rustup')
standard='truss-postgresql-pg18,current-postgresql-scalar-candidate,current-databricks-scalar-candidate,current-query-refinement-candidate'
configs={'default':'','standard':standard,'bounded':standard+',bounded-current-string-candidate','spark':'current-spark-scalar-candidate'}
report['resolved']={}
for name,features in configs.items():
 cmd=['/private/tmp/weft-toolchain/cargo/bin/cargo','+1.90.0','metadata','--format-version','1','--locked','--offline','--manifest-path',str(root/'crates/weft-python/Cargo.toml'),'--no-default-features']
 if features:cmd+=['--features',features]
 result=subprocess.run(cmd,cwd=root,env=env,text=True,capture_output=True);(out/(name+'-metadata.stderr')).write_text(result.stderr);check('cargo-metadata:'+name,result.returncode==0)
 data=json.loads(result.stdout);(out/(name+'-metadata.json')).write_text(result.stdout)
 ids={p['id']:p['name'] for p in data['packages']};nodes={ids[n['id']]:n['features'] for n in data['resolve']['nodes'] if ids[n['id']] in ['weft-core','weft-python','weft-runtime','weft-postgresql','weft-databricks']};report['resolved'][name]=nodes
 for pkg in nodes:check(f'bounded-resolved-only-explicit:{name}:{pkg}',('bounded-current-string-candidate'in nodes[pkg])==(name=='bounded'))
 check('spark-is-independent:'+name,('current-spark-scalar-candidate' in nodes['weft-runtime'])==(name=='spark'))
report['controls']=len(checks);report['checks']=checks;report['findings']=[]
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'controls':len(checks),'findings':0,'resolved':report['resolved'],'reportSha256':sha((out/'report.json').read_bytes())},indent=2))
