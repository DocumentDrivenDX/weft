#!/bin/sh
set -eu
review=/private/tmp/weft-bounded-string-r5-astra-20261016/runtime-review
source=/private/tmp/weft-bounded-string-r5-frozen-20261016
cohort=/private/tmp/weft-bounded-r5-bridge-cohort-20261016
for mode in bounded standard; do
  "$cohort/$mode-python/bin/python" -B "$review/python-controls.py" --mode "$mode" --wheel "$cohort/$mode-wheels/weft_sql-0.4.36-cp39-abi3-macosx_11_0_arm64.whl" --source "$source" --vectors "$review/native-vectors.json" --output "$review/$mode-controls.json" > "$review/$mode-controls.log" 2>&1
  "$cohort/$mode-python/bin/python" -B "$review/facetless-controls.py" --mode "$mode" --source "$source" --output "$review/$mode-facetless.json" > "$review/$mode-facetless.log" 2>&1
done
python3 "$review/finalize-report.py"
