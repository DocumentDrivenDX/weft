"""Independent R5 installed-wheel boundary controls. No native database authority tested.
Uses exact source-bound vectors as inputs; reconstructs every preparation via public producers.
"""
import argparse, copy, gc, hashlib, importlib, json, pathlib, pickle, sys, zipfile
p=argparse.ArgumentParser();p.add_argument('--mode',choices=['bounded','standard'],required=True);p.add_argument('--wheel',type=pathlib.Path,required=True);p.add_argument('--source',type=pathlib.Path,required=True);p.add_argument('--vectors',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args()
import weft
sha=lambda b:hashlib.sha256(b).hexdigest()
text=lambda x:json.dumps(x,separators=(',',':'),ensure_ascii=False)
failmsg='WFT-CURRENT-QUERY-REFINEMENT: Conditional current-query refinement refused'
checks=[]; failures=[]
def record(label,ok,detail=None):
 r={'id':label,'passed':bool(ok)}
 if detail is not None:r['detail']=detail
 checks.append(r)
 if not ok:failures.append(r)
def positive(label,fn,predicate=lambda x:bool(x)):
 try:
  value=fn();record(label,predicate(value))
 except Exception as e:record(label,False,type(e).__name__+': '+str(e)[:350])
def refused(label,fn,uniform=False):
 try:
  v=fn();record(label,False,{'unexpectedSuccess':str(v)[:350]})
 except (ValueError,TypeError,AttributeError,UnicodeError,pickle.PicklingError)as e:
  record(label,(not uniform or (type(e)is ValueError and str(e)==failmsg)) and 'PRIVATE-SENTINEL'not in str(e),{'exception':type(e).__name__,'message':str(e)[:250]})
 except Exception as e:record(label,False,type(e).__name__+': '+str(e)[:350])
def pins():
 native=pathlib.Path(importlib.import_module('weft.weft').__file__);shim=pathlib.Path(weft.__file__)
 with zipfile.ZipFile(a.wheel)as z:
  names=[n for n in z.namelist() if n.endswith(('.so','.pyd'))];assert len(names)==1
  assert z.read(names[0])==native.read_bytes() and z.read('weft/__init__.py')==shim.read_bytes()
 return dict(wheelPath=str(a.wheel),wheelSha256=sha(a.wheel.read_bytes()),nativePath=str(native),nativeSha256=sha(native.read_bytes()),shimPath=str(shim),shimSha256=sha(shim.read_bytes()))
before=pins();vs=json.loads(a.vectors.read_text())['vectors'];chosen=[vs[0],vs[4],vs[11]]
# Real producers yield new object identities, retain exact source and report bytes.
for v in vs:
 parent=weft.prepare_application_lineage(v['request']);child=parent.prepare_current_query();tag=v['id']
 positive(tag+'/source-custody',lambda:child.source_preparation()is parent and parent.source_request_json()==v['request'])
 positive(tag+'/native-report-bytes',lambda:child.designation_json()==v['designation'] and child.native_request_json()==v['nativeRequest'])
 for raw in [parent.json(),child.designation_json(),child.native_request_json()]:
  r=json.loads(raw);positive(tag+'/no-authority/'+r['version'],lambda r=r:r['authority']is False and r['securityReady']is False)
 suffix=v['backend']+'_bounded_current_'+v['kind']+'_candidate_json'
 if a.mode=='bounded':
  positive(tag+'/lower-bytes',lambda:getattr(child,'lower_'+suffix)(v['binding']),lambda x:x==v['artifact'])
  positive(tag+'/checker-bytes',lambda:getattr(child,'check_'+suffix)(v['binding'],v['input']),lambda x:x==v['report'])
 else:
  for prefix in ['lower_','check_']:positive(tag+'/'+prefix+'not-exported',lambda prefix=prefix:not hasattr(child,prefix+suffix))
 # New contexts cannot enter ANY pre-existing physical lowerer/checker API.
 for name in ['postgresql_scalar','postgresql_current_rows','postgresql_current_contributors','postgresql_current_sum','databricks_current_contributors','databricks_current_sum']:
  refused(tag+'/old-lowerer/'+name,lambda name=name:getattr(child,'lower_'+name+'_candidate_json')(v['binding']))
  check='check_'+name+'_candidate_json'
  if hasattr(child,check):refused(tag+'/old-checker/'+name,lambda check=check:getattr(child,check)(v['binding'],v['input']),True)
# Reports / packets / artifacts cannot be reimported as issued producer state.
v=vs[0];parent=weft.prepare_application_lineage(v['request']);child=parent.prepare_current_query()
for label,raw in [('lineage',parent.json()),('designation',child.designation_json()),('native',child.native_request_json()),('artifact',v['artifact']),('result',v['report'])]:
 refused('import-report/'+label,lambda raw=raw:weft.prepare_application_lineage(raw))
 for name in ['compile_json','compile_truss_runtime_json']:
  positive('old-json-route/'+name+'/'+label,lambda name=name,raw=raw:json.loads(getattr(weft,name)(raw)),lambda x:x.get('status')!='compiled' and x.get('sql')is None)
for cls,obj in [(weft.ApplicationLineagePreparation,parent),(weft.CurrentQueryPreparation,child)]:
 tag=cls.__name__
 for i,args in enumerate([(),('{}',),(parent,),({'inner':{}},)]):refused(tag+'/constructor/'+str(i),lambda cls=cls,args=args:cls(*args))
 refused(tag+'/object-new',lambda cls=cls:object.__new__(cls))
 refused(tag+'/subclass',lambda cls=cls:type('Forged',(cls,),{}))
 for f in [copy.copy,copy.deepcopy,pickle.dumps]:refused(tag+'/'+f.__name__,lambda f=f,obj=obj:f(obj))
 refused(tag+'/dict',lambda obj=obj:getattr(obj,'__dict__'))
 for name,value in [('inner',{}),('original',parent),('source_preparation',lambda:parent),('designation_json',lambda:'{}')]:refused(tag+'/set-'+name,lambda obj=obj,name=name,value=value:setattr(obj,name,value))
for arg in ['{}',{},parent,None]:refused('factory-extra-argument/'+type(arg).__name__,lambda arg=arg:parent.prepare_current_query(arg))
refused('factory-mode',lambda:parent.prepare_current_query(mode='original-authorized'))
other=weft.prepare_application_lineage(v['request']);other_child=other.prepare_current_query()
positive('identical-bytes-distinct-custody',lambda:other is not parent and other_child.source_preparation()is other and child.source_preparation()is parent)
parent_id=id(parent);del parent;gc.collect();positive('parent-retained-after-gc',lambda:id(child.source_preparation())==parent_id)
class Str(str):pass
class Poison:
 def __str__(self):raise RuntimeError('PRIVATE-SENTINEL coercion invoked')
if a.mode=='bounded':
 for v in chosen:
  parent=weft.prepare_application_lineage(v['request']);child=parent.prepare_current_query();tag=v['id'];suffix=v['backend']+'_bounded_current_'+v['kind']+'_candidate_json';lower=getattr(child,'lower_'+suffix);check=getattr(child,'check_'+suffix)
  for name in ['lower_'+suffix,'check_'+suffix]:
   for i,receiver in enumerate([None,{},v['designation'],parent,object()]):
    args=(v['binding'],) if name.startswith('lower_') else(v['binding'],v['input'])
    refused(tag+'/native-receiver/'+name+'/'+str(i),lambda name=name,receiver=receiver,args=args:getattr(weft.CurrentQueryPreparation,name)(receiver,*args))
  for label,bad in [('null',None),('dict',{}),('array',[]),('bytes',b'{}'),('bytearray',bytearray(b'{}')),('object',Poison()),('str-subclass',Str(v['binding'])),('surrogate','\ud800'),('malformed','{PRIVATE-SENTINEL'),('oversize-ascii',' '*4_000_001),('oversize-utf8','😀'*1_000_001)]:
   refused(tag+'/lower-input/'+label,lambda bad=bad:lower(bad),True)
   refused(tag+'/checker-binding/'+label,lambda bad=bad:check(bad,v['input']),True)
  for label,bad in [('null',None),('dict',{}),('bytes',b'{}'),('object',Poison()),('str-subclass',Str(v['input'])),('surrogate','\udfff'),('malformed','{PRIVATE-SENTINEL'),('oversize-ascii',' '*16_777_217),('oversize-utf8','😀'*4_194_305)]:refused(tag+'/checker-input/'+label,lambda bad=bad:check(v['binding'],bad),True)
  for which in ['binding','input']:
   original=json.loads(v[which])
   mutations=[]
   for key in ['authority','securityReady','matched','nativeAdmission','sourceRequestJson','currentQueryContext']:
    x=copy.deepcopy(original);x[key]=True if key in ['authority','securityReady','matched']else 'PRIVATE-SENTINEL';mutations.append(('unknown-'+key,x))
   for cap in [None,[],['bounded-unicode-scalars','bounded-unicode-scalars'],['live-original-integer-sum'],['bounded-unicode-scalars','live-original-integer-sum']]:
    x=copy.deepcopy(original);x['capabilities']=cap;mutations.append(('capability-'+repr(cap),x))
   x=copy.deepcopy(original);x.pop('capabilities');mutations.append(('capability-absent',x))
   for key in ['sourceRequestSha256','designationSha256']+(['sourceBindingSha256']if which=='binding'else['materializationBindingSha256','compiledArtifactSha256']):
    x=copy.deepcopy(original);x[key]='0'*64;mutations.append(('pin-'+key,x))
   x=copy.deepcopy(original);x['version']=('weft.'+v['backend']+'.current-values/'+('0.2'if v['backend']=='postgresql'else'0.1')+'-candidate')if which=='binding'else'weft.current-query.refinement-input/0.1-candidate';mutations.append(('old-version',x))
   for label,x in mutations:
    raw=text(x);refused(tag+'/'+which+'/'+label,lambda raw=raw,which=which:lower(raw)if which=='binding'else check(v['binding'],raw),True)
   dup=v[which][:-1]+',"capabilities":["bounded-unicode-scalars"]}'
   refused(tag+'/'+which+'/duplicate-property',lambda dup=dup,which=which:lower(dup)if which=='binding'else check(v['binding'],dup),True)
  # Source hash remains relevant even for source text that denotes the same query.
  foreign=weft.prepare_application_lineage(v['request']+' ').prepare_current_query()
  refused(tag+'/different-source-bytes-binding',lambda:getattr(foreign,'lower_'+suffix)(v['binding']),True)
  refused(tag+'/different-source-bytes-frame',lambda:getattr(foreign,'check_'+suffix)(v['binding'],v['input']),True)
  for foreign_v in [x for x in chosen if x['id']!=v['id']]:
   refused(tag+'/foreign-backend-or-kind-frame/'+foreign_v['id'],lambda foreign_v=foreign_v:check(v['binding'],foreign_v['input']),True)
  # Python class overrides do not change the saved native descriptor's issuer checks.
  cls=weft.CurrentQueryPreparation;method='source_preparation';old=getattr(cls,method)
  try:setattr(cls,method,lambda self:other)
  except (TypeError,AttributeError):record(tag+'/class-override-refused',True)
  else:
   try:positive(tag+'/native-lower-ignores-python-source-override',lambda:lower(v['binding']),lambda x:x==v['artifact'])
   finally:setattr(cls,method,old)
 # Both legacy declaration profiles remain incapable of the bounded physical API,
 # even if a caller recomputes all source/designation/binding pins correctly.
 for filename in ['disclosed-token-equality','live-original-integer-sum']:
  raw=(a.source/'tests/current-query-designation/fixtures'/f'{filename}.request.json').read_text();old_child=weft.prepare_application_lineage(raw).prepare_current_query();packet=json.loads(old_child.native_request_json())
  for v in chosen:
   b=json.loads(v['binding']);b.update(sourceRequestSha256=packet['sourceRequestSha256'],designationSha256=packet['designationSha256'],sourceBindingSha256=packet['binding']['sha256'])
   suffix=v['backend']+'_bounded_current_'+v['kind']+'_candidate_json'
   refused('old-profile-new-api/'+filename+'/'+v['id'],lambda old_child=old_child,b=b,suffix=suffix:getattr(old_child,'lower_'+suffix)(text(b)),True)
# Legacy same-parent designation reports are byte-preserved in both installed builds.
for stem in ['disclosed-token-equality','original-token-order','mixed-original-uses','live-original-integer-sum']:
 root=a.source/'tests/current-query-designation/fixtures';obj=weft.prepare_application_lineage((root/(stem+'.request.json')).read_text()).prepare_current_query()
 positive('retained-legacy-designation/'+stem,lambda obj=obj,stem=stem:obj.designation_json()==(root/(stem+'.report.json')).read_text())
after=pins();record('artifact-pins-stable',before==after)
result=dict(scope='Independent installed Python/Rust extension compiler bridge boundary controls. Declared fixture cells only; no native database/security acceptance.',mode=a.mode,python=sys.version,version=weft.__version__,pinsBefore=before,pinsAfter=after,inputs={'vectorsSha256':sha(a.vectors.read_bytes()),'probeSha256':sha(pathlib.Path(__file__).read_bytes())},controls=len(checks),failures=failures,checks=checks)
a.output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(json.dumps({'mode':a.mode,'controls':len(checks),'failures':failures},ensure_ascii=False));sys.exit(bool(failures))
