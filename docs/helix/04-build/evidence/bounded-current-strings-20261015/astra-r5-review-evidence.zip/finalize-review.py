import pathlib,json,hashlib
r=pathlib.Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def pin(p):p=pathlib.Path(p);return {'path':str(p),'sha256':sha(p)}
v=json.loads((r/'source-verification.json').read_text());a=json.loads((r/'evidence-audit.json').read_text());child=json.loads((r/'runtime-review/review.json').read_text());b=json.loads((r/'browser-controls.json').read_text())
for f in ['bounded-controls.json','standard-controls.json']:
 j=json.loads((r/'runtime-review'/f).read_text());assert not j['failures'] and j['pinsBefore']==j['pinsAfter'] and all(c['passed'] for c in j['checks'])
for f in ['bounded-facetless.json','standard-facetless.json']:
 j=json.loads((r/'runtime-review'/f).read_text());assert all(c['passed'] for c in j['checks'])
assert all(c['passed']for mode in b['modes']for c in mode['controls'])
report={
 'review':'Independent Astra Ultra review of bounded Unicode String R5 compiler/runtime/Python/WASM component',
 'date':'2026-10-16',
 'verdict':'No actionable finding in the exact reviewed component; no native security, backend admission, formal-proof, platform-release or publication approval.',
 'remainingFindings':[],
 'scope':{
  'baseCommit':v['base'],'sourcePacket':pin('/private/tmp/weft-bounded-string-r5-source-review-20261016.zip'),'frozenCheckout':'/private/tmp/weft-bounded-string-r5-frozen-20261016',
  'selectedInputs':1157,'manifest':pin(r/'source/snapshot-manifest.json'),'selectedChangedFiles':v['changedFiles'],'selectedChangedFileCount':34,
  'governanceSupplement':pin('/private/tmp/weft-bounded-r5-governance-supplement-20261016.zip'),
  'additionalChangedFiles':['docs/helix/02-design/technical-designs/TD-009-security-compilation.md','docs/helix/03-test/test-plans/STP-009-security-compilation.md'],'totalReviewedChangedFiles':36,
  'patch':pin(r/'source.patch'),'sourceVerification':pin(r/'source-verification.json'),'sourceAfterReview':pin(r/'source-after-review.json'),
  'governance':'AGENTS, .helix.yml and HELIX index read/retained at canonical base; CONTRACT-011 and its CONTRACT-004/010 dependencies, frozen TD-009/STP-009, and original fixtures govern this component. The supplement is separate from the 1157 compiled/test input capture.',
  'repositoryEdits':False,'sdkVersionChanged':False
 },
 'analysis':[
  {'area':'Merged catalog and resolver closure','conclusion':'Bounded Catalog flag remains explicit and defaults false; original 0.1/0.2 factories and ordinary/exact/page resolver routes pass false. Both Registry implementations refuse bounded catalogs before backend lowering. The existing name-fallback flag remains independently false in ordinary/security catalog preparation; reconciled Decimal/name-fallback registration is preserved.'},
  {'area':'Shared bound, value and literal semantics','conclusion':'Nine central semantic files are byte-identical to the reviewed R3 component, including exact numeric parsing, Unicode-scalar domains, lineage/designation/operands, refinement, registry guards and PostgreSQL lowerer. Exact bounds remain mathematical JSON integers through the safe endpoint, with decimal/exponent/negative-zero equivalence; no f64 or maximum-sized allocation. Original literals retain their original value/type and are checked against their own domain, while effective cells use their selected domain. Prior R3 controls are historical evidence carried forward by exact source equality, not represented as fresh R5 replays.','pins':pin(r/'unchanged-semantic-components.json')},
  {'area':'All-cell preflight','conclusion':'Captured cells pass scalar validation before being stored in the evaluator; bounded public cells pass complete shape/type/domain validation before Eval::derive at current_query_refinement.rs:750. Thus FALSE/LIMIT0 cannot suppress this validation. New browser controls independently reject invalid supplied eligible cells across all18 vectors, including the FALSE/LIMIT0 vectors; source inspection establishes the validation order.'},
  {'area':'Backend reconciliation','conclusion':'Databricks target selection and bounded-context selection are checked together; Spark target rejects bounded contexts. PostgreSQL and Databricks bindings retain their explicit versions/capability lists and distinct bounded artifacts. Existing Spark/Decimal/reporting paths were not implicitly upgraded. Physical SQL emission and declared-cell comparisons are compiler evidence, not validation of a live PostgreSQL/Databricks/Spark installation.'},
  {'area':'Issued preparation objects','conclusion':'Python/runtime and WASM object APIs retain actual original preparations; child context derivation reconstructs from retained originals. Private Rust fields and native descriptors govern lower/check methods. JSON reports/native-request summaries cannot replace an issued source object. Python copying/serialization/subclass/mutation/foreign-receiver controls and WASM source-custody/lifetime controls passed. Identical source bytes prepared twice remain distinct parent identities.'},
  {'area':'Unicode host boundaries','conclusion':'WASM guarded source, binding and checker inputs are JsString/externref values until Rust strict_text verifies primitive-string type, every UTF16 unit pairing and checked UTF8 byte budget; conversion follows validation. Existing security source methods preserve their JSON refusal channel. Python strict bounded-method conversion rejects non-exact strings, malformed Unicode and frame limits through uniform private diagnostics. The review does not treat a hostile JavaScript realm with arbitrary access to the module memory/prototype machinery as a separate security principal.'},
  {'area':'Feature closure','conclusion':'The public wheel baseline remains the four declared pyproject features, with bounded added only to the candidate build. The standard wheel retains legacy APIs but lacks all new bounded methods. Standard WASM exposes source inspection only, with no new issued-object exports. Valid repinned facetless String and signed64-only vectors demonstrate context-wide old/new closure independently of bounded selected facets.'},
  {'area':'Scope and documentation','conclusion':'CONTRACT-011 and the supplemental TD/STP retain nullable/absent/withheld Token, native constraints/completeness, authorization and guarded release as unresolved host/native obligations. No P03/L03/security case or complete acceptance criterion is promoted.'}
 ],
 'independentlyExecuted':{
  'totalControls':1593,'countMeaning':'Executable assertions/control observations, not independent requirements, formal theorems or native backend cases.',
  'chromiumWasm':{'bounded':398,'standard':93,'total':491,'browser':'151.0.7922.34','playwright':'1.62.1','receipt':pin(r/'browser-controls.json'),'execution':pin(r/'browser-execution.json'),'script':pin(r/'browser-controls.ts'),'scope':'Actual local Chromium initialized the pinned original frozen R5 candidate and standard WASM; raw/escaped invalid UTF16, scalar positives, primitive-only/no coercion, byte limits, legacy JSON refusal, lower/check arguments, captured cell domain, source-custody and lifetime.'},
  'pythonRustExtension':{'boundedMain':628,'standardMain':379,'boundedFacetlessOrSigned64':26,'standardFacetlessOrSigned64':20,'total':1053,'receipts':[pin(r/'runtime-review'/p) for p in ['bounded-controls.json','standard-controls.json','bounded-facetless.json','standard-facetless.json']],'scope':'Fresh calls to both pinned installed local ARM64 native extensions, actual public producers and methods; declared fixture cells only, no database.'},
  'cargoAndStaticRetention':{'total':49,'receipt':pin(r/'runtime-review/feature-controls/report.json'),'scope':'Resolved Python default/standard/bounded/Spark feature graphs and byte retention, not executed native backend behavior.'},
  'childReview':pin(r/'runtime-review/review.json')
 },
 'suppliedEvidenceIndependentlyAudited':{
  'originalCohort':pin(r/'evidence-audit.json'),'inputMapMatchesFrozenExactly':True,'executions':26,'allExitCodesZero':True,
  'bounded':{'nativeExtensionControls':265,'vectors':18,'browserControls':252,'legacyRefinement':30,'legacyQueryAbi':17,'designationBridge':'passed'},
  'standard':{'nativeExtensionControls':54,'browserControls':51,'legacyRefinement':30,'legacyQueryAbi':17,'designationBridge':'passed'},
  'fullCore':{'passed':348,'independentlyRerun':False,'receiptAndLog':a['core']},
  'scalarSuites':{'databricksIncludingSpark':14,'postgresql':19,'independentlyRerun':False,'log':a['scalarLog'],'qualification':'Supplied compiler test log; not a separate independently reproduced source-bound cohort.'},
  'artifactCustody':'Both wheel archives match installed extension/shim bytes; raw and bindgen WASM/JS/type declaration hashes match receipt; browser packets match native-vector hashes; supplied observation IDs unique and source inputs unchanged.',
  'laterCommittedOverlay':{'commit':'a853a5bcfe2edc3a4c63c0cb8fcc01593fd4ec68','audit':pin(r/'final-overlay-audit.json'),'qualification':'Separate supplied replay has26 successful commands and1157 unchanged selected inputs; only tests/truss-decimal12/wheel-smoke.py differs from the original source capture, exactly matching the independently reviewed22-case naming-gate source. Actual wheels and WASM pins verified. Later22-case Decimal receipts and15 gate controls retained; the independent491 browser controls and1053 Python controls above used the original frozen R5 artifacts.'}
 },
 'limitations':[
  'Tests and source inspection are empirical component evidence, not a formal logical proof or a completeness guarantee.',
  'No native PostgreSQL/Databricks/Spark query, installation/OID/ACL check, actor/source authorization, disclosure transform, nullable Token behavior, bypass-barrier campaign or guarded public release was exercised by this review.',
  'Single local ARM64 wheel environment and one actual Chromium version; no five-wheel release cohort or publication approval.',
  'Original R1/R2/R3 reports and earlier failed/superseded R4 work remain unchanged. No exploratory or failed cohort is promoted to current passing evidence.',
  'Full backend integration campaign still in progress at review cutoff is not credited here; this report does not depend on its completion.',
  'The selected1157-input capture is not a hermetic capture of the entire host/toolchain. Exact tool versions and relevant artifact/package hashes are recorded, but no claim is made that every external tool input is frozen.'
 ],
 'reviewHistory':{'R1':pin('/private/tmp/weft-bounded-string-r1-astra-20261015/review.json'),'R2':pin('/private/tmp/weft-bounded-string-r2-astra-20261015/review.json'),'R3':pin('/private/tmp/weft-bounded-string-r3-astra-20261015/review.json')}
}
(r/'review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'report':str(r/'review.json'),'sha256':sha(r/'review.json'),'independentControls':1593,'remainingFindings':[]},indent=2))
