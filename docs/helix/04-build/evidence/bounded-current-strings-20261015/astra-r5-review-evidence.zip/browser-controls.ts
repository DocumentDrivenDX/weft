import {createHash} from 'node:crypto';
const root='/private/tmp/weft-bounded-string-r5-astra-20261016',cohort='/private/tmp/weft-bounded-r5-bridge-cohort-20261016';
const {chromium}=await import('/Users/erik/Projects/weft/node_modules/playwright/index.mjs');
const packet=JSON.parse(await Bun.file(cohort+'/native-vectors.json').text());
const out:any={scope:'Independent actual Chromium/WASM bridge controls against pinned R5 artifacts. Compiler and declared-cell checker only; no database execution or authority.',modes:[]};
for(const mode of ['bounded','standard']){
 const web=cohort+'/'+mode+'-web',js=await Bun.file(web+'/weft_wasm.js').arrayBuffer(),wasm=await Bun.file(web+'/weft_wasm_bg.wasm').arrayBuffer();
 const browser=await chromium.launch({headless:true});
 try{
  const page=await browser.newPage(),origin='http://independent.weft.test',errors:any[]=[];page.on('pageerror',(e:any)=>errors.push(String(e)));
  await page.route('**/*',(route:any)=>{const u=new URL(route.request().url());if(u.origin!==origin)return route.abort();const file=u.pathname==='/'?null:u.pathname==='/weft.js'?js:u.pathname==='/weft_wasm_bg.wasm'?wasm:undefined;if(file===undefined)return route.abort();return route.fulfill({contentType:file===null?'text/html':u.pathname.endsWith('.js')?'text/javascript':'application/wasm',body:file===null?'<!doctype html>':Buffer.from(file)});});
  await page.goto(origin);
  const controls=await page.evaluate(async({origin,mode,vectors}:any)=>{
   const api=await import(origin+'/weft.js');await api.default({module_or_path:origin+'/weft_wasm_bg.wasm'});const controls:any[]=[];
   function check(id:string,passed:any){if(!passed)throw Error(id);controls.push({id,passed:true});}
   function refuses(id:string,fn:()=>any,code?:string){let caught:any;try{fn()}catch(e){caught=e}check(id,caught!==undefined&&(!code||String(caught).startsWith(code))&&!String(caught).includes('PRIVATE-SENTINEL'));}
   const base=vectors[0].request;check('baseline-contains-actual-supplementary',base.includes('"value":"😀"'));
   const fresh=(v:string)=>base.replace('"value":"😀"','"value":"'+v+'"');
   const names=['prepare_application_lineage_json','prepare_current_query_designations_json',...(mode==='bounded'?['prepare_application_lineage']:[])];
   for(const name of names){
    let conversions=0;
    const fake={toString(){conversions++;return base},valueOf(){conversions++;return base},[Symbol.toPrimitive](){conversions++;return base}};
    for(const [label,value] of [['undefined',undefined],['null',null],['boolean',true],['bigint',1n],['symbol',Symbol('private')],['number',NaN],['boxed',new String(base)],['fake',fake],['array',[base]],['proxy',new Proxy(fake,{get(){conversions++;throw Error('coercion')}})]] as const)refuses(name+'/primitive-only/'+label,()=>api[name](value),'WFT-CURRENT-QUERY-TEXT:');
    check(name+'/no-coercion',conversions===0);
    for(const [i,value] of ['\ud800','\udfff','\ud800a','a\udc00','\ud800\ud800','\udc00\udc00','\udc00\ud800','😀\ud800','\ud800😀','\udbff\udfff\ud800'].entries())refuses(name+'/raw-invalid-'+i,()=>api[name](fresh(value)),'WFT-CURRENT-QUERY-TEXT:');
    for(const [i,value] of ['\\ud800','\\udfff','\\ud800a','\\udc00\\ud800'].entries())refuses(name+'/escaped-invalid-'+i,()=>api[name](fresh(value)));
    for(const [i,value] of ['😀','\ud800\udc00','\udbff\udfff','e\u0301','\ufffd','\\ud83d\\ude00'].entries()){const p=api[name](fresh(value));check(name+'/valid-scalar-'+i,!!p);if(p?.free)p.free();}
    for(const [label,value] of [['ASCII',' '.repeat(4_000_001)],['BMP2','é'.repeat(2_000_001)],['BMP3','€'.repeat(1_333_334)],['supplementary','😀'.repeat(1_000_001)]])refuses(name+'/byte-budget/'+label,()=>api[name](value),'WFT-CURRENT-QUERY-TEXT:');
   }
   for(const name of ['prepare_security_mapping_json','inspect_security_mapping_subject_key_json']){
    for(const [i,v] of [undefined,null,42,new String(base),'\ud800','\udc00','€'.repeat(1_333_334)].entries()){
     const r=JSON.parse(api[name](v,'{}'));check(name+'/JSON-channel/'+i,r.status==='refused'&&r.securityReady===false&&!('handoff'in r));
    }
   }
   for(const [i,v]of [null,undefined,{},new String('{}'),'\ud800','€'.repeat(5462)].entries()){const r=JSON.parse(api.inspect_security_mapping_subject_key_json(base,v));check('selection-JSON-refusal/'+i,r.status==='refused'&&r.securityReady===false);}
   if(mode==='standard'){
    check('no-bounded-object-exports',!Object.keys(api).some(k=>/bounded|CurrentQueryPreparation|ApplicationLineagePreparation|^prepare_application_lineage$/.test(k)));
   }else{
    for(const v of vectors){
     const p=api.prepare_application_lineage(v.request),q=p.prepare_current_query(),suffix=v.backend+'_bounded_current_'+v.kind+'_candidate_json',lower='lower_'+suffix,verify='check_'+suffix;
     const again=p.prepare_current_query();check(v.id+'/same-issued-parent',again.is_from(p));again.free();
     check(v.id+'/positive-control',q[verify](v.binding,v.input)===v.report);
     for(const [i,bad] of [undefined,null,{},new String(v.input),'\ud800','\udc00','😀\ud800'].entries())refuses(v.id+'/checker-input-strict/'+i,()=>q[verify](v.binding,bad),'WFT-CURRENT-QUERY-TEXT:');
     for(const [i,bad] of ['\ud800','\udc00',new String(v.binding)].entries())refuses(v.id+'/checker-binding-strict/'+i,()=>q[verify](bad,v.input),'WFT-CURRENT-QUERY-TEXT:');
     const frame=JSON.parse(v.input);for(const r of frame.scans[0].rows)for(const cell of Object.values(r.cells) as any[])if(cell.family==='string')cell.value='PRIVATE-SENTINEL'+'😀'.repeat(65);
     refuses(v.id+'/all-captured-cell-domain',()=>q[verify](v.binding,JSON.stringify(frame)));
     refuses(v.id+'/JSON-source-object-forgery',()=>q.is_from(JSON.parse(p.json())));
     p.free();check(v.id+'/child-owned-lifetime',q[lower](v.binding)===v.artifact);q.free();
    }
    const p=api.prepare_application_lineage(base),q=p.prepare_current_query(),v=vectors[0],method='check_'+v.backend+'_bounded_current_'+v.kind+'_candidate_json';
    refuses('checker-UTF8-framing-limit',()=>q[method](v.binding,'€'.repeat(5_592_406)),'WFT-CURRENT-QUERY-TEXT:');q.free();p.free();
   }
   check('unique-control-ids',new Set(controls.map(c=>c.id)).size===controls.length);
   return controls;
  },{origin,mode,vectors:packet.vectors});
  if(errors.length)throw Error(JSON.stringify(errors));out.modes.push({mode,browser:browser.version(),jsSha256:createHash('sha256').update(new Uint8Array(js)).digest('hex'),wasmSha256:createHash('sha256').update(new Uint8Array(wasm)).digest('hex'),controls});
 }finally{await browser.close();}
}
out.packetSha256=createHash('sha256').update(await Bun.file(cohort+'/native-vectors.json').text()).digest('hex');await Bun.write(root+'/browser-controls.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out.modes.map(m=>({mode:m.mode,count:m.controls.length,browser:m.browser}))));
