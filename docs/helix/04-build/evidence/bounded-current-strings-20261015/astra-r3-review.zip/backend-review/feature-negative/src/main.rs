fn main() {
 let _ = weft_postgresql::current_scalar::lower_bounded_rows;
 let _ = weft_postgresql::current_scalar::lower_bounded_contributors;
 let _ = weft_postgresql::current_scalar::check_bounded_rows;
 let _ = weft_postgresql::current_scalar::check_bounded_contributors;
 let _ = weft_databricks::current_scalar::lower_bounded_contributors;
 let _ = weft_databricks::current_scalar::check_bounded_contributors;
}
