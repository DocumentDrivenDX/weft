"""Run source-pinned backend controls and record exact frozen-source custody.
Synthetic compiler/checker inputs only: no native database, transport or publication.
"""
import hashlib,json,os,pathlib,subprocess,sys
OUT=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('/private/tmp/weft-bounded-string-r3-frozen-20261015')
ZIP=pathlib.Path('/private/tmp/weft-bounded-string-r3-compiler-review-20261015.zip')
manifest=json.loads((OUT/'manifest.json').read_text())
def hashes():return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in manifest['files']}
before=hashes();assert before==manifest['files']
env=dict(os.environ,CARGO_HOME='/private/tmp/weft-toolchain/cargo',RUSTUP_HOME='/private/tmp/weft-toolchain/rustup')
cargo='/private/tmp/weft-toolchain/cargo/bin/cargo'
cmd=[cargo,'+1.90.0','run','--locked','--offline','--manifest-path','Cargo.toml','--target-dir','target']
r=subprocess.run(cmd,cwd=OUT,env=env,capture_output=True,text=True)
(OUT/'stdout.json').write_text(r.stdout);(OUT/'stderr.log').write_text(r.stderr)
result=json.loads(r.stdout) if r.stdout.strip() else {}
negative=(OUT/'feature-negative.stderr').read_text()
feature_errors=negative.count('error[E0425]')
receipt={'scope':__doc__,'zipSha256':hashlib.sha256(ZIP.read_bytes()).hexdigest(),'base':manifest['base'],'sourceHashesBefore':before,'sourceHashesAfter':hashes(),'sourceHashesUnchanged':hashes()==before,'command':cmd,'exitCode':r.returncode,'controls':result.get('controls'),'passed':result.get('passed'),'failures':result.get('failures'),'accepted':sum(x['accepted'] for x in result.get('results',[])),'refused':sum(not x['accepted'] for x in result.get('results',[])), 'featureDisabledProbe':{'command':[cargo,'+1.90.0','check','--offline','--manifest-path','feature-negative/Cargo.toml','--target-dir','target'],'exitCode':101,'expectedMissingSymbols':6,'observedE0425Errors':feature_errors},'reviewerFixtureCorrection':'Initial run expected an unqualified PG C collation string; actual source correctly uses COLLATE pg_catalog."C". Corrected only reviewer assertion; attempt1 source/log retained.', 'artifactHashes':{str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.rglob('*')) if p.is_file() and 'target' not in p.relative_to(OUT).parts and p.name not in ['execution.json','review.json']}}
(OUT/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['exitCode','controls','passed','failures','accepted','refused','sourceHashesUnchanged','featureDisabledProbe']},indent=2))
assert r.returncode==0 and result['failures']==0 and feature_errors==6 and receipt['sourceHashesUnchanged']
