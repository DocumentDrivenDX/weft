use serde_json::{Value,json};
use std::io::{self,BufRead};
use weft_core::{application_lineage as lineage,current_query_designation as designation,current_query_operands as operands,json::sha256};
fn binding(g:&operands::CurrentQueryOperands<'_>,backend:&str,version:&str)->Value{let d=g.designation();let p=d.preparation().plan();let keyed=backend=="db"||!version.ends_with("/0.1-candidate");let scans=std::iter::once(&p.source).chain(p.joins.iter().map(|j|&j.right)).map(|s|{let mut relation=json!({"schema":"private_stage","table":"current_values","eligibleColumn":"eligible"});if keyed{relation["rowKeyColumn"]=json!("__key")}if backend=="db"{relation["catalog"]=json!("client_dev");relation["uuid"]=json!("00000000-0000-4000-8000-000000000000");relation["version"]=json!("0");relation["schemaSha256"]=json!("b".repeat(64));}json!({"scan":s.occurrence,"target":s.record,"relation":relation})}).collect::<Vec<_>>();let mut values=vec![];for op in g.operations(){for operand in op.operands(){if let operands::Input::Field{scan,identity,original_action,..}=operand.input(){values.push(json!({"path":operand.path(),"scan":scan,"field":identity,"column":identity.element,"domain":identity,"comparisonScope":"a".repeat(64),"mode":if original_action.is_some(){"original-authorized"}else{"disclosed"},"originalAction":original_action,"exposure":null}));}}}for(i,o)in p.outputs.iter().enumerate(){if let weft_core::application_ir::Expression::Field{scan,identity}=&o.expression{values.push(json!({"path":format!("outputs/{i}/expression"),"scan":scan,"field":identity,"column":identity.element,"domain":identity,"comparisonScope":"a".repeat(64),"mode":null,"originalAction":null,"exposure":"original"}));}}json!({"version":version,"capabilities":["bounded-unicode-scalars"],"sourceRequestSha256":sha256(d.preparation().source_request_json().as_bytes()),"designationSha256":sha256(d.json().as_bytes()),"sourceBindingSha256":d.binding_scope().sha256,"scans":scans,"values":values})}

fn run(s:&Value)->Result<Value,String>{
 let r=&s["request"];let raw=r.to_string();
 let p=lineage::prepare(&raw).map_err(|e|format!("prepare:{}",e.code))?;
 let d=designation::derive(&p).map_err(|e|format!("designation:{}",e.code))?;
 let g=operands::derive(&d).map_err(|e|format!("operands:{}",e.code))?;
 let backend=s["backend"].as_str().unwrap();let rows=backend=="pg_rows";
 let mut b=binding(&g,if backend=="db"{"db"}else{"pg"},if backend=="db"{"weft.databricks.current-values/0.3-candidate"}else{"weft.postgresql.current-values/0.5-candidate"});
 if let Some(edits)=s["selections"].as_array(){for edit in edits {for v in b["values"].as_array_mut().unwrap(){
  if edit.get("scan").map_or(true,|scan|scan==&v["scan"])&&edit.get("path").map_or(true,|path|path==&v["path"]){
   if let Some(domain)=edit.get("domain"){v["domain"]["element"]=domain.clone();if v["exposure"]=="original"{v["exposure"]=json!("transformed");}}
   if let Some(column)=edit.get("column"){v["column"]=column.clone()}
   if let Some(scope)=edit.get("scope"){v["comparisonScope"]=scope.clone()}
  }
 }}}
 let br=b.to_string();
 let a=match backend {"pg_rows"=>weft_postgresql::current_scalar::lower_bounded_rows(&g,&br).map(|a|a.json()),"pg"=>weft_postgresql::current_scalar::lower_bounded_contributors(&g,&br).map(|a|a.json()),_=>weft_databricks::current_scalar::lower_bounded_contributors(&g,&br).map(|a|a.json())}.map_err(|e|format!("lower:{}",e.code))?;
 let mut f=json!({"version":"weft.current-query.refinement-input/0.2-candidate","capabilities":["bounded-unicode-scalars"],"sourceRequestSha256":sha256(raw.as_bytes()),"designationSha256":sha256(d.json().as_bytes()),"materializationBindingSha256":sha256(br.as_bytes()),"compiledArtifactSha256":sha256(a.to_string().as_bytes()),"scans":s["scans"],"resultRows":s["resultRows"]});
 if let Some(edits)=s["frameEdits"].as_object(){for (k,v)in edits {f[k]=v.clone();}}
 let fr=if let Some(raw_override)=s.get("rawOverride"){raw_override.as_str().unwrap().to_owned()}else{f.to_string()};
 let result=match backend {"pg_rows"=>weft_postgresql::current_scalar::check_bounded_rows(&g,&br,&fr),"pg"=>weft_postgresql::current_scalar::check_bounded_contributors(&g,&br,&fr),_=>weft_databricks::current_scalar::check_bounded_contributors(&g,&br,&fr)};
 let common=json!({"artifact":a,"binding":b,"frameSha256":sha256(fr.as_bytes()),"requestSha256":sha256(raw.as_bytes()),"rowsEncoding":rows});
 match result {Ok(report)=>Ok(json!({"accepted":true,"actual":common,"report":report})),Err(e)=>Ok(json!({"accepted":false,"stage":"check","code":e.code,"actual":common}))}
}
fn main(){for l in io::stdin().lock().lines(){let l=l.unwrap();let s:Value=serde_json::from_str(&l).unwrap();let result=match run(&s){Ok(v)=>v,Err(e)=>json!({"accepted":false,"error":e})};println!("{}",json!({"name":s["name"],"expectedAccepted":s["expected"],"matched":result["accepted"]==s["expected"],"result":result}));}}
