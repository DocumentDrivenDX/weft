import json, pathlib, copy, hashlib
P=pathlib.Path(__file__).parent
base=json.loads((P.parent/'reconstructed/tests/current-query-designation/fixtures/bounded-unicode-strings.request.json').read_text())
def compact(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'))
def request(sql='SELECT r.token FROM Resource r',needle=None,facets=None,nullable=False):
 r=copy.deepcopy(base);r['sql']=sql;r['parameters']={} if needle is None else {'needle':{'family':'string','value':needle}}
 if facets or nullable:
  m=r['modules'][0];d=json.loads(m['documentJson'])
  for e in d['modules'][0]['elements']:
   if facets and e['id'] in facets:e['facets']=facets[e['id']]
   if nullable and e['id']=='token':e['nullability']='nullable'
  m['documentJson']=compact(d);m['pin']['sha256']=hashlib.sha256(m['documentJson'].encode()).hexdigest()
  for s in r['opaqueSources']:
   if s['role']=='query-designation':
    p=json.loads(s['utf8']);p['modelPins']=[m['pin']];s['utf8']=compact(p);s['sha256']=hashlib.sha256(s['utf8'].encode()).hexdigest()
 return r
def bounds(lo,hi):return {'length':{'min':lo,'max':hi,'unit':'unicode-scalar'}}
def scans(values,scan='s0',column='token',family='string'):
 return {'scan':scan,'expectedRowCount':str(len(values)),'rows':[{'key':'k'+str(i),'cells':{column:{'family':family,'value':v}}} for i,v in enumerate(values)]}
def bag(backend,groups):
 if backend=='pg_rows':return compact({'version':'weft.stage-row-tuple/0.1-candidate','rows':groups[0]})
 return compact({'version':'weft.stage-contributor-bag/0.1-candidate','tuples':groups})
def carrier(backend,keys):return bag(backend,[[{'scan':'s0','key':'k'+str(i)}] for i in keys])
S=[]
def add(name,r,values,result=None,expected=True,edits=None,scanlist=None,mods=None,backends=('pg_rows','pg','db')):
 for b in backends:
  rows=([[v,carrier(b,[i])] for i,v in enumerate(values)] if result is None else result(b))
  s={'name':name+'.'+b,'backend':b,'request':r,'scans':scanlist if scanlist is not None else [scans(values)],'resultRows':rows,'expected':expected}
  if edits:s['selections']=edits
  if mods:mods(s)
  S.append(s)
for name,text,n in [('ascii','A',1),('supplementary','😀',1),('composed','é',1),('combining','e\u0301',2),('flag','🇺🇸',2),('zwj','👨\u200d👩\u200d👧\u200d👦',7),('crlf','\r\n',2),('nul','\0',1)]:
 for maxn in [n-1,n,n+1]:
  add(f'scalar_{name}_max{maxn}',request(facets={'token':bounds(0,maxn)}),[text],expected=maxn>=n)
add('empty_exact',request(facets={'token':bounds(0,0)}),[''])
add('safe_endpoint',request(facets={'token':bounds(0,9007199254740991)}),['😀'])
for sql,kind in [('SELECT r.token FROM Resource r WHERE FALSE','false'),('SELECT r.token FROM Resource r LIMIT 0','limit0'),('SELECT r.token FROM Resource r WHERE FALSE AND r.token=:needle LIMIT 0','false_and_limit0')]:
 r=request(sql,needle='😀' if ':needle' in sql else None)
 for value,name,ok in [('😀','valid',True),('','below_min',False),('😀'*65,'above_max',False)]:add(kind+'_'+name,r,[value],result=lambda b:[],expected=ok)
 for cell in [None,{'family':'string','value':None},{'family':'integer','value':'1'},{'family':'string','value':'😀','unknown':1}]:
  ss=scans(['😀']);ss['rows'][0]['cells']['token']=cell
  add(kind+'_malformed_'+str(len(S)),r,['😀'],result=lambda b:[],expected=False,scanlist=[ss])
add('normalization_not_collapsed',request('SELECT r.token FROM Resource r WHERE r.token=:needle','é'),['e\u0301'],result=lambda b:[])
add('transformed_empty_domain_literal_outside_effective',request('SELECT r.token FROM Resource r WHERE r.token=:needle','😀',{'salaryMaskLabel':bounds(0,0)}),[''],result=lambda b:[],edits=[{'domain':'salaryMaskLabel'}])
add('transformed_min2_literal_outside_effective',request('SELECT r.token FROM Resource r WHERE r.token=:needle','😀',{'salaryMaskLabel':bounds(2,10)}),['ab'],result=lambda b:[],edits=[{'domain':'salaryMaskLabel'}])
add('transformed_public_effective_empty',request(facets={'salaryMaskLabel':bounds(0,0)}),[''],edits=[{'domain':'salaryMaskLabel'}])
add('transformed_captured_still_effective_bounded',request('SELECT r.token FROM Resource r WHERE FALSE',facets={'salaryMaskLabel':bounds(2,10)}),['a'],result=lambda b:[],expected=False,edits=[{'domain':'salaryMaskLabel'}])
add('original_literal_below_min_not_healed_by_effective',request('SELECT r.token FROM Resource r WHERE r.token=:needle','😀',{'token':bounds(2,10),'salaryMaskLabel':bounds(0,64)}),['😀'],expected=False,edits=[{'domain':'salaryMaskLabel'}])
add('original_literal_above_max_not_healed',request('SELECT r.token FROM Resource r WHERE FALSE AND r.token=:needle LIMIT 0','ab',{'token':bounds(0,1),'salaryMaskLabel':bounds(0,64)}),['ab'],result=lambda b:[],expected=False,edits=[{'domain':'salaryMaskLabel'}])
for value in [None,'','😀'*65,7]:add('bad_public_'+str(len(S)),request(),['😀'],result=lambda b,v=value:[[v,carrier(b,[0])]],expected=False)
for facet in [None,[],{'length':{'min':0,'max':64,'unit':'byte'}},{'length':{'min':0,'max':64,'unit':'unicode-scalar','unknown':1}},{'length':{'min':0,'max':64.1,'unit':'unicode-scalar'}}]:
 add('invalid_effective_type_'+str(len(S)),request('SELECT r.token FROM Resource r WHERE FALSE LIMIT 0',facets={'salaryMaskLabel':facet}),['😀'],result=lambda b:[],expected=False,edits=[{'domain':'salaryMaskLabel'}])
add('nullable_original_refused',request(nullable=True),['😀'],expected=False)
for mask,scope,name,ok in [(bounds(1.0,64.0),False,'equivalent_decimals',True),(bounds(1,63),False,'different_bound',False),({},False,'facetless_vs_bounded',False),(bounds(1,64),True,'scope_mismatch',False)]:
 edits=[{'scan':'s1','domain':'salaryMaskLabel'}]
 if scope:edits.append({'scan':'s1','scope':'b'*64})
 r=request('SELECT r.token FROM Resource r JOIN Resource s ON r.token=s.token',facets={'salaryMaskLabel':mask})
 add('field_pair_'+name,r,['😀'],result=lambda b:[['😀',bag(b,[[{'scan':'s0','key':'k0'},{'scan':'s1','key':'k0'}]])]],scanlist=[scans(['😀']),scans(['😀'],'s1')],edits=edits,expected=ok)
for name,values in [('scalar_order',['\ue000','😀']),('byte_sensitive',['a','aa','é','e\u0301']),('unormalized',['é','e\u0301'])]:
 for direction in ['ASC','DESC']:
  ids=sorted(range(len(values)),key=lambda i:values[i],reverse=direction=='DESC')
  add('order_'+name+direction,request('SELECT r.token FROM Resource r ORDER BY r.token '+direction),values,result=lambda b,ids=ids,values=values:[[values[i],carrier(b,[i])] for i in ids])
for keys,public,name,ok in [([0,1,2],'2','valid_distinct_bag',True),([0,2],'2','distinct_cannot_dedup_bag',False),([0,1,1],'2','duplicate_wrong_contributor',False),([0,1,2],'3','bad_distinct_count',False)]:
 add(name,request('SELECT COUNT(DISTINCT r.token) AS n FROM Resource r'),['😀','😀','e\u0301'],result=lambda b,keys=keys,public=public:[[public,carrier(b,keys)]],expected=ok,backends=('pg','db'))
add('empty_global_count',request('SELECT COUNT(*) AS n FROM Resource r'),[],result=lambda b:[['0',carrier(b,[])]],backends=('pg','db'))
for size,ok in [(10000,True),(10001,False)]:add('row_bound_'+str(size),request('SELECT r.token FROM Resource r WHERE FALSE LIMIT 0'),['😀']*size,result=lambda b:[],expected=ok)
for name,mod in [('extra_column',lambda s:s['scans'][0]['rows'][0]['cells'].update({'extra':{'family':'string','value':'bad'}})),('missing_column',lambda s:s['scans'][0]['rows'][0]['cells'].clear()),('duplicate_key',lambda s:s['scans'][0]['rows'].append(copy.deepcopy(s['scans'][0]['rows'][0]))),('count_lexical',lambda s:s['scans'][0].update({'expectedRowCount':'01'}))]:
 add(name,request('SELECT r.token FROM Resource r WHERE FALSE LIMIT 0'),['😀'],result=lambda b:[],expected=False,mods=mod)
(P/'scenarios.jsonl').write_text(''.join(compact(s)+'\n' for s in S))
print('generated',len(S))
