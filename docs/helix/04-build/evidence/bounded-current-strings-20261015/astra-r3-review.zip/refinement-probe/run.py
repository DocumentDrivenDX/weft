import pathlib,json,hashlib,time,subprocess,shutil
p=pathlib.Path(__file__).parent;root=p.parent/'reconstructed'
inputs=json.loads((p.parent/'owner-evidence/core/execution.json').read_text())['sourceDigests']
def capture():return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in inputs}
before=capture();assert before==inputs
first=p/'initial-250-controls';first.mkdir(exist_ok=True)
for name in ['execution.json','stdout.jsonl','stderr']:
 if (p/name).exists() and not (first/name).exists():shutil.copy2(p/name,first/name)
start=time.monotonic();command=[str(p/'target/debug/bounded-refinement-probe')]
r=subprocess.run(command,input=(p/'scenarios.jsonl').read_bytes(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(p/'stdout.jsonl').write_bytes(r.stdout);(p/'stderr').write_bytes(r.stderr);after=capture()
results=[json.loads(l) for l in r.stdout.splitlines()];failed=[x['name'] for x in results if not x['matched']]
assert len(results)==sum(1 for _ in (p/'scenarios.jsonl').open())
d={'command':command,'exitCode':r.returncode,'elapsedSeconds':time.monotonic()-start,'controls':len(results),'unexpected':failed,'sourceDigests':before,'sourcesUnchanged':before==after,'reconstructedInputsMatchOwnerCapture':before==inputs,'pins':{str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [p/'src/main.rs',p/'Cargo.toml',p/'Cargo.lock',p/'generate.py',p/'run.py',p/'scenarios.jsonl',p/'stdout.jsonl',p/'stderr',p/'target/debug/bounded-refinement-probe']}}
(p/'execution.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:v for k,v in d.items() if k not in ['sourceDigests','pins']},indent=2))
assert r.returncode==0 and not failed and before==after
