from pathlib import Path
import json,hashlib
P=Path(__file__).parent;R=P/'reconstructed'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((P/'packet/manifest.json').read_text());recon=json.loads((P/'reconstruction.json').read_text())
owner=json.loads((P/'owner-evidence-verification.json').read_text());mine=json.loads((P/'refinement-probe/execution.json').read_text());sub=json.loads((P/'backend-review/review.json').read_text());artifact=json.loads((P/'refinement-probe/artifact-verification.json').read_text())
assert mine['controls']==250 and not mine['unexpected'] and mine['sourcesUnchanged'];assert sub['executedEvidence']['compilerAndAdapterControls']==306
assert all(not x['independentlyReconstructedInputMismatches'] for x in owner)
files=manifest['files'];assert all(sha(R/n)==h for n,h in files.items())
pins={}
for f in [P/'packet/manifest.json',P/'packet/change.patch',P/'reconstruction.json',P/'r2-to-r3.diff',P/'owner-evidence-verification.json',P/'backend-review/review.json',P/'backend-review/execution.json',P/'backend-review/stdout.json',P/'refinement-probe/execution.json',P/'refinement-probe/src/main.rs',P/'refinement-probe/generate.py',P/'refinement-probe/run.py',P/'refinement-probe/Cargo.toml',P/'refinement-probe/Cargo.lock',P/'refinement-probe/scenarios.jsonl',P/'refinement-probe/stdout.jsonl',P/'refinement-probe/artifact-verification.json']:
 pins[str(f.relative_to(P))]=sha(f)
report={
 'review':'Independent Astra Ultra review of frozen bounded String R3 compiler component',
 'date':'2026-10-15','verdict':'No actionable defect found in the frozen R3 compiler/checker component. Component review passed within the stated scope; no native, runtime, publication, backend-case or complete-criterion acceptance.',
 'remainingFindings':[],
 'source':{'zip':'/private/tmp/weft-bounded-string-r3-compiler-review-20261015.zip','zipSha256':recon['zipSha256'],'base':manifest['base'],'scope':manifest['scope'],'independentReconstruction':str(R),'parentFrozenRoot':'/private/tmp/weft-bounded-string-r3-frozen-20261015','manifestFileCount':len(files),'manifestPathsMatchIndependentReconstructionAndParentFrozenClone':True,'changedSourceDigests':files,'supplementalInputsRequired':[],'mutableOwnerCheckoutReviewed':False},
 'governingBasis':['AGENTS.md and .helix.yml in frozen Weft source; installed HELIX workflow','CONTRACT-004/010 source meaning and conditional relational refinement','CONTRACT-011 bounded Unicode domains, explicit profile selection, per-use custody and native boundary','US-009-AC3/AC4 via STP-009; no complete criterion closure'],
 'independentExecution':{
  'compilerAndCheckerControls':556,'passed':556,'accepted':123,'refused':433,
  'backendMatrix':{'controls':306,'accepted':20,'refused':286,'receipt':'backend-review/execution.json','report':'backend-review/review.json'},
  'domainRefinementMatrix':{'controls':250,'accepted':103,'refused':147,'receipt':'refinement-probe/execution.json','sourceInputsCapturedBeforeAndAfter':len(mine['sourceDigests']),'inputsUnchanged':mine['sourcesUnchanged'],'allInputDigestsMatchSuppliedSourceBoundSuite':True},
  'featureDisabledControl':{'newBackendSymbolsUnavailable':6,'compilerError':'E0425 with feature-gate notes','notIncludedIn556ControlCount':True},
  'registryDependencyDriftFromFrozenLockfile':[],
  'runtime':'Rust 1.90.0; offline locally compiled external probes against frozen/reconstructed path dependencies',
  'nativeExecutions':0,'browserExecutions':0,'pythonWheelExecutions':0,
  'coverage':[
   'PG binding 0.5 -> rows ABI 5 / contributors ABI 6; DBX binding/artifact 0.3; exact bounded capability metadata and explicit feature.',
   'All legacy lower/check APIs refuse bounded contexts including facetless bounded catalogs; lowerers also refuse field-free FALSE LIMIT 0 bounded contexts. Six old-profile positive controls pass.',
   'Missing/null/duplicate/unknown capabilities, versions, source/designation/binding pins, unknown authority fields, per-use selections and duplicate JSON members refuse.',
   'Actual lowering precedes adapter comparison. Exact binding bytes and derived artifact digest, report version/capabilities, fixed row/contributor encoding and private provenance bags are checked.',
   'ASCII, supplementary scalars, composed and combining text, regional flags, ZWJ sequences, CRLF and NUL distinguish scalar count from byte/code-unit/grapheme count. Empty exact domain and maximum safe declared bound remain bounded by actual input size.',
   'Captured cells outside bounds and wrong/null/unknown cell forms refuse with FALSE, LIMIT 0 and FALSE plus parameter predicate. Public null, too-short, too-long and non-string cells refuse.',
   'Original parameter domains remain distinct from selected effective cell/output domains: literal emoji in original length 1..64 compares unequal against an effective length 0..0 or 2..10 cell, while invalid original literals remain refused. Artifact metadata retains original parameter type/value and effective output domain exactly.',
   'Field-to-field comparison accepts semantically equivalent decimal-bound spellings and rejects differing bounds, facetless-versus-bounded domains and mismatched comparison scopes.',
   'Binary scalar ordering across BMP/supplementary and combining/composed strings; no normalization; COUNT DISTINCT keeps full contributor multiplicity. Wrong counts, omitted repeated contributors and wrong duplicate contributors refuse.',
   '10,000 complete captured rows pass under FALSE LIMIT 0; 10,001 refuse. Extra/missing columns, duplicate keys and noncanonical population counts refuse.'
  ]
 },
 'suppliedEvidenceIndependentlyVerified':{
  'scope':'Executed by owner, inspected and hash-reconciled by reviewer; not mislabeled as independently rerun complete suites.',
  'fullCore':{'passed':347,'failed':0,'inputDigests':1144,'allDigestsMatchIndependentReconstruction':True,'receipt':'owner-evidence/core/execution.json','receiptSha256':sha(P/'owner-evidence/core/execution.json')},
  'allCurrentScalar':{'databricksPassed':13,'postgresqlPassed':19,'failed':0,'inputDigests':1144,'allDigestsMatchIndependentReconstruction':True,'receipt':'owner-evidence/scalar/execution.json','receiptSha256':sha(P/'owner-evidence/scalar/execution.json')},
  'prePostFreshness':'Both owner receipts assert unchanged source inputs; captured hashes independently match the reconstructed frozen sources.',
  'previousR1R2Evidence':'Prior original frozen reports are preserved unchanged. R1 exact numeric oracle controls and R2 designation/legacy closure controls are historical evidence for unchanged helpers, not newly executed R3 checks.'
 },
 'staticReview':[
  {'path':'crates/weft-core/src/backend03_registry.rs','line':47,'assessment':'New catalog-wide opt-in guard executes before registration lookup/dispatch; bounded catalogs cannot enter ordinary Backend03 compilation based on selecting only facetless/integer/no fields. This specific guard was inspected, not separately exercised through a direct external Backend03 adapter.'},
  {'path':'crates/weft-core/src/current_query_refinement.rs','line':394,'assessment':'Separate compare_bounded and old compare select disjoint context/frame profiles. Captured and public domain preflight occurs before eval.derive at line 750, including empty-result plans.'},
  {'path':'crates/weft-core/src/current_query_refinement.rs','line':579,'assessment':'Every actual original literal/parameter is validated before evaluation; field pairing compares semantic complete domains plus exact scope, while literal pairing independently validates original/effective operands.'},
  {'path':'crates/weft-core/src/current_string_domain.rs','line':16,'assessment':'Exact mathematical bound parser remains unchanged from reviewed R1/R2, with no f64 conversion or allocation based on declared maxima. R3 probes additionally exercise equivalent decimal bounds through both physical backends.'},
  {'path':'docs/helix/02-design/contracts/CONTRACT-011-bounded-current-strings.md','line':123,'assessment':'TEXT/STRING SQL is explicitly conditional; complete native domain validation and constraint correspondence before release remain host obligations.'}
 ],
 'missingEvidenceAndIntegrationLimits':[
  'No PostgreSQL or Databricks native execution in this review. Native constraints, exact encoding/comparison correspondence, complete eligible-population domain checks and actual transform/source custody still require independent qualification.',
  'Runtime/Python/WASM public exports, feature propagation and ABI registration are not implemented in the frozen component. This report does not qualify wheels, browser behavior or host boundary conversion.',
  'Future WASM APIs must preserve/refuse ill-formed JavaScript UTF-16 before Rust String conversion; a Rust-side JsString guard and affected legacy security-source factory audit remain follow-up requirements, not demonstrated by Rust-only tests.',
  'NUL is a Unicode scalar in synthetic conditional controls. Its checker acceptance is not PostgreSQL text acceptance or native encoding qualification.',
  'Integration with current Weft main including Spark/reporting/Decimal work remains unreviewed. The frozen base-relative packet must be reconciled and tested as a combined final source before final integration acceptance.',
  'No UMF pg-raw.P03, L03, nullable Token, native gateway, weakened-barrier, guarded-release or full bounded-string chunk acceptance. Original 132 shared/native requirements and 158 allocated cases remain required; no case or criterion promotion.',
  'Neither artifact nor matched checker report proves authentication, authorization, native input truth/completeness or public-release authority. Successful outputs retain authority:false, securityReady:false and nativeAdmission:required.'
 ],
 'reviewerHarnessCorrections':[
  'First refinement-probe build used nonexistent short DBX method names; compiler rejected them. Corrected only external probe to actual *_bounded_contributors names; attempt-1 source/log retained. No product source edits.',
  'Backend probe first assertion expected unqualified C collation; actual source correctly uses pg_catalog-qualified C. Corrected reviewer assertion only; prior source/log retained.'
 ],
 'artifactPins':pins,
 'repositoryModification':'No owner repository or frozen source changed. External review probes, reconstructed base+patch copy and reports only under requested /private/tmp review directory.'
}
(P/'review.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
(P/'README.md').write_text('# Frozen bounded String R3 component review\n\nNo actionable defect found in the reviewed compiler/checker component. 556 independent synthetic controls passed, plus six feature-disabled symbol refusals. All 1,144 source hashes in each supplied core/backend receipt match the independently reconstructed frozen source. Supplied suites pass 347 core, 13 Databricks current_scalar and 19 PostgreSQL current_scalar tests.\n\nThe exact verdict, scope, source hashes, control scripts/results and missing evidence are in `review.json`. There is no native, Python, browser, publication, backend-case or full-chunk acceptance. Prior frozen R1/R2 and Decimal reports remain unchanged.\n')
print('reviewSha256',sha(P/'review.json'))
