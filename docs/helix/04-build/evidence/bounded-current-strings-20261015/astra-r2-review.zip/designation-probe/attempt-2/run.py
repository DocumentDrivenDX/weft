from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/private/tmp/weft-bounded-string-r2-astra-20261015/reconstructed');out=Path(__file__).parent
manifest=json.loads(Path('/private/tmp/weft-bounded-string-r2-review-20261015/manifest.json').read_text())
before={k:hashlib.sha256((root/k).read_bytes()).hexdigest() for k in manifest['files']}
assert before==manifest['files']
command=['/Users/erik/.rustup/toolchains/1.90.0-aarch64-apple-darwin/bin/cargo','run','--locked','--offline','--manifest-path',str(out/'Cargo.toml')]
env={**os.environ,'PATH':'/Users/erik/.rustup/toolchains/1.90.0-aarch64-apple-darwin/bin:/opt/homebrew/bin:/usr/bin:/bin','CARGO_HOME':'/private/tmp/weft-toolchain/cargo','CARGO_TARGET_DIR':'/private/tmp/umf-bounded-string-target-20261015'}
started=time.monotonic()
with (out/'stdout.log').open('w') as stdout,(out/'stderr.log').open('w') as stderr:r=subprocess.run(command,env=env,stdout=stdout,stderr=stderr,timeout=240)
after={k:hashlib.sha256((root/k).read_bytes()).hexdigest() for k in manifest['files']}
record={'command':command,'exitCode':r.returncode,'elapsedSeconds':time.monotonic()-started,'sourcesUnchanged':before==after,'verifiedFrozenFiles':len(before),'toolchain':'Rust1.90.0-aarch64-apple-darwin','hashes':{str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [out/'Cargo.toml',out/'Cargo.lock',out/'src/main.rs',out/'run.py',out/'stdout.log',out/'stderr.log']}}
(out/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
assert r.returncode==0 and before==after
print(json.dumps(record))
