use serde_json::{json,Value};
use weft_core::{application_lineage,application_resolve,application_syntax,backend::{Registry,Plan,Target,BindingInput},json::sha256};
fn main(){
 let mut r:Value=serde_json::from_str(include_str!("/private/tmp/weft-bounded-string-r1-astra-20261015/reconstructed/tests/current-query-designation/fixtures/mixed-original-uses.request.json")).unwrap();
 r["interfaceVersion"]=json!("weft-application-lineage/0.3-candidate");r["sql"]=json!("SELECT r.token FROM Resource r WHERE r.token='a'");
 let mut doc:Value=serde_json::from_str(r["modules"][0]["documentJson"].as_str().unwrap()).unwrap();
 doc["modules"][0]["elements"].as_array_mut().unwrap().iter_mut().find(|e|e["id"]=="token").unwrap()["facets"]=json!({"length":{"min":1,"max":3,"unit":"unicode-scalar"}});
 let raw=doc.to_string();r["modules"][0]["pin"]["sha256"]=json!(sha256(raw.as_bytes()));r["modules"][0]["documentJson"]=json!(raw);
 let parent=application_lineage::prepare(&r.to_string()).unwrap();
 let ordinary=application_resolve::resolve(parent.catalog(),application_syntax::parse(r["sql"].as_str().unwrap()).unwrap(),Default::default(),None);
 println!("ordinary_resolver={:?}",ordinary.as_ref().err());
 let legacy01=weft_core::resolve::resolve(parent.catalog(),weft_core::syntax::parse(r["sql"].as_str().unwrap()).unwrap());
 println!("v01_resolver={:?}",legacy01);
 let mut old=parent.plan().clone();old.ir_version="weft-ir/0.2.0".into();
 let pin=&r["modules"][0]["pin"];let logical=|e:&str|json!({"documentId":pin["documentId"],"revision":pin["revision"],"module":"m","element":e});
 let binding=json!({"profile":"ashlar-databricks-candidate/0.1.0","layoutRevision":"ashlar-delta/0.3","layoutSha256":"ad4a264508c971aefcd94e3ae90f8f74dcf119b7d767f6060c638f4abde3284e","modelPins":[pin],"publication":{"id":"development-compiler-fixture","manifestUuid":"00000000-0000-4000-8000-000000000000","tables":[{"name":["spark_catalog","default","compiler_fixture"],"uuid":"00000000-0000-4000-8000-000000000000","version":1}]},"records":[{"logical":logical("Resource"),"table":0,"kind":"object","sourceSystem":"development","typeId":"3","schemaRevision":"original-1","properties":[{"logical":logical("token"),"home":{"kind":"props","propertyId":"7"}}]}]}).to_string();
 let mut registry=Registry::default();registry.register(weft_databricks::candidate::Candidate).unwrap();
 let result=registry.compile(parent.catalog(),Plan::V02(&old),&Target{backend_id:"ashlar.databricks".into(),backend_version:"0.1.0-candidate".into(),profile_id:"dbsql-candidate".into(),allow_candidate:true},&BindingInput{profile:"ashlar-databricks-candidate/0.1.0".into(),sha256:sha256(binding.as_bytes()),json:binding});
 println!("parent_ir={} legacy_ir={} legacy_caps={:?}",parent.plan().ir_version,old.ir_version,old.required_capabilities);
 match result {Ok(value)=>println!("COMPILED {}",serde_json::to_string(&value).unwrap()),Err(error)=>println!("REFUSED {:?}",error)};
}
