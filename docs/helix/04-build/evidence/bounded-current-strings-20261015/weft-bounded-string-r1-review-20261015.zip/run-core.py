from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path.cwd();out=Path('/private/tmp/weft-bounded-core-r1-20261015');out.mkdir(exist_ok=True)
roots=['crates','tests','spec','vendor','docs/helix/02-design/contracts']
def capture():
 paths={p for name in roots for p in (root/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts and 'target' not in p.parts}
 paths.update(root/name for name in ['Cargo.toml','Cargo.lock'] if (root/name).is_file())
 paths.update(p for p in (root/'.cargo').rglob('*') if p.is_file())
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
before=capture();command=['/Users/erik/.rustup/toolchains/1.90.0-aarch64-apple-darwin/bin/cargo','test','--locked','--offline','-p','weft-core','--lib','--features','current-query-refinement-candidate','--','--nocapture'];started=time.monotonic()
env={**os.environ,'PATH':'/Users/erik/.rustup/toolchains/1.90.0-aarch64-apple-darwin/bin:/opt/homebrew/bin:/usr/bin:/bin','CARGO_HOME':'/private/tmp/weft-toolchain/cargo','CARGO_TARGET_DIR':'/private/tmp/umf-bounded-string-target-20261015'}
with (out/'stdout.log').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
 result=subprocess.run(command,env=env,stdout=stdout,stderr=stderr,timeout=240)
after=capture();record={'command':command,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-started,'sourceDigests':before,'sourcesUnchanged':before==after,'scope':'Selected isolated repository compilation/test inputs and endpoint freshness, not a hermetic toolchain or native backend proof.'}
(out/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
assert result.returncode==0 and before==after
print(json.dumps({'exitCode':result.returncode,'sourcesUnchanged':before==after,'sourceCount':len(before)}))
