"""Independent numeric oracle and source-preparation controls on frozen R1."""
from pathlib import Path
from decimal import Decimal, localcontext
import hashlib
import json
import random
import subprocess
import time

OUT=Path('/private/tmp/weft-bounded-string-r1-astra-20261015')
ROOT=OUT/'reconstructed'
BIN=OUT/'target/debug/examples/astra_bound_oracle'
MAX=9007199254740991
rng=random.Random(733011)
cases=[]
def expected(token):
    with localcontext() as ctx:
        ctx.prec=5000
        value=Decimal(token)
        return int(value) if value>=0 and value<=MAX and value==value.to_integral_value() else None
def add(token, want='derive'):
    value=expected(token) if want=='derive' else want
    cases.append({'token':token,'expected':value,'input':'{"length":{"min":0,"max":'+token+',"unit":"unicode-scalar"}}'})
for token in ['0','-0','0.0','-0.0','1','1.0','1.0000','1e+0','1E-0','1.5e1','0.00010e4',
              '9007199254740991','9007199254740991.0','9007199254740992','9007199254740991.0000000000000000001',
              '9.007199254740991e15','9.007199254740992e15','900719925474099100e-2',
              '900719925474099099999e-5','-1e-1000','1e-1000','1e1000']:
    add(token)
for negative in ['', '-']:
    for exponent in ['', '+', '-']:
        add(negative+'0.000e'+exponent+'9'*200,0)
for token in ['1e'+'9'*200,'1e-'+'9'*200,'1e+'+'9'*200]:add(token,None)
for n in [0,1,2,MAX-1,MAX,MAX+1,10**20]:
    for zeros in [0,1,15,100,1000]:
        add(str(n)+'.'+'0'*zeros if zeros else str(n))
        add(str(n)+'0'*zeros+'e-'+str(zeros))
for _ in range(6000):
    whole=str(rng.randrange(0,10**rng.randrange(1,24)))
    frac=''.join(str(rng.randrange(10)) for _ in range(rng.randrange(0,28)))
    sign='-' if rng.randrange(5)==0 else ''
    exponent=rng.randrange(-75,76)
    token=sign+whole+('.'+frac if frac else '')
    if rng.randrange(2):token+=rng.choice(['e','E'])+('+' if exponent>=0 and rng.randrange(2) else '')+str(exponent)
    add(token)
payload=''.join(c['input']+'\n' for c in cases)
(OUT/'numeric-cases.json').write_text(json.dumps(cases,indent=2)+'\n')
started=time.monotonic();run=subprocess.run([str(BIN)],input=payload,text=True,capture_output=True,timeout=30)
(OUT/'numeric.stdout').write_text(run.stdout);(OUT/'numeric.stderr').write_text(run.stderr)
assert run.returncode==0,run.stderr
observed=[json.loads(line) for line in run.stdout.splitlines()]
assert len(observed)==len(cases)
failures=[]
for index,(case,result) in enumerate(zip(cases,observed)):
    ok=result.get('parsed') is True and result.get('accepted') is (case['expected'] is not None)
    if case['expected'] is not None:ok=ok and result.get('min')==0 and result.get('max')==case['expected']
    if not ok:failures.append({'index':index,'case':case,'observed':result})
numeric={'cases':len(cases),'failures':failures,'elapsedSeconds':time.monotonic()-started,'exitCode':run.returncode}

template=json.loads((ROOT/'tests/current-query-designation/fixtures/mixed-original-uses.request.json').read_text())
def request(minimum,maximum,version='0.3-candidate',sql='SELECT r.token FROM Resource r'):
    req=json.loads(json.dumps(template));req['interfaceVersion']='weft-application-lineage/'+version;req['sql']=sql
    document=json.loads(req['modules'][0]['documentJson'])
    next(x for x in document['modules'][0]['elements'] if x['id']=='token')['facets']='BOUND_PLACEHOLDER'
    document_raw=json.dumps(document,ensure_ascii=False,separators=(',',':')).replace('"BOUND_PLACEHOLDER"','{"length":{"min":'+minimum+',"max":'+maximum+',"unit":"unicode-scalar"}}')
    req['modules'][0]['documentJson']=document_raw;req['modules'][0]['pin']['sha256']=hashlib.sha256(document_raw.encode()).hexdigest()
    return json.dumps(req,ensure_ascii=False,separators=(',',':'))
lineage=[]
for minimum,maximum,want in [('0','1',True),('-0','1.0',True),('0.0','9.007199254740991e15',True),
    ('1.0','3e0',True),('0','9007199254740992',False),('0','1.5',False),('0','1e-1',False),
    ('-1','1',False),('2','1',False),('0','9007199254740991.0000000000000001',False),
    ('-0.0e999999999999999999999999','1',True)]:
    lineage.append({'minimum':minimum,'maximum':maximum,'version':'0.3-candidate','expected':want,
                    'request':request(minimum,maximum)})
for version in ['0.1-candidate','0.2-candidate']:
    lineage.append({'minimum':'1','maximum':'3','version':version,'expected':False,'request':request('1','3',version)})
payload=''.join(json.dumps({'mode':'lineage','request':x['request']},ensure_ascii=False)+'\n' for x in lineage)
(OUT/'lineage-cases.json').write_text(json.dumps(lineage,ensure_ascii=False,indent=2)+'\n')
run=subprocess.run([str(BIN)],input=payload,text=True,capture_output=True,timeout=30)
(OUT/'lineage.stdout').write_text(run.stdout);(OUT/'lineage.stderr').write_text(run.stderr)
assert run.returncode==0,run.stderr
lineage_observed=[json.loads(line) for line in run.stdout.splitlines()]
assert len(lineage_observed)==len(lineage)
lineage_failures=[{'case':c,'observed':o} for c,o in zip(lineage,lineage_observed) if o['prepared'] is not c['expected']]
record={'status':'passed' if not failures and not lineage_failures else 'failed','numeric':numeric,
        'lineage':{'cases':len(lineage),'failures':lineage_failures,'observations':lineage_observed},
        'binarySha256':hashlib.sha256(BIN.read_bytes()).hexdigest(),
        'exampleSourceSha256':hashlib.sha256((ROOT/'crates/weft-core/examples/astra_bound_oracle.rs').read_bytes()).hexdigest(),
        'scope':'Independent Python Decimal oracle against actual frozen Rust bounds plus bounded source preparation; no SQL/backend/browser execution.'}
(OUT/'adversarial.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':record['status'],'numericCases':len(cases),'numericFailures':len(failures),'lineageCases':len(lineage),'lineageFailures':len(lineage_failures)}))
