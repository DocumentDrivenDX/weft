"""Authored Unicode scalar, nullable, legacy and ill-formed JSON controls."""
from pathlib import Path
import hashlib,json,subprocess
out=Path('/private/tmp/weft-bounded-string-r1-astra-20261015')
binary=out/'target/debug/examples/astra_bound_oracle'
vectors=[('',0),('A',1),('\x00',1),('\r\n',2),('é',1),('e\u0301',2),
         ('😀',1),('🇨🇦',2),('👨\u200d👩\u200d👧\u200d👦',7),
         ('\ufeff',1),('\u2028',1),('\U0010ffff',1),('😀éA',3)]
cases=[]
for value,count in vectors:
    for minimum,maximum,valid in [(count,count,True),(count+1,9007199254740991,False)]+([(0,count-1,False)] if count else []):
        cases.append({'id':'scalar-'+str(len(cases)),'mode':'validate','value':value,'bounded':True,
                      'facets':{'length':{'min':minimum,'max':maximum,'unit':'unicode-scalar'}},
                      'expected':{'supported':True,'valid':valid,'literalFacetValid':valid}})
cases += [
    {'id':'old-bounded-refuses','mode':'validate','value':'😀','bounded':False,
     'facets':{'length':{'min':1,'max':1,'unit':'unicode-scalar'}},
     'expected':{'supported':False,'valid':False,'literalFacetValid':True}},
    {'id':'old-unbounded-retained','mode':'validate','value':'😀','bounded':False,'facets':{},
     'expected':{'supported':True,'valid':True,'literalFacetValid':True}},
    {'id':'nullable-legacy-literal-retained','mode':'validate','value':'A','bounded':False,'nullable':True,'facets':{},
     'expected':{'supported':False,'valid':False,'literalFacetValid':True}},
    {'id':'nullable-bounded-domain-refuses','mode':'validate','value':'A','bounded':True,'nullable':True,
     'facets':{'length':{'min':1,'max':1,'unit':'unicode-scalar'}},
     'expected':{'supported':False,'valid':False,'literalFacetValid':True}},
]
for index,value in enumerate(['\ud800','\udfff','a\ud800b']):
    cases.append({'id':'ill-formed-json-'+str(index),'mode':'validate','value':value,'bounded':True,'facets':{},'expected':{'parsed':False}})
payload=''.join(json.dumps({k:v for k,v in case.items() if k not in ['id','expected']},ensure_ascii=True)+'\n' for case in cases)
(out/'unicode-cases.json').write_text(json.dumps(cases,ensure_ascii=True,indent=2)+'\n')
run=subprocess.run([str(binary)],input=payload,text=True,capture_output=True,timeout=20)
(out/'unicode.stdout').write_text(run.stdout);(out/'unicode.stderr').write_text(run.stderr)
assert run.returncode==0,run.stderr
observations=[json.loads(line) for line in run.stdout.splitlines()]
assert len(observations)==len(cases)
failures=[]
for case,observation in zip(cases,observations):
    if not all(type(observation.get(key)) is type(value) and observation.get(key)==value for key,value in case['expected'].items()):
        failures.append({'id':case['id'],'expected':case['expected'],'observed':observation})
report={'status':'passed' if not failures else 'failed','cases':len(cases),'failures':failures,
        'binarySha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
        'scope':'Actual frozen Rust helper and Rust serde_json parser; supplementary scalars, combining marks, ZWJ/flag graphemes, NUL, nullable/legacy separation, malformed JSON surrogates. No JavaScript/WASM pre-conversion test.'}
(out/'unicode.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
