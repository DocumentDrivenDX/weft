import importlib.util,json,hashlib,os,stat
from pathlib import Path
ROOT=Path('/private/tmp/weft-unnamed-arithmetic-042');OUT=Path('/private/tmp/weft-042-cli-checks-f');TARGET=Path('/private/tmp/weft-042-target-a')
TOOL=Path('/private/tmp/weft-toolchain/rustup/toolchains/1.90.0-aarch64-apple-darwin/bin')
FREEZE=Path('/private/tmp/weft-042-source-freeze-e.json')
def verify():
 for i in json.loads(FREEZE.read_bytes())['files']:
  b=Path(i['path']).read_bytes();assert len(b)==i['bytes'] and hashlib.sha256(b).hexdigest()==i['sha256']
def size():
 total=0
 for d,_,files in os.walk(TARGET):
  for name in files:
   s=(Path(d)/name).lstat()
   if stat.S_ISREG(s.st_mode):total+=s.st_size
 return total
spec=importlib.util.spec_from_file_location('capture','/private/tmp/ashlar-count-star-installed-cli-capture-a.py');capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
verify();OUT.mkdir(mode=0o700);env=json.loads(Path('/private/tmp/weft-042-bounded-check-command-e.json').read_bytes())['environment']
argv=[str(TOOL/'cargo'),'build','--offline','--locked','-j1','-p','weft-runtime','--no-default-features','--features','ashlar-databricks-paths-keys,ashlar-databricks-implicit-arithmetic','--bin','weft-paths-keys','--bin','weft-implicit-arithmetic']
primary=None;result=None
try:
 result=capture.capture(argv,str(ROOT),env,OUT/'build.stdout',OUT/'build.stderr',300,4194304)
 if result['exitCode']!=0:raise ValueError('publicCLI build failed')
 if size()>3*1024**3:raise ValueError('owned target capacity exceeded')
except BaseException as e:primary=e
finally:
 try:verify()
 except BaseException as e:primary=capture.select_failure(primary,e)
 stream=None
 try:
  stream=(OUT/'build-receipt.json').open('x');stream.write(json.dumps({'argv':argv,'capture':result,'targetBytes':size(),'success':primary is None,'scope':'actual publicdebugCLI build only; no indexed product/native qualification'},indent=2)+'\n');stream.flush()
 except BaseException as e:primary=capture.select_failure(primary,e)
 finally:
  if stream is not None:
   try:stream.close()
   except BaseException as e:primary=capture.select_failure(primary,e)
if primary is not None:raise primary
