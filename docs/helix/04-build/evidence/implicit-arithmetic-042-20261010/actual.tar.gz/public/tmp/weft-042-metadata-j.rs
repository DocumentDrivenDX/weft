fn main() {
 let mut registry=weft_core::backend03::Registry::default();
 registry.register(weft_databricks::implicit_arithmetic::ImplicitArithmeticLabels).expect("explicit registration");
 let manifest=registry.manifest(weft_databricks::paths_keys::ID).expect("explicit manifest");
 println!("{}",serde_json::to_string(manifest).expect("public serialization"));
}
