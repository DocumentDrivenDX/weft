import gzip,json,hashlib,importlib.util
from pathlib import Path
ROOT=Path('/private/tmp/weft-unnamed-arithmetic-042'); OUT=Path('/private/tmp/weft-042-public-check-g'); BIN=Path('/private/tmp/weft-042-target-a/debug')
spec=importlib.util.spec_from_file_location('capture','/private/tmp/ashlar-count-star-installed-cli-capture-a.py'); c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
freeze=json.loads(Path('/private/tmp/weft-042-source-freeze-e.json').read_bytes())
def verify():
 for f in freeze['files']:
  b=Path(f['path']).read_bytes();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
pins={str(BIN/n):hashlib.sha256((BIN/n).read_bytes()).hexdigest() for n in ('weft-paths-keys','weft-implicit-arithmetic')}
verify();OUT.mkdir(mode=0o700);env=json.loads(Path('/private/tmp/weft-042-bounded-check-command-e.json').read_bytes())['environment'];records=[];primary=None
try:
 corpus=json.loads(gzip.decompress((ROOT/'tests/distribution-count-star-corpus/fixtures/count-star-having-041-corpus.json.gz').read_bytes()))
 for i,row in enumerate(corpus['cases']):
  p=OUT/('old-%03d'%i); p.with_suffix('.request').write_bytes(bytes.fromhex(row['requestHex']))
  r=c.capture([str(BIN/'weft-paths-keys')],str(ROOT),env,p.with_suffix('.stdout'),p.with_suffix('.stderr'),10,4194304,stdin_path=p.with_suffix('.request'))
  actual=p.with_suffix('.stdout').read_bytes();expected=bytes.fromhex(row['responseHex'])+b'\n'
  records.append({'kind':'old','id':row['id'],'capture':r,'equal':actual==expected})
  assert r['exitCode']==0 and not p.with_suffix('.stderr').read_bytes() and actual==expected
 for name in ('partial-return','fulfillment','settlement','refund'):
  original=Path('/private/tmp/ashlar-commerce-original-installed-compile-c/compile-output')/('commerce-'+name+'-0.request'); request=json.loads(original.read_bytes()); migrated=json.loads(original.read_bytes())
  migrated['dialect']='weft-sql/0.4.2';migrated['interfaceVersion']='weft-compile/0.4.2'
  def change(x):
   if type(x) is dict:
    for k,v in x.items():
     if k=='backendVersion' and v=='0.4.1-count-star-having-candidate':x[k]='0.4.2-implicit-arithmetic-labels-candidate'
     else:change(v)
   elif type(x) is list:
    for v in x:change(v)
  change(migrated)
  pairs=[]
  for iteration in range(2):
   p=OUT/(name+'-'+str(iteration));p.with_suffix('.request').write_bytes(json.dumps(migrated,separators=(',',':'),ensure_ascii=False).encode())
   r=c.capture([str(BIN/'weft-implicit-arithmetic')],str(ROOT),env,p.with_suffix('.stdout'),p.with_suffix('.stderr'),10,4194304,stdin_path=p.with_suffix('.request'))
   actual=p.with_suffix('.stdout').read_bytes();response=json.loads(actual);records.append({'kind':'new','id':name,'iteration':iteration,'capture':r,'status':response.get('status')});pairs.append(actual)
   assert r['exitCode']==0 and response['status']=='compiled' and not p.with_suffix('.stderr').read_bytes()
  assert pairs[0]==pairs[1]
except BaseException as e:primary=e
finally:
 try:
  verify()
  for p,h in pins.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
 except BaseException as e:primary=c.select_failure(primary,e)
 (OUT/'receipt.json').write_text(json.dumps({'records':records,'binaryPins':pins,'success':primary is None,'scope':'old80 byte parity and new4 actualCLI compilation only'},indent=2)+'\n')
if primary is not None:raise primary
