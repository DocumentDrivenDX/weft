import importlib.util,json,hashlib,os,stat
from pathlib import Path
ROOT=Path('/private/tmp/weft-042-integration-b');OUT=Path('/private/tmp/weft-042-integration-check-l');TARGET=Path('/private/tmp/weft-042-target-a')
f=json.loads(Path('/private/tmp/weft-042-integration-source-freeze-b.json').read_bytes());env=json.loads(Path('/private/tmp/weft-042-bounded-check-command-e.json').read_bytes())['environment'];cargo='/private/tmp/weft-toolchain/rustup/toolchains/1.90.0-aarch64-apple-darwin/bin/cargo'
s=importlib.util.spec_from_file_location('capture','/private/tmp/ashlar-count-star-installed-cli-capture-a.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
def verify():
 for x in f['files']:
  b=Path(x['path']).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
def size():
 return sum((Path(d)/n).lstat().st_size for d,_,ns in os.walk(TARGET) for n in ns if stat.S_ISREG((Path(d)/n).lstat().st_mode))
verify();OUT.mkdir(mode=0o700);primary=None;records=[]
try:
 commands=[('transport',[cargo,'test','--offline','--locked','-j1','-p','weft-runtime','--no-default-features','--features','ashlar-databricks-paths-keys,ashlar-databricks-implicit-arithmetic','--test','implicit_arithmetic_input']),('runtime',[cargo,'test','--offline','--locked','-j1','-p','weft-runtime','--no-default-features','--features','ashlar-databricks-paths-keys,ashlar-databricks-implicit-arithmetic','--lib','implicit_arithmetic::tests']),('boundaries',['/usr/bin/python3','-B','scripts/checks/check-module-boundaries.py'])]
 for name,argv in commands:
  r=c.capture(argv,str(ROOT),env,OUT/(name+'.stdout'),OUT/(name+'.stderr'),300,4194304);records.append({'phase':name,'argv':argv,'capture':r,'targetBytes':size()})
  if r['exitCode']!=0:raise ValueError('affected phase failed:'+name)
  if size()>3*1024**3:raise ValueError('target capacity exceeded')
 for name in ('partial-return','fulfillment','settlement','refund'):
  req=Path('/private/tmp/weft-042-public-check-i')/(name+'-0.request');r=c.capture([str(TARGET/'debug/weft-implicit-arithmetic')],str(ROOT),env,OUT/(name+'.stdout'),OUT/(name+'.stderr'),10,4194304,stdin_path=req);response=json.loads((OUT/(name+'.stdout')).read_bytes());records.append({'phase':name,'capture':r,'status':response.get('status')});assert r['exitCode']==0 and response['status']=='compiled'
except BaseException as e:primary=e
finally:
 try:verify()
 except BaseException as e:primary=c.select_failure(primary,e)
 stream=None
 try:
  stream=(OUT/'receipt.json').open('x');stream.write(json.dumps({'records':records,'success':primary is None,'sourceFreeze':'/private/tmp/weft-042-integration-source-freeze-b.json','scope':'integrated affectedtransport/runtime/public4 andmodulechecks only'},indent=2)+'\n');stream.flush()
 except BaseException as e:primary=c.select_failure(primary,e)
 finally:
  if stream is not None:
   try:stream.close()
   except BaseException as e:primary=c.select_failure(primary,e)
if primary is not None:raise primary
