use std::io::{self,BufRead};
use serde_json::{json,Value};
fn main(){
 for line in io::stdin().lock().lines(){let raw=line.unwrap();let v:Value=serde_json::from_str(&raw).unwrap();
 let result=match weft_core::application_lineage::prepare(v["request"].as_str().unwrap()){
 Ok(p)=>{let legacy=weft_core::application_syntax::parse("SELECT r.resourceId FROM Resource r").and_then(|q|weft_core::application_resolve::resolve(p.catalog(),q,Default::default(),None));json!({"ok":true,"report":serde_json::from_str::<Value>(p.json()).unwrap(),"designationAccepted":weft_core::current_query_designation::derive(&p).is_ok(),"legacyResolverAccepted":legacy.is_ok()})},
 Err(e)=>json!({"ok":false,"diagnostic":format!("{:?}",e)})};println!("{}",json!({"id":v["id"],"result":result}));}
}
