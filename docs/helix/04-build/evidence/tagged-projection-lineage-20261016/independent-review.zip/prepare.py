from pathlib import Path
import json,hashlib,shutil,difflib
r=Path(__file__).resolve().parent;old=Path('/private/tmp/weft-presence-lineage-astra-20261016');m=json.loads((r/'frozen/review-manifest.json').read_text());h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert h(r/'frozen/prior/r1-review-packet.zip')==m['r1PacketSha256'];assert h(r/'frozen/prior/astra-r1-review.json')==h(old/'review.json')==m['r1ReviewSha256']
for f in ['enabled-results.jsonl','public-model-validation.json','control-inputs.json']:assert(r/'frozen/prior'/f).read_bytes()==(old/f).read_bytes()
shutil.copytree(old/'reconstructed',r/'reconstructed')
changed=[]
for f in m['sourceFiles']:
 p=f['path'];assert h(r/'frozen'/p)==f['sha256']and h(old/'frozen'/p)==f['r1Sha256'];
 if f['sha256']!=f['r1Sha256']:changed.append(p)
 shutil.copyfile(r/'frozen'/p,r/'reconstructed'/p)
assert changed==['crates/weft-core/src/application_lineage.rs']
for f in ['control-inputs.json','control-inputs.jsonl','public-model-validation.json']:shutil.copyfile(old/f,r/f)
pins={str(p.relative_to(r/'reconstructed')):h(p)for p in(r/'reconstructed').rglob('*')if p.is_file()};(r/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
p=changed[0];(r/'r1-to-r2.patch').write_text(''.join(difflib.unified_diff((old/'frozen'/p).read_text().splitlines(True),(r/'frozen'/p).read_text().splitlines(True),fromfile='r1/'+p,tofile='r2/'+p)))
(r/'packet-audit.json').write_text(json.dumps({'status':'passed','exactR1PacketAndReportRetained':True,'originalIndependentWitnessesRetained':True,'changedSinceR1':changed,'sourceFilesPinned':len(pins)},indent=2)+'\n');print('R2 reconstructed, only lineage source differs')
