use serde_json::{Value,json};
fn main(){
 let mut request:Value=serde_json::from_str(include_str!("/private/tmp/weft-presence-owner-20261016/tests/current-query-presence/fixtures/optional-token-lineage.request.json")).unwrap();
 assert!(weft_core::application_lineage::prepare(&request.to_string()).is_ok());
 let mut wildcard=request.clone();wildcard["sql"]=json!("SELECT r.* FROM Resource r");
 println!("{}",json!({"wildcardPrepared":weft_core::application_lineage::prepare(&wildcard.to_string()).is_ok(),"nativeAdmission":false}));
 let mut doc:Value=serde_json::from_str(request["modules"][0]["documentJson"].as_str().unwrap()).unwrap();
 let field=doc["modules"][0]["elements"].as_array_mut().unwrap().iter_mut().find(|v|v["id"]=="token").unwrap().as_object_mut().unwrap();
 field.remove("scalarType");field.remove("facets");field.insert("cardinality".into(),json!("array"));field.insert("itemType".into(),json!({"module":"m","element":"resourceId"}));
 let raw=doc.to_string();request["modules"][0]["documentJson"]=json!(raw);request["modules"][0]["pin"]["sha256"]=json!(weft_core::json::sha256(raw.as_bytes()));
 let refusal=weft_core::application_lineage::prepare(&request.to_string()).err().expect("Known array must refuse");
 println!("{}",json!({"originalScalarPrepared":true,"publicValidatedArrayRefused":true,"diagnostic":refusal.code,"nativeAdmission":false}));
}
