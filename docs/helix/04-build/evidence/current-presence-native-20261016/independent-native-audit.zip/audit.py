from pathlib import Path
import json,zipfile,hashlib,copy,collections,shutil,uuid
R=Path(__file__).resolve().parent
raw=(R/'supplied/receipt.json').read_bytes();receipt=json.loads(raw)
zipraw=(R/'supplied/source-inputs.zip').read_bytes();archive=zipfile.ZipFile(R/'supplied/source-inputs.zip');manifest=json.loads(archive.read('manifest.json'))
def sha(b):return hashlib.sha256(b).hexdigest()
def encoded(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def digest(x):return sha(canonical(x).encode())
def literal(s):return "E'"+s.replace('\\','\\\\').replace("'","''")+"'"
checks=[]
def ck(id,actual,expected):
 ok=type(actual)==type(expected) and actual==expected
 checks.append({'id':id,'passed':ok,'actual':actual if len(str(actual))<300 else {'canonicalSha256':digest(actual)},'expected':expected if len(str(expected))<300 else {'canonicalSha256':digest(expected)}})
 return ok
ck('receipt-exact-pin',sha(raw),'c1a0299242907ad79fc4437ae5ced9b67a36d9e305be455121b5149a2177f49d')
ck('manifest-domain',sorted(manifest),sorted(receipt['sourceDigests']))
ck('archive-member-domain',sorted(archive.namelist()),sorted(['manifest.json']+[v['entry']for v in manifest.values()]))
ck('unique-archive-members',len(set(archive.namelist())),len(archive.namelist()))
ck('source-count',len(manifest),1285)
endpoints={};frozen={}
for p,v in manifest.items():
 b=archive.read(v['entry']);frozen[p]=b;h=sha(b)
 ck('archive-pin:'+p,h,v['sha256']);ck('receipt-pin:'+p,h,receipt['sourceDigests'][p])
 now=Path(p);current=sha(now.read_bytes())if now.is_file()else None
 endpoints[p]={'archivedSha256':h,'currentSha256':current,'matched':h==current}
 ck('current-endpoint:'+p,current,h)
(R/'source-endpoints.json').write_text(json.dumps(endpoints,indent=2)+'\n')
def locate(suffix):
 paths=[p for p in frozen if p.endswith(suffix)];assert len(paths)==1,(suffix,paths)
 return paths[0]
def load(suffix):return json.loads(frozen[locate(suffix)])
runner=locate('/tools/security/pg18-atomic-presence-transport.py')
ck('runner-reviewed-r5',sha(frozen[runner]),'b96f21ffc49d8bb44e5dcb47341c51eacbd0eab5b92aa300b3c8e2793eb13216')
producer=load('/umf-atomic-presence-handoff-r3-20261016/inputs.json')
cases={c['id']:c['request']for c in load('/fixtures/actual-atomic-transport.json')['cases']}
emitted=load('/weft-presence-actual-emitted-r3-20261016.json')
logical={p['id']:p for p in producer['packets']}
ck('original-packet-count',len(logical),66);ck('original-emitted-count',len(emitted),41)
ck('exact-original-rendered-id-set',sorted(r['id']for r in emitted),sorted(k for k,v in logical.items()if v['result']['status']=='rendered'))
umfroot=Path(runner).parents[2];reconstructed=R/'reconstructed-umf';reconstructed.mkdir(exist_ok=True)
ck('generator-source-domain',sorted(producer['sources']),sorted(producer['sourcePins']))
ck('generator-source-count',len(producer['sourcePins']),102)
for rel,h in producer['sourcePins'].items():
 p=str(umfroot/rel);b=frozen[p];ck('generator-bytes:'+rel,b.decode(),producer['sources'][rel]);ck('generator-pin:'+rel,sha(b),h)
 target=reconstructed/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
# External packages are copied solely to execute independently on the archived 102-source closure.
old=Path('/private/tmp/umf-atomic-presence-handoff-astra-20261016/reconstructed/node_modules')
for d in old.iterdir():
 target=reconstructed/'node_modules'/d.name
 if not target.exists():shutil.copytree(d,target)
# Restore pinned metadata after external package copy and verify it against the archived dependency claim.
for rel in producer['sourcePins']:
 if rel.startswith('node_modules/'):
  target=reconstructed/rel;ck('dependency-metadata:'+rel,sha(target.read_bytes()),producer['sourcePins'][rel])
extra=load('/umf-atomic-presence-handoff-astra-20261016/independent-controls.json');templates={r['id']:r for r in emitted}
ck('supplemental-controls-status',extra['status'],'passed');ck('supplemental-count',extra['count'],59);ck('supplemental-observation-count',len(extra['observations']),6)
for o in extra['observations']:
 packet=copy.deepcopy(o['packet']);base=packet['id'];ck(o['id']+':same-supplemental-source',packet['source'],logical[base]['source'])
 packet['id']='review-'+o['id'];packet['result']=o['result'];logical[packet['id']]=packet;cases[packet['id']]=cases[base];row=copy.deepcopy(templates[base]);row['id']=packet['id'];emitted.append(row)
byid={r['id']:r for r in emitted}
expected_ops=[(r['id'],None)for r in emitted]+[('allowed:string',n)for n in ['missing-result','extra-result','scalar-null-collapse','changed-header']]+[('allowed:transformed-null','invalid-selected-occurrence')]
ck('operation-count',len(receipt['operations']),52);ck('operation-identities',[(o['id'],o['negative'])for o in receipt['operations']],expected_ops)
ck('positive-count',receipt['positiveOperations'],47);ck('negative-count',receipt['negativeOperations'],5)
ck('observation-count',len(receipt['observations']),869)
for i,o in enumerate(receipt['observations']):ck('observation:%04d:%s'%(i,o['id']),o['actual'],o['expected'])
expected_sql=["SELECT json_build_object('version',version(),'number',current_setting('server_version_num'),'currentUser',current_user,'sessionUser',session_user,'encoding',current_setting('client_encoding'));",'CREATE SCHEMA private_stage;CREATE TABLE private_stage.held_cells(private_key text COLLATE "C" PRIMARY KEY,eligible boolean NOT NULL,token_cell text NOT NULL);']
replay=[];summaries=[]
for i,o in enumerate(receipt['operations']):
 tag='%02d:%s:%s'%(i,o['id'],o['negative']);packet=logical[o['id']];original=packet['result'];batch=original['batch'];binding=byid[o['id']]['binding'];negative=o['negative'];request=cases[o['id']]
 ck(tag+':request-exact-canonical',o['requestJson'],canonical(request));ck(tag+':binding-exact-canonical',o['bindingJson'],canonical(binding))
 prep=json.loads(o['preparationJson']);artifact=json.loads(o['artifactJson']);frame=o['frame']
 ck(tag+':preparation-pin',sha(o['preparationJson'].encode()),binding['preparationSha256'])
 ck(tag+':source-request-pin',sha(o['requestJson'].encode()),binding['sourceRequestSha256'])
 ck(tag+':source-binding-pin',prep['binding']['sha256'],binding['sourceBindingSha256'])
 ck(tag+':compiled-exact-issued-artifact',artifact,byid[o['id']]['compiled'])
 ck(tag+':compiled-pin',sha(o['artifactJson'].encode()),frame['compiledArtifactSha256'])
 ck(tag+':binding-pin',sha(o['bindingJson'].encode()),frame['materializationBindingSha256'])
 ck(tag+':frame-preparation-pin',frame['preparationSha256'],sha(o['preparationJson'].encode()))
 ck(tag+':frame-request-pin',frame['sourceRequestSha256'],sha(o['requestJson'].encode()))
 ck(tag+':bound-header',artifact['disclosureHeader'],{k:v for k,v in batch.items()if k!='rows'})
 ck(tag+':no-SQL-parameters',artifact['parameters'],[])
 ck(tag+':source-false-authority', [original['authority'],original['complete']],[False,False])
 ck(tag+':typed-false-authority',[prep['authority'],prep['securityReady'],artifact['authority'],artifact['securityReady']],[False,False,False,False])
 ck(tag+':typed-admission-required',[prep['nativeAdmission'],artifact['nativeAdmission']],['required','required'])
 ck(tag+':driver-column-order',o['driverColumnNames'],['output_0','__weft_source_rows'])
 resources=original['resources'];rows=batch['rows'];ck(tag+':resource-row-count',len(resources),len(rows))
 captured=[];expected_sql.append('TRUNCATE private_stage.held_cells;')
 for resource,row in zip(resources,rows):
  ck(tag+':one-cell-per-resource',len(row),1);cell=row[0];key=canonical(resource)
  expected_sql.append('INSERT INTO private_stage.held_cells VALUES ('+literal(key)+',true,'+literal(encoded(cell))+');')
  c=copy.deepcopy(cell)
  if negative=='invalid-selected-occurrence':c['selection']={'ruleIndex':999,'disclosureIndex':999}
  captured.append([key,encoded(c)])
 expected_sql.append("INSERT INTO private_stage.held_cells VALUES ('excluded-fixture-row',false,'{\"disposition\":\"withheld\"}');")
 if negative=='invalid-selected-occurrence':
  expected_sql.append('UPDATE private_stage.held_cells SET token_cell='+literal(captured[0][1])+' WHERE eligible;')
 expected_sql += ['SELECT private_key,token_cell FROM private_stage.held_cells WHERE eligible IS TRUE ORDER BY private_key;',artifact['sql']+';']
 captured.sort(key=lambda r:r[0].encode('utf8'))
 ck(tag+':independent-captured-complete-key-cell-population',o['expectedCapture'],captured)
 expected_frame={k:v for k,v in byid[o['id']]['frame'].items()if k not in ['rows','resultRows','expectedRowCount']}
 expected_frame['rows']=[{'key':k,'cells':[c]}for k,c in captured];expected_frame['expectedRowCount']=str(len(captured));expected_frame['resultRows']=copy.deepcopy(o['actualDriverRows'])
 native_pairs=[]
 for j,row in enumerate(o['actualDriverRows']):
  ck(tag+':native-row-width:'+str(j),len(row),2)
  cell,side=row;ck(tag+':native-column-types:'+str(j),[type(cell).__name__,type(side).__name__],['str','str'])
  s=json.loads(side);ck(tag+':native-sideband-closed-shape:'+str(j),s,{'version':'weft.stage-row-tuple/0.1-candidate','rows':[{'scan':'s0','key':s['rows'][0]['key']}]})
  native_pairs.append([s['rows'][0]['key'],cell])
 ck(tag+':driver-exact-key-cell-bag',sorted(native_pairs),sorted(captured))
 ck(tag+':native-key-uniqueness',len(set(k for k,c in native_pairs)),len(native_pairs))
 if negative=='missing-result':expected_frame['resultRows']=[]
 if negative=='extra-result':expected_frame['resultRows']=copy.deepcopy(o['actualDriverRows'])*2
 if negative=='scalar-null-collapse':expected_frame['resultRows'][0][0]=None
 if negative=='changed-header':expected_frame['header']=copy.deepcopy(expected_frame['header']);expected_frame['header']['policy']['revision']='other'
 ck(tag+':exact-checker-frame',frame,expected_frame)
 ck(tag+':correct-negative-layer',o['negativeInputLayer'],'staged-native-cell'if negative=='invalid-selected-occurrence'else'checker-frame-corruption'if negative else None)
 if negative not in [None,'invalid-selected-occurrence']:
  ck(tag+':generic-checker-refusal',o['checker'],{'phase':'refused','authority':False})
  ck(tag+':no-partial-native-batch','nativeBatch'in o,False);ck(tag+':no-public-inspection','publicInspection'in o,False)
 else:
  report=json.loads(o['checker']['reportJson']);ck(tag+':check-phase',o['checker']['phase'],'checked');ck(tag+':checker-matched',report['matched'],True)
  for k,v in {'compiledArtifactSha256':sha(o['artifactJson'].encode()),'materializationBindingSha256':sha(o['bindingJson'].encode()),'preparationSha256':sha(o['preparationJson'].encode()),'sourceRequestSha256':sha(o['requestJson'].encode()),'transportInputSha256':sha(encoded(frame).encode())}.items():ck(tag+':report-'+k,report[k],v)
  ck(tag+':report-no-authority',[report['authority'],report['securityReady'],report['nativeAdmission']],[False,False,'required'])
  keyed={k:json.loads(c)for k,c in native_pairs};native_batch={**artifact['disclosureHeader'],'rows':[[keyed[canonical(resource)]]for resource in resources]}
  ck(tag+':native-batch-resource-order',o['nativeBatch'],native_batch)
  ck(tag+':whole-v2-status',o['publicInspection']['status'],'refused'if negative else'validated-disclosure')
  ck(tag+':whole-v2-no-authority',[o['publicInspection']['authority'],o['publicInspection']['complete']],[False,False])
  ck(tag+':inspection-input-source',o['publicInspection']['source'],native_batch)
  for key in ['policy','catalog','closure']:ck(tag+':inspection-original-'+key,o['publicInspection'][key],packet['source'][key])
  ck(tag+':inspection-batch',o['publicInspection']['batch'],None if negative else native_batch)
  if negative is None:ck(tag+':native-batch-equals-producer',native_batch,batch)
 replay.append({'operationIndex':i,'id':o['id'],'negative':negative,'packet':packet,'record':o})
 summaries.append({'index':i,'id':o['id'],'negative':negative,'negativeInputLayer':o['negativeInputLayer'],'nativeRowCount':len(native_pairs),'capturedRowCount':len(captured),'distinctNativeKeys':len(set(k for k,c in native_pairs)),'distinctCellValues':len(set(c for k,c in native_pairs)),'checkerPhase':o['checker']['phase'],'publicInspection':o.get('publicInspection',{}).get('status'),'nativeResourceOrder':[json.loads(k)['key'][0] for k,c in native_pairs],'logicalResourceOrder':[r['key'][0]for r in resources]})
ck('exact-all-recorded-sql-statements',receipt['sqlStatements'],expected_sql);ck('sql-statement-count',len(expected_sql),234)
ck('mixed-empty-native-counts',[s['nativeRowCount']for s in summaries if s['id'].startswith('review-')],[4,0,4,0,4,0])
for s in summaries:
 if s['id'].startswith('review-mixed'):ck(s['id']+':distinct-keys-retain-duplicate-values',s['distinctNativeKeys']>s['distinctCellValues'],True)
ck('supplied-status',receipt['status'],'native-atomic-presence-component-passed');ck('supplied-sources-unchanged',receipt['sourcesUnchanged'],True)
ck('image-digest',receipt['imageId'],'sha256:74935e72241653ca55e0414067e6d8763aceb8a810eb51b452253ec3dcfc4336')
ck('engine-number',receipt['engine']['number'],'180006');ck('engine-encoding',receipt['engine']['encoding'],'UTF8');ck('excluded-admin-identity',[receipt['engine']['currentUser'],receipt['engine']['sessionUser']],['postgres','postgres'])
ck('exact-tmpfs-mount',receipt['mounts'],[{'Type':'tmpfs','Source':'','Destination':'/var/lib/postgresql','Mode':'','RW':True,'Propagation':''}])
cleanup=receipt['cleanup'];name='umf-pg18-atomic-presence-'+receipt['runId'];ck('valid-unique-run-id',str(uuid.UUID(receipt['runId'])),receipt['runId'])
for k in ['attempted','ownedLabelVerified','removed','verified','absentAfterRemoval','containerRemovalVerified','tmpfsOnlyLayoutVerified','storageCleanupVerified']:ck('cleanup:'+k,cleanup[k],True)
ck('cleanup-inspect-exit',cleanup['inspectExitCode'],0);ck('cleanup-remove-exit',cleanup['removeExitCode'],0);ck('cleanup-post-remove-exit',cleanup['postRemoveExitCode'],1);ck('cleanup-post-remove-stdout',cleanup['postRemoveStdout'],'[]\n');ck('cleanup-post-remove-stderr',cleanup['postRemoveStderr'],'error: no such object: '+name+'\n')
ck('cleanup-outcome',cleanup['outcome'],'removed-and-absent');ck('cleanup-storage-scope',cleanup['storageCleanupScope'],'exact tmpfs-only storage and container absence')
ck('terminal-log',json.loads((R/'supplied/native.log').read_text()),{'status':receipt['status'],'operations':52,'observations':869,'cleanupVerified':True})
(R/'replay-inputs.json').write_text(json.dumps(replay,ensure_ascii=False,indent=2)+'\n')
(R/'operation-audit.json').write_text(json.dumps(summaries,ensure_ascii=False,indent=2)+'\n')
(R/'expected-sql.json').write_text(json.dumps(expected_sql,ensure_ascii=False,indent=2)+'\n')
report={'status':'passed'if all(c['passed']for c in checks)else'failed','count':len(checks),'failures':[c for c in checks if not c['passed']],'checks':checks,'receiptSha256':sha(raw),'sourceArchiveSha256':sha(zipraw),'scope':'Independent static audit of supplied native campaign records and current source endpoints; no database execution or fresh daemon observation.'}
(R/'audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k!='checks'}));raise SystemExit(0 if report['status']=='passed'else 1)
