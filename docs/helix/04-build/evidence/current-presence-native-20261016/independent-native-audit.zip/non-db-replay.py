from pathlib import Path
import json,zipfile,hashlib,shutil,subprocess,time
R=Path(__file__).resolve().parent
z=zipfile.ZipFile(R/'supplied/source-inputs.zip');m=json.loads(z.read('manifest.json'))
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
# Complete the external dependency runtime in the fresh source reconstruction.
old=Path('/private/tmp/umf-atomic-presence-handoff-astra-20261016/reconstructed/node_modules');dst=R/'reconstructed-umf/node_modules'
for d in old.iterdir():shutil.copytree(d,dst/d.name,dirs_exist_ok=True)
external={str(p.relative_to(dst)):sha(p.read_bytes())for p in sorted(dst.rglob('*'))if p.is_file()}
(R/'external-runtime-files.json').write_text(json.dumps(external,indent=2)+'\n')
p=[k for k in m if k.endswith('/debug/weft-presence-native-probe')];assert len(p)==1
binary=R/'sources/weft-presence-native-probe';binary.write_bytes(z.read(m[p[0]]['entry']));binary.chmod(0o700);assert sha(binary.read_bytes())=='fa9874ec3a25ed3662eee49fc45320c653f31e4042fbe3536f8faa9d8652e6a4'
inputs=json.loads((R/'replay-inputs.json').read_text());executions=[];checks=[]
def ck(id,actual,expected):
 ok=type(actual)==type(expected)and actual==expected
 checks.append({'id':id,'passed':ok,'actualSha256':sha(enc(actual).encode()),'expectedSha256':sha(enc(expected).encode())})
for x in inputs:
 o=x['record'];tag=str(x['operationIndex'])+':'+x['id']+':'+str(x['negative'])
 commands=[{'requestJson':o['requestJson']},{'bindingJson':o['bindingJson']},{'frameJson':enc(o['frame'])}];text=''.join(enc(c)+'\n'for c in commands)
 start=time.monotonic();p=subprocess.run([str(binary)],input=text,text=True,capture_output=True,timeout=15);elapsed=time.monotonic()-start
 output=[json.loads(line)for line in p.stdout.splitlines()]
 expectedcode=1 if o['checker']['phase']=='refused'else 0
 ck(tag+':exit',p.returncode,expectedcode);ck(tag+':stderr',p.stderr,'');ck(tag+':exact-three-responses',len(output),3)
 if len(output)==3:
  ck(tag+':prepared-phase',output[0]['phase'],'prepared');ck(tag+':same-held-preparation',output[0]['preparationJson'],o['preparationJson']);ck(tag+':compiled-phase',output[1]['phase'],'compiled');ck(tag+':same-issued-artifact',output[1]['artifactJson'],o['artifactJson']);ck(tag+':same-actual-frame-report',output[2],o['checker'])
 executions.append({'operationIndex':x['operationIndex'],'id':x['id'],'negative':x['negative'],'command':[str(binary)],'stdinSha256':sha(text.encode()),'exitCode':p.returncode,'elapsedSeconds':elapsed,'stdout':p.stdout,'stderr':p.stderr})
report={'status':'passed'if all(x['passed']for x in checks)else'failed','count':len(checks),'checks':checks,'executions':executions,'binarySha256':sha(binary.read_bytes()),'nativeDatabaseExecuted':False,'scope':'Independent held-probe replay of recorded supplied native frames; no SQL or Docker. Source-pinned archived issued binary, not a new build.'}
(R/'held-probe-replay.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':report['status'],'checks':len(checks),'operations':len(executions),'failures':[x['id']for x in checks if not x['passed']]}));raise SystemExit(0 if report['status']=='passed'else 1)
