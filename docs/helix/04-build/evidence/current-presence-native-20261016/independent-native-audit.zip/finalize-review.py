from pathlib import Path
import json,hashlib,datetime
R=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):
 p=Path(p);return {'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
def local(name):return pin(R/name)
receipt=json.loads((R/'supplied/receipt.json').read_text())
reports={n:json.loads((R/n).read_text())for n in ['audit.json','provenance-audit.json','held-probe-replay.json','v2-codec-replay.json']}
assert all(x['status']=='passed'for x in reports.values())
review={
 'reviewVersion':'1.0',
 'reviewer':'Retained independent Astra Ultra reviewer /root/astra_retirement_review',
 'date':'2026-10-16',
 'status':'completed',
 'verdict':'Supplied native R5 evidence is internally consistent with its exact captured sources and the independently replayed logical components; no actionable finding within this component scope.',
 'reviewKind':'Independent audit of a supplied actual native campaign, with independent non-database producer/held-probe/whole-V2/codec replay.',
 'nativeDatabaseExecutedByReviewer':False,
 'findings':[],
 'remainingFindings':[],
 'inputs':{
  'nativeReceipt':local('supplied/receipt.json'),
  'sourceArchive':local('supplied/source-inputs.zip'),
  'nativeLog':local('supplied/native.log'),
  'runner':local('sources/pg18-atomic-presence-transport.py'),
  'cleanupHelper':local('sources/native_owned_cleanup.py'),
  'probeSource':local('sources/main.rs'),
  'executedArchivedProbe':local('sources/weft-presence-native-probe'),
  'probeManifest':local('sources/probe-source-manifest.json'),
  'priorPreExecutionReview':json.loads((R/'prior-review-custody.json').read_text()),
 },
 'suppliedCampaign':{
  'runId':receipt['runId'],'status':receipt['status'],
  'operations':52,'positiveOperations':47,'negativeOperations':5,'observations':869,
  'observationsQualification':'869 recorded assertions, including repeated per-operation IDs and repeated evidence comparisons; not 869 unique acceptance requirements.',
  'sqlStatements':234,'capturedSourcePaths':1285,
  'engine':receipt['engine'],'imageId':receipt['imageId'],
  'nativeClaimsReviewed':[
   'The reviewed runner re-executed the original WithinOperation producer and original whole-V2 inspector before each operation. The supplied per-operation observations match the archived authored source/cut/selection and complete result objects.',
   'All 234 recorded SQL statements reconstruct exactly from the archived producer resources/full cell JSON, optional staged mutation and actual issued SQL artifact. The native driver columns are explicitly output_0 then __weft_source_rows.',
   'The independently captured eligible key/cell relation equals the exact expected producer resource population, with ordered capture by private key. The emitted SQL result is checked as a complete key/cell bag. No query ordering guarantee is inferred.',
   'All six mixed/empty supplemental operations have actual driver/capture counts 4,0,4,0,4,0. The three mixed populations retain four unique private keys with 3,1,1 distinct cell values. Duplicate values do not collapse rows. The original census includes denied r2; resources and native eligible rows exclude it.',
   'Original String, null, known absence, withheld, and pure presentation-null cells retain their full V2 cell carrier. Original disclosure of known-absent input correctly emits an absent wire cell. The storage header remains stored-transformed via vault/1; no vault operation or pre-storage substitution is represented.',
   'Four negative operations alter only the checker frame: missing row, duplicate row, SQL-null cell collapse and changed header. Each retains unmodified actual driver rows and refuses generically with no partial nativeBatch/publicInspection result. These are not altered-SQL campaigns.',
   'The fifth negative changes the actual staged full cell JSON to selected occurrence 999/999. Capture and driver agree on that altered cell, structural Rust transport checking succeeds, and the original whole-V2 inspector refuses. This demonstrates the mandatory separate semantic barrier.',
   'All preparation, artifact, binding, request and transport report hashes match the exact recorded bytes. Four original opaque semantic source bytes/identities, the model pin, unadmitted fixture binding and exact producer profile agree with the original producer packet.',
  ],
  'cleanup':{
   'assessment':'Consistent supplied successful owned cleanup evidence, checked against the reviewed exact cleanup implementation; no fresh Docker/daemon inspection was performed by reviewer.',
   'record':receipt['cleanup'],
   'mounts':receipt['mounts'],
   'qualification':'The receipt records exact single tmpfs storage at /var/lib/postgresql, matching ownership label before removal, successful removal, and the exact named-container absence response afterward. Full cleanup requires both container removal and the observed tmpfs-only layout. This is not a general unexpected-volume erasure claim.'
  }
 },
 'independentChecks':[
  {'name':'Archive, endpoint, operation, report, SQL, key/cell bag and cleanup correspondence','checks':7047,'status':'passed','report':local('audit.json')},
  {'name':'Original source/profile/model/census/occurrence correspondence and post-replay endpoints','checks':4666,'status':'passed','report':local('provenance-audit.json')},
  {'name':'Actual held Rust probe on all recorded native request/binding/frame triplets','operations':52,'checks':416,'status':'passed','report':local('held-probe-replay.json'),'qualification':'Executes the exact source-archived supplied binary in fresh processes with actual retained borrowing and checked commands. Preparations, artifacts, reports/refusals and exits reproduce exactly. No new build or database execution in this audit.'},
  {'name':'Fresh actual atomic producer and original whole-V2 JSON/YAML checks','operations':52,'checkedNativeBatches':48,'checks':392,'status':'passed','report':local('v2-codec-replay.json'),'qualification':'All 52 fresh producer results match exactly. The 47 positive native batches round-trip through JSON and YAML. The staged invalid-selection batch reproduces the exact refused inspector verdict and both encoding/decoding refusal channels.'},
 ],
 'custody':{
  'archive': 'All 1285 manifest entries are unique, each archived member hashes to both manifest and receipt pin, and the archive has exactly the declared members plus manifest. Every original current source endpoint matched at initial audit and after non-DB replays.',
  'reconstruction':'The original 102-source UMF generator closure is reconstructed byte-for-byte from the native archive and verified again after replay. All actual opaque semantic source bytes, their digests, model bytes and selected occurrence fields are checked separately.',
  'sourceEndpoints':local('source-endpoints.json'),
  'runtime':local('runtime.json'),
  'externalRuntimeManifest':local('external-runtime-files.json'),
  'qualification':'Source endpoint equality does not establish held-file or ABA resistance. External compiler/runtime/OS/Docker executable closure is not hermetic. The local replay records Bun 1.4.2, Python 3.9.6, Ajv 8.20.0 and YAML 2.9.1; 770 copied external package files are pinned before and checked after replay.',
  'priorReviewUnchanged':True,
  'executionRecords':local('executions.json'),
 },
 'retainedReviewerAttempt':{
  'productFinding':False,
  'qualification':json.loads((R/'reviewer-attempts/qualification.json').read_text()),
  'firstScript':local('reviewer-attempts/first-provenance-audit.py'),
  'firstFailedReport':local('reviewer-attempts/first-provenance-audit.json'),
  'correctedScript':local('provenance-audit.py')
 },
 'scopeLimits':[
  'This is an audit of supplied actual PostgreSQL 18.6 evidence plus independent non-database replays. The reviewer did not execute SQL, create a container, or independently observe the daemon during the supplied campaign.',
  'The fixture executes as excluded administrator postgres. Supplied trusted logical facts, model/source hashes, a read-purpose declaration and an unadmitted fixture binding do not authenticate a native caller/Subject, source, complete current cut, host role/mapping or grant.',
  'The native table materializes already-produced eligible resources. Its SQL eligible flag and complete relation capture test transport of that supplied population; they do not independently implement or prove native membership/authorization joins. The deliberately excluded fixture row tests the SQL eligibility filter only.',
  'The producer census includes denied identities and rule truth; it remains private host/owner composition data, not public query output or reader diagnostics. This review grants no release authority.',
  'The structural transport report remains authority:false, securityReady:false, nativeAdmission:required. Whole UMF semantic validation, closing authenticated source/caller/current-cut checks, native completeness and guarded release remain mandatory host obligations.',
  'No broader operators, transformation/vault authority, default/public runtime ABI, production backend admission or required acceptance case is promoted. Original 158 UMF required cases/34 criteria remain 45 implemented and 113 missing as reported by the existing gate; that broad gate was not rerun in this audit. The original Weft acceptance allocation likewise remains unchanged.',
  'Counts here are component observations and repeated audit assertions, not independent proofs or acceptance coverage totals. The 25 refused original producer packets are retained in source inputs but were not presented as successful native transport operations.',
  'The supplied receipt preserves decoded driver rows, exact SQL strings and runner observations, not an independently signed database transcript. This audit verifies their source-consistent correspondence and reproduces the logical checks without claiming independent native execution.'
 ],
 'disposition':'No additional correction is required for retaining this exact component evidence. Any later source, ABI, role, operator or admission change requires its own qualified review and evidence.'
}
(R/'review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
(R/'README.md').write_text('Independent supplied-native evidence audit — 2026-10-16\n\nThe exact R5 receipt and source archive are retained in supplied/. Review verdict: no actionable finding within the component scope. No Docker or SQL was executed by this reviewer.\n\nThe audit verifies all 1,285 source pins, 234 SQL statements, 52 operation records, complete private-key/cell bags, report pins, whole-V2 correspondence and qualified tmpfs cleanup. Fresh non-database replays reproduce all 52 held-probe responses and producer outputs; the 47 valid batches round-trip through JSON/YAML, and the staged invalid-selection batch refuses whole-V2/codec admission.\n\nSee review.json for exact pins, checks, limitations and the retained corrected reviewer harness attempt. The prior pre-execution review remains unchanged. manifest.json covers every retained file except itself.\n')
files={str(p.relative_to(R)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}for p in sorted(R.rglob('*'))if p.is_file()and p.name!='manifest.json'}
# The source archive itself contains manifest.json; do not accidentally exclude package files with that name in a future layout.
files={str(p.relative_to(R)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}for p in sorted(R.rglob('*'))if p.is_file()and p!=R/'manifest.json'}
manifest={'version':'independent-review-evidence-manifest/1','root':str(R),'files':files,'fileCount':len(files),'qualification':'All retained review files except this manifest; supplied archive contains its own exact 1285-source manifest. No previous review directory was modified.'}
(R/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'review':local('review.json'),'manifest':local('manifest.json'),'fileCount':len(files),'findings':[]},indent=2))
