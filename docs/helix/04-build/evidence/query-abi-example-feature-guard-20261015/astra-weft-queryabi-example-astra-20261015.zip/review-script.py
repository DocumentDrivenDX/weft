from pathlib import Path
import subprocess,hashlib,tomllib,json,difflib,zipfile
R=Path('/private/tmp/weft-queryabi-example-astra-20261015');R.mkdir(exist_ok=False)
S=Path('/private/tmp/weft-queryabi-example-root-review-20261015');base='fa55e7b73117544d6351b0f866abe0d6a28c9f65';repo='/Users/erik/Projects/weft';sha=lambda b:hashlib.sha256(b).hexdigest()
get=lambda rel:subprocess.check_output(['git','-C',repo,'show',base+':'+rel])
before=get('crates/weft-runtime/Cargo.toml');after=(S/'after-Cargo.toml').read_bytes();assert before==(S/'before-Cargo.toml').read_bytes();assert sha(after)=='48eb19d53b7944c24b97bf8630d421d30b30c100a91eb5996a641adcd52176cd'
addition=b'\n[[example]]\nname="compile_truss_query_abi"\nrequired-features=["truss-postgresql-pg18"]\n';assert after==before+addition
b=tomllib.loads(before.decode());a=tomllib.loads(after.decode());expected={'name':'compile_truss_query_abi','required-features':['truss-postgresql-pg18']};assert a['example'][-1]==expected;assert a['example'][:-1]==b['example'];a['example']=a['example'][:-1];assert a==b
callee=get('crates/weft-runtime/src/lib.rs');example=get('crates/weft-runtime/examples/compile_truss_query_abi.rs');assert b'#[cfg(feature="truss-postgresql-pg18")]\npub fn compile_truss_runtime_json' in callee;assert b'weft_runtime::compile_truss_runtime_json' in example
assert b['features']['truss-postgresql-pg18']==['dep:weft-postgresql']
assert all('required-features'in x for x in b['example'])
paths={'before-Cargo.toml':before,'after-Cargo.toml':after,'committed-example.rs':example,'committed-callee.txt':b'\n'.join(callee.splitlines()[484:497])+b'\n'}
logs={}
for label,path in [('original-default-failure','/private/tmp/weft-queryabi-example-default-20261015.log'),('owner-default-fixed','/private/tmp/weft-queryabi-examples-default-fixed-20261015.log'),('owner-explicit-pg18-fixed','/private/tmp/weft-queryabi-example-pg18-fixed-20261015.log')]:
 raw=Path(path).read_bytes();logs[label]={'path':path,'sha256':sha(raw),'bytes':len(raw)};paths[label+'.log']=raw
assert b'E0425'in paths['original-default-failure.log']
assert all(b'Finished `dev` profile'in paths[x+'.log']for x in ['owner-default-fixed','owner-explicit-pg18-fixed'])
assert after==(S/'after-Cargo.toml').read_bytes();assert before==(S/'before-Cargo.toml').read_bytes()
for name,raw in paths.items():(R/name).write_bytes(raw)
(R/'change.diff').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile=base+'/crates/weft-runtime/Cargo.toml',tofile='reviewed/crates/weft-runtime/Cargo.toml')))
report={'status':'no-blocking-packaging-finding','scope':'Independent static four-line Cargo manifest delta review only. No Rust/core/native/CI campaign was run.','base':base,'file':'crates/weft-runtime/Cargo.toml','beforeSha256':sha(before),'afterSha256':sha(after),'semanticDelta':expected,'checks':{'beforeMatchesActualCommittedGitBlob':True,'onlyFourLineAppend':True,'parsedTOMLOnlyOneExampleAddition':True,'exactFeatureNameMatchesCommittedCalleeCfg':True,'featureEnablesActualOptionalDependency':True,'matchesExistingRequiredFeatureExamplePattern':True,'beforeAfterCaptureStable':True},'sourcePins':{'committedRuntimeLib':sha(callee),'committedExample':sha(example)},'effect':'Default examples builds skip this example when its callee is unavailable. Explicit truss-postgresql-pg18 selection admits the example and enables the same original callee; no implementation or SQL/checker/Python meaning changes.','ownerExecutionEvidence':logs,'qualification':'Owner logs show the original E0425 and fixed default/explicit-feature checks finishing; those executions are owner evidence, not independent replays. No future five-platform CI or native acceptance is qualified.','casesPromoted':[],'authority':False}
(R/'review.json').write_text(json.dumps(report,indent=2)+'\n');(R/'review-script.py').write_bytes(Path(__file__).read_bytes())
manifest={p.name:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}for p in R.iterdir()if p.is_file()};(R/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');Z=R.with_suffix('.zip')
with zipfile.ZipFile(Z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(R.iterdir()):z.write(p,p.name)
print(json.dumps({'review':str(R/'review.json'),'reviewSha256':sha((R/'review.json').read_bytes()),'archive':str(Z),'archiveSha256':sha(Z.read_bytes()),'bytes':Z.stat().st_size}))
