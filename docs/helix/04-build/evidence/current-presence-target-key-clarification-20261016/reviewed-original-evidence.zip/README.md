# Canonical target Key clarification

This documentation-only clarification preserves Core R1 source/protocols and its
historical reviewed packet. Canonical UMF0.8 relationshipTarget requires module,
element and key. Its relationshipEndpoint source declares module and element;
that source does not supply an authored Key default. The exact vendored schema
matches committed UMF11b412e4 byte-for-byte (upstream-custody.json).

The actual pinned JSON Schema validator passes five shape controls: original
native graph fixture, missing target Key refusal, null target Key refusal,
source endpoint without a Key, and an unknown Key name that passes shape but
still requires original semantic resolution. Ajv has coercion/defaults/property
removal disabled. This is schema-shape evidence, not full UMF semantic admission,
Key existence/domain comparison, native binding, authorization or release.

CONTRACT015's record-only incomplete report may retain original invalid graph
metadata. Its example now explicitly requires whole-source UMF rejection before
graph/native admission and forbids manufacturing a Key. No factory, old guard,
registration, consumer computation asset, result or acceptance tally changes.

The initial audit invocation used the parent temporary directory and found no
script; zero tests ran. The corrected command is:
`bun docs/helix/04-build/evidence/current-presence-target-key-clarification-20261016/audit.mjs`
from the isolated/reconstructed repository root. The five observed assertions
are retained in audit.json. No source-schema or validator guard was changed.
