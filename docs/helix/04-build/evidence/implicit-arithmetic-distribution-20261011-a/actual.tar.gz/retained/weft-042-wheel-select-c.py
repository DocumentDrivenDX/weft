from pathlib import Path,PurePosixPath
import zipfile,hashlib,stat,json
def choose(primary,closing):
 if primary is None:return closing
 if isinstance(primary,Exception) and not isinstance(closing,Exception):return closing
 return primary
def owned(resource,operation):
 primary=None;result=None
 try:result=operation(resource)
 except BaseException as e:primary=e
 try:resource.close()
 except BaseException as e:primary=choose(primary,e)
 if primary is not None:raise primary
 return result
def read_file(p):return owned(p.open('rb'),lambda f:f.read())
def write_file(p,b):return owned(p.open('xb'),lambda f:f.write(b))
wheel=Path('/private/tmp/weft-042-products-a/wheels/weft_sql-0.1.0-cp39-abi3-macosx_11_0_arm64.whl');out=Path('/private/tmp/weft-042-wheel-selected-a')
def extract(z):
 members=z.infolist();assert len(members)<=64 and len({i.filename for i in members})==len(members);assert sum(i.file_size for i in members)<=32*1024*1024
 records=[];extensions=[]
 for i in members:
  p=PurePosixPath(i.filename);mode=i.external_attr>>16
  assert not p.is_absolute() and '..'not in p.parts and '\\'not in i.filename and not i.flag_bits&1 and stat.S_ISREG(mode)
  b=z.read(i);assert len(b)==i.file_size;records.append({'name':i.filename,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
  if i.filename.endswith('.so'):extensions.append((i.filename,b))
 assert len(extensions)==1
 name,b=extensions[0];assert len(b)==9445488 and hashlib.sha256(b).hexdigest()=='f307f12ef5ea2fe1a5e5897f25b77a0ee317f0003feb137dc731132ced9c8376'
 assert not out.exists();out.mkdir(mode=0o700);p=out/'weft.abi3.so';write_file(p,b);p.chmod(0o444)
 write_file(out/'receipt.json',(json.dumps({'scope':'bounded exact wheel-member extraction only; no installed-wheel qualification','members':records,'selected':name},indent=2)+'\n').encode())

def main():
 assert hashlib.sha256(read_file(wheel)).hexdigest()=='7c15ea437fd4c125f8b5b8acec135681f47aed0f7f789c24f6683f24fcb64ff5' and wheel.stat().st_size<=32*1024*1024
 owned(zipfile.ZipFile(wheel),extract)
if __name__=='__main__':main()
