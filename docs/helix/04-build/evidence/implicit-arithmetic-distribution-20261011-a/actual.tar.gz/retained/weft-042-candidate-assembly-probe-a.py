import sys, json, pathlib, hashlib, importlib.util
command_path, command_sha = sys.argv[1:]
raw = pathlib.Path(command_path).read_bytes()
assert hashlib.sha256(raw).hexdigest() == command_sha
command = json.loads(raw)
def verify():
    for item in command['resources']:
        path = pathlib.Path(item['path'])
        assert not path.is_symlink()
        raw = path.read_bytes()
        assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
verify()
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module
shared = load('count_star_distribution', command['shared'])
codec = load('distribution_codec', command['codec'])
owner = load('implicit_distribution', command['owner'])
checker = load('independent_expectations', command['checker'])
config = json.loads(pathlib.Path(command['config']).read_bytes())
primary = None
try:
    result = owner.assemble_implicit_arithmetic(config, codec, checker.check)
    print(json.dumps({'realizationId': result['realizationId'], 'sourceCommit': result['source']['commit'],
                      'corpus': result['conformance']['corpus']['cases'], 'controls': result['conformance']['controls']['cases']}))
except BaseException as error:
    primary = error
finally:
    try:
        verify()
    except BaseException as error:
        primary = shared.cleanup_primary(primary, error)
if primary is not None:
    raise primary
