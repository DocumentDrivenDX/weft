from pathlib import Path
import importlib.util,json,hashlib,os,stat
meta=Path('/private/tmp/weft-042-products-command-a.json');v=json.loads(meta.read_bytes());root=Path(v['root']);out=Path(v['output']);target=Path(v['target']);limits=v['limits']
s=importlib.util.spec_from_file_location('capture','/private/tmp/ashlar-count-star-installed-cli-capture-a.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
def verify():
 for x in v['sourceFiles']:
  b=Path(x['path']).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
 for x in v['toolFiles']:
  p=Path(x['path']);assert str(p.resolve(strict=True))==x['resolved'];b=p.read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
def target_size():
 total=0
 for d,dirs,files in os.walk(target):
  for n in dirs+files:
   p=Path(d)/n;t=p.lstat()
   if stat.S_ISLNK(t.st_mode):raise ValueError('ownedtarget symlink')
   if stat.S_ISREG(t.st_mode):total+=t.st_size
 return total
verify();assert not out.exists() and not target.exists();out.mkdir(mode=0o700);target.mkdir(mode=0o700);(out/'tmp').mkdir(mode=0o700);primary=None;records=[]
try:
 for command in v['commands']:
  phase=command['phase'];verify();r=c.capture(command['argv'],str(root),v['environment'],out/(phase+'.stdout'),out/(phase+'.stderr'),limits['phaseSeconds'],limits['streamBytes']);item={'phase':phase,'capture':r,'targetBytes':target_size(),'products':[]};records.append(item)
  if r['exitCode']!=0:raise ValueError('component build failed:'+phase)
  if item['targetBytes']>limits['targetLogicalBytes']:raise ValueError('target capacity exceeded')
  products=list(map(Path,command['products']))
  if phase=='python':
   wheels=list((out/'wheels').glob('*.whl'));assert len(wheels)==1;products+=wheels
  if phase=='wasm-bindings':products+=list((out/'web').iterdir())
  for p in products:
   t=p.lstat();assert stat.S_ISREG(t.st_mode) and t.st_size<=limits['artifactBytes'];b=p.read_bytes();item['products'].append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
  verify()
except BaseException as e:primary=e
finally:
 try:verify()
 except BaseException as e:primary=c.select_failure(primary,e)
 stream=None
 try:
  stream=(out/'receipt.json').open('x');stream.write(json.dumps({'sourceCommit':v['sourceCommit'],'commandSha256':hashlib.sha256(meta.read_bytes()).hexdigest(),'records':records,'success':primary is None,'qualification':v['qualification']},indent=2)+'\n');stream.flush()
 except BaseException as e:primary=c.select_failure(primary,e)
 finally:
  if stream is not None:
   try:stream.close()
   except BaseException as e:primary=c.select_failure(primary,e)
if primary is not None:raise primary
