import pathlib, json, hashlib, importlib.util, sys
command_path, expected_sha = sys.argv[1:]
raw = pathlib.Path(command_path).read_bytes()
assert hashlib.sha256(raw).hexdigest() == expected_sha
command = json.loads(raw)
def verify():
    for item in command['resources']:
        p = pathlib.Path(item['path'])
        assert not p.is_symlink()
        raw = p.read_bytes()
        assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
verify()
for key in ('output', 'stdout', 'stderr', 'receipt'):
    p = pathlib.Path(command[key])
    assert not p.exists() and not p.is_symlink()
spec = importlib.util.spec_from_file_location('capture', command['capture'])
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
primary = None
result = None
try:
    result = capture.capture(['/usr/bin/python3', '-I', '-B', '-S', command['probe'], command_path, expected_sha],
                             command['cwd'], {'PATH':'/usr/bin:/bin','LANG':'en_US.UTF-8'},
                             pathlib.Path(command['stdout']), pathlib.Path(command['stderr']),
                             command['timeoutSeconds'], command['streamLimitBytes'])
except BaseException as error:
    primary = error
try:
    verify()
except BaseException as error:
    primary = capture.select_failure(primary, error)
stream = None
try:
    stream = pathlib.Path(command['receipt']).open('x')
    json.dump({'capture':result,'openingClosingCustody':primary is None,'failure':None if primary is None else type(primary).__name__},stream,indent=2)
    stream.write('\n')
except BaseException as error:
    primary = capture.select_failure(primary,error)
finally:
    if stream is not None:
        try: stream.close()
        except BaseException as error: primary = capture.select_failure(primary,error)
if primary is not None: raise primary
if result['exitCode']: raise SystemExit(result['exitCode'])
