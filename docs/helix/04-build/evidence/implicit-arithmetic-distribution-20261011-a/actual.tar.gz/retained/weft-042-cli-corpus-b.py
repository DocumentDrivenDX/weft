"""Finite raw-first CLI semantic capture; expectations are independently authored."""
from pathlib import Path
import importlib.util,json,gzip,hashlib,time,os
META=Path('/private/tmp/weft-042-cli-corpus-command-b.json')
def load(path,name):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def main():
 v=json.loads(META.read_bytes());out=Path(v['output']);records=[];primary=None
 def verify():
  for x in v['resources']:
   b=Path(x['path']).read_bytes()
   if len(b)!=x['bytes'] or hashlib.sha256(b).hexdigest()!=x['sha256']:raise ValueError('resource custody')
 verify();c=load(v['capture'],'capture');checker=load(v['checker'],'checker');assert not out.exists();out.mkdir(mode=0o700);deadline=time.monotonic()+v['wholeSeconds']
 cases=json.loads(gzip.decompress(Path(v['corpus']).read_bytes()))['cases']
 assert len(cases)==94 and len({x['id']for x in cases})==94
 try:
  for i,case in enumerate(cases):
   request=bytes.fromhex(case['requestHex']);p=out/f'{i:03d}.request';p.write_bytes(request)
   item={'id':case['id'],'requestSha256':hashlib.sha256(request).hexdigest()};records.append(item)
   for repeat in range(2):
    left=deadline-time.monotonic()
    if left<=0:raise TimeoutError('whole corpus deadline')
    stdout=out/f'{i:03d}-{repeat}.stdout';stderr=out/f'{i:03d}-{repeat}.stderr'
    observed=c.capture([v['binary']],v['cwd'],v['environment'],stdout,stderr,min(10,left),4*1024*1024,stdin_path=p)
    item.setdefault('captures',[]).append(observed)
    raw=stdout.read_bytes();item.setdefault('responseSha256',[]).append(hashlib.sha256(raw).hexdigest())
    if observed['exitCode']!=0 or stderr.read_bytes():raise ValueError('CLI transport refused')
    response=json.loads(raw);checker.check(case,response)
    if repeat and raw!=(out/f'{i:03d}-0.stdout').read_bytes():raise ValueError('repeat bytes')
   item['semanticPassed']=True
 except BaseException as e:primary=e
 try:verify()
 except BaseException as e:primary=c.select_failure(primary,e)
 receipt={'scope':'actual CLI94 semantic correspondence only; no embedding/index/native qualification','records':records,'success':primary is None,'failure':None if primary is None else type(primary).__name__}
 stream=None
 try:
  stream=(out/'receipt.json').open('x');json.dump(receipt,stream,indent=2);stream.write('\n')
 except BaseException as e:primary=c.select_failure(primary,e)
 finally:
  if stream is not None:
   try:stream.close()
   except BaseException as e:primary=c.select_failure(primary,e)
 if primary is not None:raise primary
 print(json.dumps({'state':'CLI94-semantic-passed','cases':len(records)}))
if __name__=='__main__':main()
