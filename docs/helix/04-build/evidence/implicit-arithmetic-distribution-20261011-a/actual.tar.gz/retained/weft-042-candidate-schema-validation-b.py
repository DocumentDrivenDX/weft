"""Validate only the retained candidate manifest; no index authority or network."""
import sys, json, hashlib, importlib.metadata
from pathlib import Path
import jsonschema
manifest_path, manifest_sha, schema_path, schema_sha = sys.argv[1:]
def load(path, sha):
    p = Path(path)
    assert not p.is_symlink()
    assert p.stat().st_size <= 4 * 1024 * 1024
    raw = p.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == sha
    return json.loads(raw)
schema = load(schema_path, schema_sha)
manifest = load(manifest_path, manifest_sha)
jsonschema.Draft202012Validator.check_schema(schema)
jsonschema.Draft202012Validator(schema).validate(manifest)
assert load(schema_path, schema_sha) == schema
assert load(manifest_path, manifest_sha) == manifest
print(json.dumps({'manifestSha256':manifest_sha,'schemaSha256':schema_sha,'validator':'jsonschema Draft202012Validator','jsonschemaVersion':importlib.metadata.version('jsonschema'),'schemaValidated':True,'qualification':'Closed manifest shape only; no trusted index/native authority'}))
