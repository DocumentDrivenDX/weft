import argparse,pathlib,json,hashlib,importlib.util
p=argparse.ArgumentParser();p.add_argument('--command',required=True);p.add_argument('--sha256',required=True);p.add_argument('--phase',required=True);a=p.parse_args();raw=pathlib.Path(a.command).read_bytes();assert hashlib.sha256(raw).hexdigest()==a.sha256;v=json.loads(raw)
def verify():
 for x in v['resources']:
  p=pathlib.Path(x['path'])
  if 'resolved'in x:assert str(p.resolve(strict=True))==x['resolved']
  else:assert not p.is_symlink()
  b=p.read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
q=next(q for q in v['commands']if q['phase']==a.phase);v['resources'].extend(q.get('dynamicResources',[]));verify();s=importlib.util.spec_from_file_location('capture',v['capture']);c=importlib.util.module_from_spec(s);s.loader.exec_module(c);q=next(q for q in v['commands']if q['phase']==a.phase);out=pathlib.Path(v['output']);
if a.phase=='wheel':assert not out.exists();out.mkdir(mode=0o700)
else:assert out.is_dir()
primary=None;result=None
try:result=c.capture(q['argv'],v['cwd'],v['environment'],pathlib.Path(q['stdout']),pathlib.Path(q['stderr']),q['timeoutSeconds'],4*1024*1024)
except BaseException as e:primary=e
try:verify()
except BaseException as e:primary=c.select_failure(primary,e)
stream=None
try:
 stream=pathlib.Path(q['receipt']).open('x');json.dump({'capture':result,'openingClosingCustody':primary is None,'qualification':v['qualification'],'failure':None if primary is None else type(primary).__name__},stream,indent=2);stream.write('\n')
except BaseException as e:primary=c.select_failure(primary,e)
finally:
 if stream is not None:
  try:stream.close()
  except BaseException as e:primary=c.select_failure(primary,e)
if primary is not None:raise primary
if result['exitCode']:raise SystemExit(result['exitCode'])
