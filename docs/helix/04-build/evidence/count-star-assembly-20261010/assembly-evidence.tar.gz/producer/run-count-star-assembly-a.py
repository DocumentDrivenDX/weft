"""Frozen inert new-profile entrypoint; independently reviewed command only."""
import importlib.util,json,sys
from pathlib import Path
root=Path('/private/tmp/ashlar-weft-distribution-d2d/scripts/distribution')
sys.path.insert(0,str(root))
spec=importlib.util.spec_from_file_location('selected_assembler',root/'assemble-paths-distribution.py')
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
record=module.assemble(module.Config(Path('/private/tmp/weft-count-star-build-20261010-b/source'),Path('/private/tmp/weft-count-star-build-20261010-b'),Path('/private/tmp/ashlar-weft-distribution-d2d'),Path('/private/tmp/weft-count-star-build-20261010-b/realization-count-star-a'),'weft-5ddcebd-count-star-aarch64-apple-darwin-candidate',profile='paths-keys-count-star'))
print(json.dumps({'state':'inert-count-star-candidate-assembled','realizationId':record['realizationId'],'sourceCommit':record['source']['commit'],'scope':'No compiler execution, installation, index or native SQL authority.'}))
