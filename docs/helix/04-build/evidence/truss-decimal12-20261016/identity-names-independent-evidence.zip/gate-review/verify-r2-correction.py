"""Verify packaging-only R2 correction without rerunning unchanged compilers."""
from pathlib import Path,PurePosixPath
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'r2-correction';OUT.mkdir(exist_ok=True)
OLD=Path('/private/tmp/weft-decimal12-identity-names-static-review-20261016.zip')
NEW=Path('/private/tmp/weft-decimal12-identity-names-r2-review-20261016.zip')
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha(OLD.read_bytes())=='e44aeb06bd2bdda9f983f2185b86a9f07d726b873874b40b45f25d1b185fef40'
assert sha(NEW.read_bytes())=='91eedda821dcd0245ecbd8f5d110aba527ffccf4e3d41183aad072f19dbe8c74'
with zipfile.ZipFile(OLD) as a,zipfile.ZipFile(NEW) as b:
 old=json.loads(a.read('source-pins.json'));new=json.loads(b.read('source-pins.json'))
 assert new['base']==old['base'];assert len(old['files'])==17;assert len(new['files'])==18
 checks={p:{'oldSha256':sha(a.read(p)),'newSha256':sha(b.read(p)),'sameBytes':a.read(p)==b.read(p)} for p in old['files']}
 assert all(v['sameBytes'] and v['oldSha256']==old['files'][p]==new['files'][p] for p,v in checks.items())
 added=set(new['files'])-set(old['files']);expected='docs/helix/04-build/releases/v0.4.36.md';assert added=={expected}
 note=b.read(expected);assert sha(note)==new['files'][expected]=='37b90b31891374ecbd68170aebb803a2679b07cca0e62671127c86f97e92eb10'
 assert all(sha(b.read(p))==h for p,h in new['files'].items())
 for p in ['source-pins.json',expected]+[p for p in b.namelist() if p.startswith('observations/')]:
  safe=PurePosixPath(p);assert not safe.is_absolute() and '..' not in safe.parts
  target=OUT/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b.read(p))
 reports={}
 for label,count in [('genuine-northwind',2),('decimal-smoke',20),('refinement-smoke',30),('query-abi-smoke',17)]:
  name=f'weft-identity036-{label}-20261016.json';data=b.read('observations/'+name)
  assert data==(ROOT/'wheel-evidence'/name).read_bytes()
  reports[label]={'count':count,'sha256':sha(data),'matchesAuditedSupplementalReport':True}
 logs={}
 for label,count in [('core',339),('pg',115)]:
  name=f'observations/weft-identity036-{label}-regressions-20261016.log';data=b.read(name)
  assert f'test result: ok. {count} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in data.decode()
  logs[label]={'reportedPassed':count,'sha256':sha(data),'independentlyReexecutedByThisReviewer':False}
result={'scope':__doc__,'base':new['base'],'originalZipSha256':sha(OLD.read_bytes()),'correctedZipSha256':sha(NEW.read_bytes()),'unchangedOriginalFiles':checks,'onlyAddedSourceFile':expected,'addedReleaseNoteSha256':sha(note),'all18ManifestHashesMatch':True,'suppliedRegressionLogs':logs,'suppliedWheelReports':reports,'nativeWorkflowClaim':'Present in R2 source-pins observedTests; excluded from this review because matching before/after candidate-host and final source-bound evidence were not reviewed.','correctedFinding':'Original P2 missing release note is closed for R2 only.','furtherCampaignsPerformed':0}
(OUT/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='unchangedOriginalFiles'},indent=2))
