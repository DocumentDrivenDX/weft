"""Audit supplied local-wheel custody and replay only its two naming controls.
Does not execute native SQL or the other supplied smoke campaigns.
"""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,zipfile
OUT=Path(__file__).resolve().parent/'wheel-evidence'
REVIEW=OUT.parent.parent
WHEEL=Path('/private/tmp/weft-identity036-wheel-20261016/weft_sql-0.4.36-cp39-abi3-macosx_11_0_arm64.whl')
INSTALLED=Path('/private/tmp/weft-identity036-installed-20261016/weft')
BUILD=Path('/private/tmp/weft-decimal12-reconciled-20261016')
CAPTURE=Path('/private/tmp/truss-northwind-genuine-query-capture-20261015/northwind-compile-request.json')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected={'wheelSha256':'25613653fed7a6bbcbaee2c55f653307a96669eab3a64a9e683e204452411dbf','nativeModuleSha256':'7ed33a7ce423c1787073615c8985317846d3e4df817f13667c71a86b08ff261c','shimSha256':'cd0fa27c9580742333d14e24d5ebfd74babb47d31720bb4c577278d05486f11d'}
def pins():return {'wheelSha256':sha(WHEEL),'nativeModuleSha256':sha(INSTALLED/'weft.abi3.so'),'shimSha256':sha(INSTALLED/'__init__.py')}
before=pins();assert before==expected
with zipfile.ZipFile(WHEEL) as z:
 names=[n for n in z.namelist() if n.endswith(('.so','.pyd'))];assert len(names)==1
 assert z.read(names[0])==(INSTALLED/'weft.abi3.so').read_bytes()
 assert z.read('weft/__init__.py')==(INSTALLED/'__init__.py').read_bytes()
 meta=z.read(next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))).decode()
 assert 'Version: 0.4.36\n' in meta
supplied={}
for name in ['genuine-northwind','decimal-smoke','refinement-smoke','query-abi-smoke']:
 p=Path(f'/private/tmp/weft-identity036-{name}-20261016.json');report=json.loads(p.read_text());shutil.copyfile(p,OUT/p.name)
 if name=='query-abi-smoke':assert report['nativeModuleSha256']==expected['nativeModuleSha256'];assert report['compilerControls']==len(report['controls'])==17
 else:
  assert report['pinsBeforeAfter']==expected
  assert report['nativeAdmission'] is False and report['securityReady'] is False
  assert len(report['checks'])=={'genuine-northwind':2,'decimal-smoke':20,'refinement-smoke':30}[name]
 supplied[name]={'sha256':sha(p),'controls':len(report['checks']) if name!='query-abi-smoke' else len(report['controls']),'sourceCommit':report.get('sourceCommit'),'replayedByReviewer':name=='genuine-northwind'}
manifest=json.loads((REVIEW/'packet/source-pins.json').read_text())
assert sha(CAPTURE)==manifest['files']['tests/truss-decimal12/fixtures/genuine-northwind-compile-request.json']
paths=set(subprocess.check_output(['git','-C','/Users/erik/Projects/weft','ls-tree','-r','--name-only',manifest['base']],text=True).splitlines())|set(manifest['files'])
# Current build-source correspondence, not historical before/after build attestation.
diffs=[]
for p in sorted(paths):
 a=REVIEW/'reconstructed'/p;b=BUILD/p
 if not a.is_file() or not b.is_file() or sha(a)!=sha(b):diffs.append({'path':p,'frozen':sha(a) if a.is_file() else None,'buildSource':sha(b) if b.is_file() else None})
script=Path('/private/tmp/verify-weft-identity036-genuine-northwind.py');shutil.copyfile(script,OUT/script.name);shutil.copyfile(WHEEL,OUT/WHEEL.name);shutil.copyfile(CAPTURE,OUT/'genuine-request.json');shutil.copyfile('/private/tmp/weft-identity036-wheel-build-20261016.log',OUT/'build.log')
env=dict(os.environ,PYTHONPATH=str(INSTALLED.parent))
cmd=['/Users/erik/.local/bin/python3.11','-B',str(OUT/script.name),'--wheel',str(OUT/WHEEL.name),'--output',str(OUT/'independent-genuine-northwind.json')]
r=subprocess.run(cmd,cwd=OUT,env=env,capture_output=True,text=True)
(OUT/'independent-genuine.stdout').write_text(r.stdout);(OUT/'independent-genuine.stderr').write_text(r.stderr)
result={'scope':__doc__,'pinsBefore':before,'pinsAfter':pins(),'pinsUnchanged':before==pins(),'captureMatchesFrozenRequest':True,'currentBuildSourceComparedFiles':len(paths),'currentBuildSourceDifferences':diffs,'suppliedReports':supplied,'independentReplay':{'command':cmd,'exitCode':r.returncode,'controls':2},'nativeExecutions':0,'fivePlatformCohort':False,'sourceCommitAttestation':False,'artifactHashes':{p.name:sha(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='audit.json'}}
(OUT/'audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='artifactHashes'},indent=2))
assert r.returncode==0 and before==pins()
