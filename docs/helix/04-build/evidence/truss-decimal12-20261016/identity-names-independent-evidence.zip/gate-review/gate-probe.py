"""Independent synthetic mutation checks for the frozen publication validator.
No wheel, compiler, native runtime, network, or publication is executed.
"""
from pathlib import Path
from copy import deepcopy
import hashlib, json, runpy, subprocess, sys, zipfile

ROOT = Path('/private/tmp/weft-decimal12-identity-names-astra-20261016/packet')
OUT = Path(__file__).resolve().parent
COMMIT = '1' * 40
VERSION = '0.4.36'
# Independently spelled out case identities and states from the requested surface.
POSITIVES = ['projection', 'exact-parameter-0', 'exact-parameter-1', 'exact-parameter-2',
 'exact-parameter-3', 'exact-parameter-4', 'exact-parameter-5']
NEGATIVES = ['nonrepresentable-0', 'nonrepresentable-1', 'nonrepresentable-2',
 'nonrepresentable-3', 'nonrepresentable-4', 'nonrepresentable-5', 'nonrepresentable-6',
 'old-version-0.4.38', 'old-version-0.4.37']
EXPECTED = [{'id':i, 'status':'compiled'} for i in POSITIVES] + [
 {'id':i, 'status':'blocked'} for i in NEGATIVES] + [
 {'id':'related-decimal-key', 'status':'compiled'},
 {'id':'first-typed-page', 'status':'compiled'},
 {'id':'next-typed-page', 'status':'compiled'},
 {'id':'bad-typed-page', 'status':'blocked'}]
WHEELS = ['linux-x86_64.whl', 'linux-aarch64.whl', 'macos-arm64.whl', 'macos-x86_64.whl', 'windows-amd64.whl']
BASE = [{'wheel':w, 'pinsBeforeAfter':{k:hashlib.sha256((w+k).encode()).hexdigest()
 for k in ['wheelSha256','nativeModuleSha256','shimSha256']}} for w in WHEELS]
REPORTS = [dict(deepcopy(b), sourceCommit=COMMIT, version=VERSION, controls=20,
 nativeAdmission=False, securityReady=False, checks=deepcopy(EXPECTED)) for b in BASE]
validate = runpy.run_path(str(ROOT/'scripts/release/verify-decimal12-smoke.py'))['validate']
results=[]

def trial(name, edit=lambda r,b:None, accepted=False):
 r,b=deepcopy(REPORTS),deepcopy(BASE)
 edit(r,b)
 # All mutation inputs are actual JSON-representable structures.
 r,b=json.loads(json.dumps(r)),json.loads(json.dumps(b))
 try:
  validate(r,b,COMMIT,VERSION)
  got=True;error=None
 except Exception as exc:
  got=False;error=type(exc).__name__
 results.append({'id':name,'expected':'accepted' if accepted else 'rejected',
  'observed':'accepted' if got else 'rejected','exception':error,'pass':got==accepted})

trial('valid-five-wheel-twenty-case-control',accepted=True)
trial('report-order-independent',lambda r,b:r.reverse(),True)
trial('baseline-order-independent',lambda r,b:b.reverse(),True)
trial('both-orders-independent',lambda r,b:(r.reverse(),b.reverse()),True)
trial('missing-report',lambda r,b:r.pop())
trial('extra-report',lambda r,b:r.append(deepcopy(r[0])))
trial('missing-baseline',lambda r,b:b.pop())
trial('extra-baseline',lambda r,b:b.append(deepcopy(b[0])))
trial('duplicate-report',lambda r,b:r.__setitem__(1,deepcopy(r[0])))
trial('duplicate-baseline',lambda r,b:b.__setitem__(1,deepcopy(b[0])))
trial('unmatched-wheel',lambda r,b:r[0].update(wheel='other.whl'))
trial('wrong-expected-commit',lambda r,b:[x.update(sourceCommit='2'*40) for x in r])
trial('wrong-expected-version',lambda r,b:[x.update(version='0.4.35') for x in r])
for i in range(5):
 for field in ['wheel','sourceCommit','version','controls','nativeAdmission','securityReady','pinsBeforeAfter','checks']:
  trial(f'wheel-{i}-missing-{field}',lambda r,b,i=i,f=field:r[i].pop(f))
  trial(f'wheel-{i}-null-{field}',lambda r,b,i=i,f=field:r[i].update({f:None}))
 for field in ['sourceCommit','version','wheel']:
  for value in ['',False,0,{},[]]:
   trial(f'wheel-{i}-bad-{field}-{repr(value)}',lambda r,b,i=i,f=field,v=value:r[i].update({f:v}))
 for value in [True,False,20.0,'20',19,21,-1,[],{}]:
  trial(f'wheel-{i}-bad-control-{repr(value)}',lambda r,b,i=i,v=value:r[i].update(controls=v))
 for field in ['nativeAdmission','securityReady']:
  for value in [True,0,1,'false',[],{}]:
   trial(f'wheel-{i}-bad-authority-{field}-{repr(value)}',lambda r,b,i=i,f=field,v=value:r[i].update({f:v}))
 for pin in ['wheelSha256','nativeModuleSha256','shimSha256']:
  trial(f'wheel-{i}-missing-pin-{pin}',lambda r,b,i=i,p=pin:r[i]['pinsBeforeAfter'].pop(p))
  trial(f'wheel-{i}-changed-pin-{pin}',lambda r,b,i=i,p=pin:r[i]['pinsBeforeAfter'].update({p:'f'*64}))
 trial(f'wheel-{i}-swapped-pins',lambda r,b,i=i:r[i].update(pinsBeforeAfter=deepcopy(r[(i+1)%5]['pinsBeforeAfter'])))
 trial(f'wheel-{i}-empty-checks',lambda r,b,i=i:r[i].update(checks=[]))
 trial(f'wheel-{i}-reversed-checks',lambda r,b,i=i:r[i]['checks'].reverse())
 trial(f'wheel-{i}-extra-check',lambda r,b,i=i:r[i]['checks'].append({'id':'extra','status':'compiled'}))
 for j in range(20):
  trial(f'wheel-{i}-case-{j}-missing',lambda r,b,i=i,j=j:r[i]['checks'].pop(j))
  trial(f'wheel-{i}-case-{j}-duplicate',lambda r,b,i=i,j=j:r[i]['checks'].__setitem__(j,deepcopy(r[i]['checks'][(j+1)%20])))
  trial(f'wheel-{i}-case-{j}-wrong-identity',lambda r,b,i=i,j=j:r[i]['checks'][j].update(id='unknown'))
  trial(f'wheel-{i}-case-{j}-wrong-status',lambda r,b,i=i,j=j:r[i]['checks'][j].update(status='wrong'))
  trial(f'wheel-{i}-case-{j}-extra-field',lambda r,b,i=i,j=j:r[i]['checks'][j].update(extra=True))
  trial(f'wheel-{i}-case-{j}-missing-identity',lambda r,b,i=i,j=j:r[i]['checks'][j].pop('id'))
  trial(f'wheel-{i}-case-{j}-missing-status',lambda r,b,i=i,j=j:r[i]['checks'][j].pop('status'))

observed={'sourceCommit':None}
trial('synthetic-null-source-commit-is-not-release-evidence',
 lambda r,b:[x.update(sourceCommit=observed['sourceCommit']) for x in r])

supplied=subprocess.run([sys.executable,'-B',str(ROOT/'scripts/release/test-decimal12-smoke-gate.py')],capture_output=True,text=True)
(OUT/'supplied-gate-controls.stdout').write_text(supplied.stdout)
(OUT/'supplied-gate-controls.stderr').write_text(supplied.stderr)
pins=json.loads((ROOT/'source-pins.json').read_text())
hashes={p:{'expected':h,'actual':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()} for p,h in pins['files'].items()}
result={'scope':__doc__,'python':sys.version,'executable':sys.executable,'base':pins['base'],
 'zipSha256':hashlib.sha256(Path('/private/tmp/weft-decimal12-identity-names-static-review-20261016.zip').read_bytes()).hexdigest(),
 'sourcePins':hashes,'sourceHashesMatch':all(v['expected']==v['actual'] for v in hashes.values()),
 'suppliedTestExitCode':supplied.returncode,'suppliedTestStdout':supplied.stdout.strip(),
 'probeSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'controls':len(results),'passed':sum(r['pass'] for r in results),
 'accepted':sum(r['observed']=='accepted' for r in results),'rejected':sum(r['observed']=='rejected' for r in results),
 'failures':[r for r in results if not r['pass']], 'results':results}
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['sourcePins','results']},indent=2))
assert result['sourceHashesMatch'] and supplied.returncode==0 and not result['failures']
