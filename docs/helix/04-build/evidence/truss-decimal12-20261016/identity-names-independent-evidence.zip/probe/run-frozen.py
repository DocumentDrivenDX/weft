from pathlib import Path
import json,os,hashlib,subprocess,time
P=Path(__file__).parent;R=P.parent/'reconstructed';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def sources():
 files=[]
 for dirname in ['crates','tests','spec','vendor','.cargo','spikes','docs/helix/02-design/contracts']:
  for here,dirs,names in os.walk(R/dirname):
   dirs[:]=[d for d in dirs if d not in {'target','.git','.venv','node_modules','__pycache__'}]
   files.extend(Path(here)/n for n in names if not n.endswith('.pyc'))
 files.extend(R/n for n in ['Cargo.toml','Cargo.lock'])
 return {str(p.relative_to(R)):sha(p) for p in sorted(set(files))}
before=sources();env=dict(os.environ,CARGO_HOME='/private/tmp/weft-toolchain/cargo',CARGO_TARGET_DIR=str(P.parent/'target'),PATH='/Users/erik/.rustup/toolchains/1.90.0-aarch64-apple-darwin/bin:/opt/homebrew/bin:/usr/bin:/bin');commands=[['cargo','build','--manifest-path',str(P/'Cargo.toml'),'--locked','--offline'],['python3',str(P/'naming-controls.py')],['python3',str(P.parent/'decimal-controls/run-controls.py')]]
start=time.monotonic();results=[]
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,env=env,capture_output=True);(P/f'pinned-{i}.stdout').write_bytes(r.stdout);(P/f'pinned-{i}.stderr').write_bytes(r.stderr);results.append({'command':cmd,'exitCode':r.returncode});assert r.returncode==0,(cmd,r.stderr.decode())
after=sources();assert before==after
n=json.loads((P/'naming-results.json').read_text());d=json.loads((P.parent/'decimal-controls/controls-result.json').read_text());assert not n['unexpected']and not d['unexpected']
owner=Path('/private/tmp/weft-decimal12-reconciled-20261016');differences=[name for name,h in before.items()if not (owner/name).is_file()or sha(owner/name)!=h]
report={'commands':results,'elapsedSeconds':time.monotonic()-start,'sourceDigests':before,'sourceInputCount':len(before),'sourcesUnchanged':True,'ownerExportDifferences':differences,'namingControls':n['count'],'freshDecimalControls':d['cases'],'controlsPassed':n['count']+d['cases'],'binarySha256':sha(P.parent/'target/debug/identity-name-review-probe'),'scope':'Fresh reconstructed compiler evidence; no native, browser or wheel execution in this probe.'}
(P/'execution.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='sourceDigests'},indent=2))
