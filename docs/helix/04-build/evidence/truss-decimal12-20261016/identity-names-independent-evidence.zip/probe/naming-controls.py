from pathlib import Path
import json,copy,hashlib,subprocess,time
P=Path(__file__).parent;R=P.parent/'reconstructed';BIN=P.parent/'target/debug/identity-name-review-probe'
sha=lambda b:hashlib.sha256(b).hexdigest()
compact=lambda v:json.dumps(v,separators=(',',':'),ensure_ascii=False)
template=json.loads((R/'tests/truss-query-abi/fixtures/native-query-bundle.json').read_text())
def request(sql='SELECT a."A-value" FROM "A" a',names=None,rename=None,facets=None,version='0.4.39'):
 b=copy.deepcopy(template);d=json.loads(b['modules'][0]['documentJson']);bind=json.loads(b['bindingJson'])
 if names is not None:
  for e in d['modules'][0]['elements']:
   if e['id'] in names:
    if names[e['id']] is None:e.pop('name',None)
    else:e['name']=names[e['id']]
 if facets:
  for e in d['modules'][0]['elements']:
   if e['id'] in facets:e['scalarType']='decimal';e['facets']=facets[e['id']]
 if rename:
  def walk(v):
   if isinstance(v,str):return rename.get(v,v)
   if isinstance(v,list):return [walk(x)for x in v]
   if isinstance(v,dict):return {k:walk(x)for k,x in v.items()}
   return v
  d=walk(d);bind=walk(bind)
 raw=compact(d);b['modules'][0]['documentJson']=raw;b['modules'][0]['pin']['sha256']=sha(raw.encode());bind['documents'][0]['sha256']=sha(raw.encode());rawb=compact(bind)
 return dict(interfaceVersion='weft-compile/0.2.6',dialect='weft-sql/0.2.0',timestampComparisonProfile='umf-rfc3339-exact-instant/1.0.0',modules=b['modules'],sql=sql,parameters={},exactParameters={},options={'allowCandidate':True},target=dict(backendId='truss.postgresql.runtime',backendVersion=version,targetProfile='truss-runtime-pg18.6/0.5',bindingJson=rawb,bindingSha256=sha(rawb.encode())))
C=[]
def add(name,r,want='compiled',mode='compile',after=None,code=None,calls=None,labels=None):C.append(dict(name=name,input={'request':compact(r),'mode':mode,'after':after,'size':2},want=want,code=code,calls=calls,labels=labels))
missing={'A':None,'B':None,'A-value':None,'A-label':None,'B-value':None,'B-label':None}
for v in ['0.4.38','0.4.39']:
 for names,label in [({},'all_authored'),({'A':None},'record_missing'),({'A-value':None,'A-label':None},'member_missing'),(missing,'all_missing')]:
  for mode,sql in [('compile','SELECT a."A-value" FROM "A" a'),('compile','SELECT a.* FROM "A" a'),('page','SELECT a.* FROM "A" a'),('compile','SELECT RELATED_KEYS(a.children, 4) FROM "A" a')]:
   ok=not names or v=='0.4.39'
   add(f'{v}_{label}_{mode}_{sql}',request(sql,names,version=v),'compiled'if ok else'blocked',mode,after=['v','l']if mode=='page'else None)
for names,query,want,name in [({'A':'Displayed'},'SELECT a."A-value" FROM "A" a','blocked','record_id_not_alias'),({'A':'Displayed'},'SELECT a."A-value" FROM "Displayed" a','compiled','authored_record_wins'),({'A-value':'Displayed'},'SELECT a."A-value" FROM "A" a','blocked','field_id_not_alias'),({'A-value':'Displayed'},'SELECT a."Displayed" FROM "A" a','compiled','authored_field_wins')]:
 for v in ['0.4.38','0.4.39']:add(name+v,request(query,names,version=v),want)
for sql,mode,name in [('SELECT a."A-value" FROM "A" a','compile','qualified'),('SELECT a.* FROM "A" a','compile','wildcard'),('SELECT a.* FROM "A" a','page','page_key')]:
 add('field_collision_'+name,request(sql,{'A-value':None,'A-label':'A-value'}),'blocked',mode)
add('record_collision',request(names={'A':None,'B':'A'}),'blocked',code='WFT-NAME-AMBIGUOUS')
for v in ['0.4.38','0.4.39']:add('legacy_case_distinct_wildcard_'+v,request('SELECT a.* FROM \"A\" a',{'A-value':'Token','A-label':'token'},version=v),'compiled')
for sql,want,name in [('SELECT a.token FROM "A" a','blocked','fold_collision'),('SELECT a."Token" FROM "A" a','compiled','quoted_upper'),('SELECT a."token" FROM "A" a','compiled','quoted_lower'),('SELECT a."TOKEN" FROM "A" a','blocked','quoted_wrong_case'),('SELECT a.* FROM "A" a','compiled','wildcard_case_distinct_labels')]:
 add(name,request(sql,missing,rename={'A-value':'Token','A-label':'token'}),want)
for sql,want,name in [('SELECT a.token FROM "A" a','compiled','fold_match'),('SELECT a.TOKEN FROM "A" a','compiled','fold_match_upper'),('SELECT a."Token" FROM "A" a','compiled','quoted_exact'),('SELECT a."token" FROM "A" a','blocked','quoted_case_refusal')]:
 add(name,request(sql,missing,rename={'A-value':'Token'}),want)
for sql,want,name in [('SELECT a."A-value" FROM a a','compiled','record_unquoted_fold'),('SELECT a."A-value" FROM "a" a','blocked','record_quoted_exact'),('SELECT a."A-value" FROM m.A a','compiled','namespace_record'),('SELECT a."A-value" FROM wrong.A a','blocked','namespace_refusal')]:add(name,request(sql,missing),want)
# Exact literal-dot IDs remain distinct from field path syntax.
for sql,want,name in [('SELECT a."value.part" FROM "A" a','compiled','quoted_dot'),('SELECT a.value.part FROM "A" a','blocked','unquoted_dot'),('SELECT a."semi; SELECT" FROM "A" a','compiled','quoted_semicolon')]:
 add(name,request(sql,missing,rename={'A-value':'semi; SELECT'if'semi'in name else'value.part'}),want)
for mode in ['core_ordinary','core_exact','core_identity','core_string','core_old','core_new']:
 add('core_factory_'+mode,request('SELECT a.* FROM "A" a',missing),'blocked',mode,calls=1 if mode in ['core_identity','core_new']else 0)
for names,label in [(missing,'ids'),({'A-value':'Price'},'authored')]:
 sql='SELECT a.* FROM "A" a'
 for token,ok in [('9999999999.9900',True),('10000000000.00',False),('0.001',False)]:
  add('decimal_page_'+label+'_'+token,request(sql,names,facets={'A-value':{'precision':12,'scale':2}}),'compiled'if ok else'blocked','page',after=[token,'label'])
# Bare-name resolution retains exact-one-visible-member rules in predicates.
for sql,want,name in [('SELECT a."A-value" FROM "A" a WHERE "A-label"=\'x\'','blocked','bare_unqualified_outside_dialect'),('SELECT a."A-value" FROM "A" a JOIN "B" b ON a."A-value"=b."B-value" WHERE value=\'x\'','blocked','bare_ambiguous')]:
 ren={'A-label':'value','B-label':'value'} if name=='bare_ambiguous' else None
 add(name,request(sql,missing,rename=ren),want)
# Empty or null authored names do not silently opt into ID naming.
for v in [None,'',7]:
 r=request();d=json.loads(r['modules'][0]['documentJson']);next(e for e in d['modules'][0]['elements'] if e['id']=='A')['name']=v
 raw=compact(d);r['modules'][0]['documentJson']=raw;r['modules'][0]['pin']['sha256']=sha(raw.encode());b=json.loads(r['target']['bindingJson']);b['documents'][0]['sha256']=sha(raw.encode());r['target']['bindingJson']=compact(b);r['target']['bindingSha256']=sha(r['target']['bindingJson'].encode());add('malformed_authored_name_'+str(v),r,'blocked')
genuine=json.loads((R/'tests/truss-decimal12/fixtures/genuine-northwind-compile-request.json').read_text())
for v in ['0.4.38','0.4.39']:
 r=copy.deepcopy(genuine);r['target']['backendVersion']=v;add('genuine_untouched_'+v,r,'compiled'if v=='0.4.39'else'blocked')
(P/'naming-inputs.json').write_text(json.dumps(C,indent=2,ensure_ascii=False)+'\n')
start=time.monotonic();r=subprocess.run([str(BIN)],input=''.join(compact(x['input'])+'\n'for x in C),text=True,capture_output=True);(P/'naming.stdout').write_text(r.stdout);(P/'naming.stderr').write_text(r.stderr);assert r.returncode==0,r.stderr
rows=[json.loads(l)for l in r.stdout.splitlines()];assert len(rows)==len(C)
results=[]
for c,o in zip(C,rows):
 v=o['result'];a=v.get('artifact',v);status=v['status'];code=(v.get('diagnostics')or[{}])[0].get('code');matched=status==c['want'] and (c['code']is None or code==c['code']) and(c['calls']is None or o['factoryCalls']==c['calls']);results.append({'name':c['name'],'matched':matched,'status':status,'code':code,'factoryCalls':o['factoryCalls']})
 if status=='compiled':
  rr=json.loads(c['input']['request']);assert any(p.get('value')==rr['target']['bindingJson']for p in a['parameters']);assert a.get('backend',{}).get('backendVersion')==rr['target']['backendVersion']
report={'count':len(C),'exitCode':r.returncode,'unexpected':[x for x in results if not x['matched']],'results':results,'elapsedSeconds':time.monotonic()-start};(P/'naming-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='results'},indent=2))
