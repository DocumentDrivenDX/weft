from pathlib import Path
import json,os,shutil,subprocess,hashlib
P=Path(__file__).parent;R=P/'replay';W=Path('/private/tmp/weft-identity036-wheel-20261016/weft_sql-0.4.36-cp39-abi3-macosx_11_0_arm64.whl');N=P/'smoke-negatives';N.mkdir(exist_ok=True);(N/'malformed.whl').write_text('not a wheel')
missing=N/'missing-genuine-root'
for n in ['tests/truss-decimal12/wheel-smoke.py','tests/truss-query-abi/fixtures/native-query-bundle.json','crates/weft-python/pyproject.toml']:
 out=missing/n;out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,out)
env=dict(os.environ,PYTHONPATH='/private/tmp/weft-identity036-installed-20261016',PYTHONDONTWRITEBYTECODE='1');tests=[('missing-wheel',R/'tests/truss-decimal12/wheel-smoke.py',N/'missing.whl'),('wheel-is-directory',R/'tests/truss-decimal12/wheel-smoke.py',N),('malformed-wheel',R/'tests/truss-decimal12/wheel-smoke.py',N/'malformed.whl'),('missing-genuine-fixture',missing/'tests/truss-decimal12/wheel-smoke.py',W)];out=[]
for name,script,wheel in tests:
 report=N/(name+'.json');assert not report.exists()
 cmd=['/Users/erik/.local/bin/python3.11','-B',str(script),'--wheel',str(wheel),'--output',str(report)];r=subprocess.run(cmd,env=env,capture_output=True);(N/(name+'.stdout')).write_bytes(r.stdout);(N/(name+'.stderr')).write_bytes(r.stderr);assert r.returncode!=0 and not report.exists()
 out.append({'name':name,'command':cmd,'exitCode':r.returncode,'reportProduced':report.exists()})
(N/'results.json').write_text(json.dumps({'controls':len(out),'allRefused':True,'results':out},indent=2)+'\n');print('negative smoke controls:',len(out),'passed')
