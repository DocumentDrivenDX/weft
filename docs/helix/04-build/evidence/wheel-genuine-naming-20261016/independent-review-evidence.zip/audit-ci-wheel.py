from pathlib import Path
import hashlib,json,zipfile,shutil,os,subprocess
P=Path(__file__).parent;D=P/'ci-supplement';D.mkdir(exist_ok=True);S=Path('/private/tmp/weft036-ci-arm-38848945807');I=Path('/private/tmp/weft036-ci-arm-installed-38848945807');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for f in S.iterdir():
 if f.is_file():shutil.copy2(f,D/f.name)
v=json.loads((D/'verified-artifact.json').read_text());W=next(D.glob('*.whl'));native=next((I/'weft').glob('*.so'));pins={'wheelSha256':sha(W),'nativeModuleSha256':sha(native),'shimSha256':sha(I/'weft/__init__.py')};assert pins==v['pins']
with zipfile.ZipFile(W)as z:
 mods=[n for n in z.namelist()if n.endswith(('.so','.pyd'))];assert len(mods)==1;assert z.read(mods[0])==native.read_bytes();assert z.read('weft/__init__.py')==(I/'weft/__init__.py').read_bytes()
counts=[]
for item in v['reports']:
 r=json.loads((D/item['file']).read_text());assert r['pinsBeforeAfter']==pins and r['sourceCommit']==v['sourceCommit']and r['version']=='0.4.36';assert r['nativeAdmission']is False and r['securityReady']is False
 count=r.get('controls',len(r['checks']));assert count==item['controls'];counts.append({'file':item['file'],'controls':count,'sha256':sha(D/item['file'])})
source=json.loads((P/'reconstruction.json').read_text())['sourceDigests'];assert all(sha(P/'replay'/n)==h for n,h in source.items())
cmd=['/Users/erik/.local/bin/python3.11','-B',str(P/'replay/tests/truss-decimal12/wheel-smoke.py'),'--wheel',str(W),'--output',str(D/'independent-expanded22.json')];env=dict(os.environ,PYTHONPATH=str(I),PYTHONDONTWRITEBYTECODE='1');r=subprocess.run(cmd,env=env,capture_output=True);(D/'stdout').write_bytes(r.stdout);(D/'stderr').write_bytes(r.stderr);assert r.returncode==0,r.stderr
new=json.loads((D/'independent-expanded22.json').read_text());assert new['controls']==22 and new['sourceCommit']is None and new['pinsBeforeAfter']==pins;assert new==json.loads((D/'expanded22-local-smoke.json').read_text());assert pins=={'wheelSha256':sha(W),'nativeModuleSha256':sha(native),'shimSha256':sha(I/'weft/__init__.py')};assert all(sha(P/'replay'/n)==h for n,h in source.items())
report={'scope':'Independently checked supplied build-only CI ARM wheel and four original reports; independently replayed final expanded22 script locally. Not a22caseCIcohort or publication/native qualification.','suppliedRunId':v['runId'],'suppliedOriginalSourceCommit':v['sourceCommit'],'originalReportCounts':counts,'pinsBeforeAfter':pins,'exactArchiveInstalledModuleAndShimMatch':True,'command':cmd,'exitCode':r.returncode,'newLocalControls':22,'newLocalSourceCommit':None,'newLocalReportMatchesSuppliedExpandedReport':True,'frozenReviewInputHashesUnchanged':True,'nativeSqlExecutions':0,'realWheelPlatforms':1};(D/'audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
