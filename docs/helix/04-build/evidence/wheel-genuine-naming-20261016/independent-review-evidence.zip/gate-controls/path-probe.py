"""Synthetic archive/report-path controls using exact base workflow preflight.
Dummy archive entries are bytes only: no installed wheel, native SQL or publication.
"""
from pathlib import Path
from types import SimpleNamespace
import hashlib,json,os,pathlib,runpy,subprocess,sys,textwrap,zipfile
OUT=Path(__file__).resolve().parent
PACKET=OUT.parent/'packet'
COMMIT='a'*40;VERSION='0.4.36'
workflow=subprocess.check_output(['git','-C','/Users/erik/Projects/weft','show','1ed81c11fa870d57ba21d4339132ff139b05641d:.github/workflows/release.yml'],text=True)
# Exact wheel/baseline validation section; inject its already-resolved version/commit.
preflight=textwrap.dedent('\n'.join(workflow.splitlines()[156:171]))
assert preflight.startswith("root=pathlib.Path('dist')")
(OUT/'base-workflow-preflight.py.txt').write_text(preflight+'\n')
gate=runpy.run_path(str(PACKET/'scripts/release/verify-decimal12-smoke.py'))
results=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def trial(name,edit=lambda p:None,expected=False):
 case=OUT/'path-fixtures'/name;dist=case/'dist';dist.mkdir(parents=True,exist_ok=True)
 for i in range(5):
  wheel=f'wheel-{i}.whl';native=f'native-{i}'.encode();shim=b'shim'
  with zipfile.ZipFile(dist/wheel,'w') as z:
   z.writestr('weft/native.so',native);z.writestr('weft/__init__.py',shim)
  pins={'wheelSha256':sha((dist/wheel).read_bytes()),'nativeModuleSha256':sha(native),'shimSha256':sha(shim)}
  baseline={'wheel':wheel,'sourceCommit':COMMIT,'version':VERSION,'pinsBeforeAfter':pins,'checks':[{}, {}, {}, {'id':'no-context-downgrade','refused':True}],'nativeAdmission':False,'securityReady':False}
  report=dict(baseline,controls=22,checks=gate['EXPECTED'])
  (dist/f'current-query-smoke-{i}.json').write_text(json.dumps(baseline))
  (dist/f'truss-decimal12-smoke-{i}.json').write_text(json.dumps(report))
 edit(dist)
 previous=os.getcwd()
 try:
  os.chdir(case)
  ns={'pathlib':pathlib,'hashlib':hashlib,'json':json,'zipfile':zipfile,'subprocess':SimpleNamespace(check_output=lambda *a,**k:COMMIT),'version':VERSION}
  exec(preflight,ns)
  decimal=[json.loads(p.read_text()) for p in sorted(ns['root'].glob('truss-decimal12-smoke-*.json'))]
  gate['validate'](decimal,ns['smoke'],COMMIT,VERSION)
  accepted=True;error=None
 except Exception as e:accepted=False;error=type(e).__name__
 finally:os.chdir(previous)
 results.append({'id':name,'expectedAccepted':expected,'accepted':accepted,'pass':accepted==expected,'exception':error})
def change(p,file,key,value):
 f=p/file;r=json.loads(f.read_text());r[key]=value;f.write_text(json.dumps(r))
def copy(p,a,b):(p/b).write_bytes((p/a).read_bytes())
trial('valid',expected=True)
trial('missing-wheel',lambda p:(p/'wheel-0.whl').unlink())
trial('extra-wheel',lambda p:copy(p,'wheel-0.whl','wheel-5.whl'))
trial('missing-baseline-report',lambda p:(p/'current-query-smoke-0.json').unlink())
trial('duplicate-baseline-wheel',lambda p:copy(p,'current-query-smoke-0.json','current-query-smoke-1.json'))
trial('missing-naming-report',lambda p:(p/'truss-decimal12-smoke-0.json').unlink())
trial('duplicate-naming-wheel',lambda p:copy(p,'truss-decimal12-smoke-0.json','truss-decimal12-smoke-1.json'))
trial('extra-naming-report',lambda p:copy(p,'truss-decimal12-smoke-0.json','truss-decimal12-smoke-extra.json'))
trial('duplicate-report-path-overwrite',lambda p:((p/'truss-decimal12-smoke-1.json').replace(p/'truss-decimal12-smoke-0.json')))
trial('wrong-report-path-prefix',lambda p:(p/'truss-decimal12-smoke-0.json').rename(p/'other-smoke-0.json'))
trial('nested-report-path',lambda p:((p/'nested').mkdir(),(p/'truss-decimal12-smoke-0.json').rename(p/'nested/truss-decimal12-smoke-0.json')))
trial('wheel-hash-mismatch',lambda p:(p/'wheel-0.whl').write_bytes(b'wrong bytes'))
for key,value in [('nativeModuleSha256','0'*64),('shimSha256','0'*64)]:
 def edit(p,key=key,value=value):
  f=p/'current-query-smoke-0.json';r=json.loads(f.read_text());r['pinsBeforeAfter'][key]=value;f.write_text(json.dumps(r))
 trial('baseline-'+key+'-mismatch',edit)
for path in ['../wheel-0.whl','./wheel-0.whl','/tmp/wheel-0.whl','nested/wheel-0.whl']:
 safe=path.replace('/','_').replace('.','_')
 trial('baseline-wheel-path-'+safe,lambda p,path=path:change(p,'current-query-smoke-0.json','wheel',path))
 trial('naming-wheel-path-'+safe,lambda p,path=path:change(p,'truss-decimal12-smoke-0.json','wheel',path))
trial('malformed-report-json',lambda p:(p/'truss-decimal12-smoke-0.json').write_text('{'))
trial('old20-report-file',lambda p:change(p,'truss-decimal12-smoke-0.json','checks',gate['EXPECTED'][:20]))
result={'scope':__doc__,'base':'1ed81c11fa870d57ba21d4339132ff139b05641d','python':sys.version,'controls':len(results),'passed':sum(x['pass'] for x in results),'results':results,'preflightSha256':sha(preflight.encode()),'scriptSha256':sha(Path(__file__).read_bytes())}
(OUT/'path-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k!='results'},indent=2))
assert all(x['pass'] for x in results)
