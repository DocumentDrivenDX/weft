"""Bounded wheel selection only; no installation or native import."""
import argparse, hashlib, json, os, pathlib, stat, zipfile
p=argparse.ArgumentParser()
p.add_argument('--wheel-dir',required=True,type=pathlib.Path)
p.add_argument('--extension',required=True,type=pathlib.Path)
p.add_argument('--output-dir',required=True,type=pathlib.Path)
p.add_argument('--receipt',required=True,type=pathlib.Path)
a=p.parse_args()
if not all(x.is_absolute() for x in vars(a).values()): raise ValueError('absolute-config')
if a.wheel_dir.is_symlink() or not a.wheel_dir.is_dir(): raise ValueError('wheel-directory')
entries=list(a.wheel_dir.iterdir())
if len(entries)!=1: raise ValueError('exact-wheel-inventory')
w=entries[0]
if w.is_symlink() or not w.is_file() or w.suffix!='.whl' or w.stat().st_size>32*1024*1024: raise ValueError('bounded-wheel')
raw=w.read_bytes()
if len(raw)>32*1024*1024: raise ValueError('wheel-bound')
# Read the pinned in-memory wheel, avoiding a second file-open custody race.
import io
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 infos=z.infolist()
 if not 1<=len(infos)<=128: raise ValueError('member-count')
 names=set(); total=0; rows=[]; selected=[]
 for i in infos:
  name=i.filename; path=pathlib.PurePosixPath(name)
  mode=i.external_attr>>16
  if name in names or path.is_absolute() or '..' in path.parts or '\\' in name or not path.parts or stat.S_IFMT(mode) not in (0,stat.S_IFREG) or i.is_dir() or i.flag_bits&1: raise ValueError('member-shape')
  names.add(name); total+=i.file_size
  if i.file_size>16*1024*1024 or total>32*1024*1024: raise ValueError('decoded-bound')
  with z.open(i) as f: data=f.read(16*1024*1024+1)
  if len(data)!=i.file_size or len(data)>16*1024*1024: raise ValueError('member-size')
  rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
  if name.endswith('/weft.abi3.so') or name=='weft.abi3.so': selected.append((name,data))
 if len(selected)!=1: raise ValueError('exact-native-member')
 if a.extension.is_symlink() or not a.extension.is_file() or a.extension.stat().st_size>16*1024*1024: raise ValueError("retained-native-shape")
 with a.extension.open("rb") as f: native=f.read(16*1024*1024+1)
 if len(native)>16*1024*1024 or selected[0][1]!=native: raise ValueError('retained-native-byte-equality')
a.output_dir.mkdir()
dst=a.output_dir/'weft.abi3.so'
with dst.open('xb') as f: f.write(selected[0][1])
dst.chmod(0o444)
receipt={'qualification':'Wheel inventory and selected extension byte custody only; no installation/import.', 'wheel':{'path':str(w),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},'members':rows,'selectedMember':selected[0][0],'extension':{'path':str(dst),'bytes':len(native),'sha256':hashlib.sha256(native).hexdigest()}}
with a.receipt.open('x') as f: json.dump(receipt,f,sort_keys=True,indent=2);f.write('\n')
