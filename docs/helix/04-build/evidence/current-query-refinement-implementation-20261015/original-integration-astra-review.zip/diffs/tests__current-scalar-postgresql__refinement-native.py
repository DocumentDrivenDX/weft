--- previous/tests/current-scalar-postgresql/refinement-native.py
+++ addendum/tests/current-scalar-postgresql/refinement-native.py
@@ -1,7 +1,7 @@
 """Fresh native SQL/checker correspondence with synthetic stage premises.
 No caller/source authorization, native admission or guarded release claim.
 """
-import argparse,ast,collections,copy,hashlib,importlib,json,pathlib,sys,zipfile
+import argparse,ast,collections,copy,hashlib,importlib,json,pathlib,shutil,sys,zipfile
 import weft
 p=argparse.ArgumentParser();p.add_argument('--truss',type=pathlib.Path,required=True);p.add_argument('--wheel',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args();a.output.mkdir(exist_ok=False)
 sys.path.insert(0,str(a.truss/'packages/python/src'))
@@ -61,5 +61,8 @@
      except ValueError as e:assert 'WFT-CURRENT-QUERY-REFINEMENT'in str(e)
      else:raise AssertionError('Wrong native public value accepted')
      checks.append({'id':name+'/'+label+'/wrong-public','refused':True})
-report={'scope':__doc__,'weftVersion':weft.__version__,'wheelSha256':sha(a.wheel.read_bytes()),'nativeModuleSha256':sha(native.read_bytes()),'runnerSha256':sha(pathlib.Path(__file__).read_bytes()),'originalOracleSourcePins':source_pins,'serverVersionNum':version,'checks':checks,'nativeSecurityAcceptance':False,'casesPromoted':[]}
+assert runtime._server is None and runtime._lease is None and not (runtime.directory/'postmaster.pid').exists()
+shutil.rmtree(runtime.directory)
+assert not runtime.directory.exists()
+report={'serverStopped':True,'leaseReleased':True,'runtimeDirectoryRemoved':True,'scope':__doc__,'weftVersion':weft.__version__,'wheelSha256':sha(a.wheel.read_bytes()),'nativeModuleSha256':sha(native.read_bytes()),'runnerSha256':sha(pathlib.Path(__file__).read_bytes()),'originalOracleSourcePins':source_pins,'serverVersionNum':version,'checks':checks,'nativeSecurityAcceptance':False,'casesPromoted':[]}
 (a.output/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'checks':len(checks),'nativeSecurityAcceptance':False}))
