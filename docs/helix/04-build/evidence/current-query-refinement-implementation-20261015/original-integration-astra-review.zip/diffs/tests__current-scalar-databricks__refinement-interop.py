--- previous/tests/current-scalar-databricks/refinement-interop.py
+++ addendum/tests/current-scalar-databricks/refinement-interop.py
@@ -5,19 +5,22 @@
 def text(v):return json.dumps(v,separators=(',',':'),ensure_ascii=False)
 def sha(v):return hashlib.sha256(v).hexdigest()
 root=pathlib.Path(__file__).resolve().parents[1];corpus=root/'current-scalar-databricks/native.py'
+inputs=[a.native_dir/'receipt.json',a.native_dir/'statements.json',corpus,root/'current-query-designation/fixtures/mixed-original-uses.request.json',root/'current-query-designation/fixtures/live-original-integer-sum.request.json']
+captured={p:p.read_bytes()for p in inputs}
+before={str(p):sha(captured[p])for p in inputs}
 native=pathlib.Path(importlib.import_module('weft.weft').__file__)
 with zipfile.ZipFile(a.wheel)as z:
  names=[n for n in z.namelist()if n.endswith(('.so','.pyd'))];assert len(names)==1
  assert native.read_bytes()==z.read(names[0])and pathlib.Path(weft.__file__).read_bytes()==z.read('weft/__init__.py')
-tree=ast.parse(corpus.read_text());assignments={t.id:n.value for n in tree.body if isinstance(n,ast.Assign)for t in n.targets if isinstance(t,ast.Name)}
+tree=ast.parse(captured[corpus].decode());assignments={t.id:n.value for n in tree.body if isinstance(n,ast.Assign)for t in n.targets if isinstance(t,ast.Name)}
 one=[('k1',),('k3',),('k4',),('k5',)];joined=[(x,y)for group in [['k1','k4'],['k3','k5']]for x in group for y in group]
 env={'maximum':9223372036854775807,'minimum':-9223372036854775808,'one':one,'joined':joined}
 cases=eval(compile(ast.Expression(assignments['cases']),str(corpus),'eval'),{'__builtins__':{'str':str}},env)
 fixture=eval(compile(ast.Expression(assignments['rows']),str(corpus),'eval'),{'__builtins__':{}},env)
-prior=json.loads((a.native_dir/'receipt.json').read_text());assert prior['schemaRemoved'] is True
+prior=json.loads(captured[a.native_dir/'receipt.json']);assert prior['schemaRemoved'] is True
 records={r['id']:r for r in prior['checks']if 'compiled'in r};assert len(records)==len(cases)==22
-statements=json.loads((a.native_dir/'statements.json').read_text());by_id={s['response']['statement_id']:s for s in statements}
-sources={False:json.loads((root/'current-query-designation/fixtures/mixed-original-uses.request.json').read_text()),True:json.loads((root/'current-query-designation/fixtures/live-original-integer-sum.request.json').read_text())}
+statements=json.loads(captured[a.native_dir/'statements.json']);by_id={s['response']['statement_id']:s for s in statements}
+sources={False:json.loads(captured[inputs[-2]]),True:json.loads(captured[inputs[-1]])}
 checks=[]
 def refused(method,binding,frame,label):
  try:method(binding,frame)
@@ -32,7 +35,9 @@
  lower=child.lower_databricks_current_sum_candidate_json if context else child.lower_databricks_current_contributors_candidate_json
  check=child.check_databricks_current_sum_candidate_json if context else child.check_databricks_current_contributors_candidate_json
  artifact_text=lower(binding_text);compiled=json.loads(artifact_text);assert compiled==old['compiled']
- response=by_id[old['statementId']]['response'];assert response['status']['state']=='SUCCEEDED'
+ statement=by_id[old['statementId']];assert statement['statement']==compiled['sql']
+ assert statement['parameters']==[{'name':v['marker'],'value':v['value'],'type':'STRING'}for v in compiled['parameters']]
+ response=statement['response'];assert response['status']['state']=='SUCCEEDED'
  manifest=response['manifest'];result=response.get('result',{});assert not manifest.get('truncated',False)
  assert not result.get('next_chunk_internal_link')and not result.get('next_chunk_external_link')
  assert result.get('row_count',0)==manifest.get('total_row_count',0)
@@ -74,5 +79,6 @@
    refused(check,value,raw,'exact-binding-string-'+str(i))
   empty=copy.deepcopy(frame);empty['scans'][0]['rows']=[];empty['scans'][0]['expectedRowCount']='0';empty['resultRows']=[['0',text(dict(version='weft.stage-contributor-bag/0.1-candidate',tuples=[]))]]
   r=json.loads(check(binding_text,text(empty)));assert r['matched']and not r['authority'];checks.append({'id':'consistent-forged-world-conditional-only','authority':False})
-report={'scope':'Actual installed candidate CQP checker over retained managed results and independently captured original fixture populations. Offline correspondence only; no fresh native execution, completeness/authority admission or guarded release.','version':weft.__version__,'wheelSha256':sha(a.wheel.read_bytes()),'nativeModuleSha256':sha(native.read_bytes()),'runnerSha256':sha(pathlib.Path(__file__).read_bytes()),'checks':checks,'nativeSecurityAcceptance':False,'casesPromoted':[]}
+assert before=={str(p):sha(p.read_bytes())for p in inputs}
+report={'inputPinsBeforeAfter':before,'scope':'Actual installed candidate CQP checker over retained managed results and independently captured original fixture populations. Offline correspondence only; no fresh native execution, completeness/authority admission or guarded release.','version':weft.__version__,'wheelSha256':sha(a.wheel.read_bytes()),'nativeModuleSha256':sha(native.read_bytes()),'runnerSha256':sha(pathlib.Path(__file__).read_bytes()),'checks':checks,'nativeSecurityAcceptance':False,'casesPromoted':[]}
 (a.output/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'checks':len(checks),'managedCases':len(cases),'nativeSecurityAcceptance':False}))
