"""Independent finite pure checks of the actual prototype wheel. No DB or authority.
Uses original governed source fixtures, independently authored captured data/results.
"""
import pathlib,zipfile,hashlib,json,sys,io,copy,importlib,itertools
R=pathlib.Path(__file__).resolve().parent
W=pathlib.Path('/private/tmp/weft-integrated035-wheel-20261015/weft_sql-0.4.35-cp39-abi3-macosx_11_0_arm64.whl')
F=pathlib.Path('/private/tmp/weft-refinement-implementation-astra-20261015/workspace/tests/current-query-designation/fixtures')
paths=[W,pathlib.Path(__file__),F/'mixed-original-uses.request.json',F/'live-original-integer-sum.request.json']
raws={str(p):p.read_bytes() for p in paths}
sha=lambda b:hashlib.sha256(b).hexdigest()
before={p:sha(b) for p,b in raws.items()}
assert before[str(W)]=='e8dfc15316109494846c4d0a5f58038f623028746a749e11e4af240f25ddcbdd'
wheel_zip=zipfile.ZipFile(io.BytesIO(raws[str(W)]));install=R/'wheel-extracted';install.mkdir(exist_ok=True)
for n in wheel_zip.namelist():
 assert not pathlib.PurePosixPath(n).is_absolute() and '..'not in pathlib.PurePosixPath(n).parts
 if not n.endswith('/'):
  p=install/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(wheel_zip.read(n))
sys.path.insert(0,str(install));import weft
m=importlib.import_module('weft.weft');mp=pathlib.Path(m.__file__)
assert mp.parent==install/'weft'
assert mp.read_bytes()==wheel_zip.read('weft/'+mp.name)
assert pathlib.Path(weft.__file__).read_bytes()==wheel_zip.read('weft/__init__.py')
assert weft.prepare_application_lineage is m.prepare_application_lineage
text=lambda x:json.dumps(x,ensure_ascii=False,separators=(',',':'))
sources={False:json.loads(raws[str(F/'mixed-original-uses.request.json')]),True:json.loads(raws[str(F/'live-original-integer-sum.request.json')])}
identity=lambda x:dict(documentId='domain',revision='query-value-core-r1',module='m',element=x)
# Unicode decomposition and negative values deliberately differ from owner fixtures.
DATA=[dict(key='α',resourceId='rα',salary=9,salary_public='mask-Z',token='é'),dict(key='β',resourceId='rβ',salary=-7,salary_public='mask-A',token='e\u0301'),dict(key='γ',resourceId='rγ',salary=9,salary_public='mask-M',token='é')]
checks=[];cases=[]
ERROR='WFT-CURRENT-QUERY-REFINEMENT: Conditional current-query refinement refused'
def note(label,ok,**extra):
 checks.append(dict(id=label,passed=bool(ok),**extra));assert ok,label

def make(sql,profile='pg-bag',params=None,data=None):
 sum_context=profile.endswith('sum');db=profile.startswith('db');kind='sum'if sum_context else'rows'if profile=='pg-rows'else'contributors'
 original=text(dict(sources[sum_context],sql=sql,parameters=params or {}));parent=weft.prepare_application_lineage(original);child=parent.prepare_current_query()
 assert child.source_preparation()is parent
 packet=json.loads(child.native_request_json());values=[]
 for op in packet['operations']:
  for operand in op['operands']:
   v=operand['input']
   if v['kind']!='field':continue
   assert v['identity']['element']in{'resourceId','salary','token'}
   action=v['originalAction']
   values.append(dict(path=operand['path'],scan=v['scan'],field=v['identity'],column=v['identity']['element'],domain=v['identity'],comparisonScope='a'*64,mode='original-authorized'if action else'disclosed',originalAction=action,exposure=None))
 for p in packet['projections']:
  f=p['field'];mask=f['element']=='salary'
  values.append(dict(path=p['path'],scan=p['scan'],field=f,column='salary_public'if mask else f['element'],domain=identity('salaryMaskLabel')if mask else f,comparisonScope='a'*64,mode=None,originalAction=None,exposure='transformed'if mask else'original'))
 relation=dict(schema='review_stage',table='captured',eligibleColumn='eligible',rowKeyColumn='private_key')
 if db:relation.update(catalog='review_catalog',uuid='00000000-0000-4000-8000-000000000001',version='1',schemaSha256='b'*64)
 version=('weft.databricks.current-values/'+('0.2'if sum_context else'0.1'))if db else('weft.postgresql.current-values/'+('0.4'if sum_context else'0.2'if kind=='rows'else'0.3'))
 binding=dict(version=version+'-candidate',sourceRequestSha256=packet['sourceRequestSha256'],designationSha256=packet['designationSha256'],sourceBindingSha256=packet['binding']['sha256'],scans=[dict(scan=s['scan'],target=s['record'],relation=relation)for s in packet['scans']],values=values)
 bindingRaw=text(binding);backend='databricks'if db else'postgresql';lower=getattr(child,f'lower_{backend}_current_{kind}_candidate_json');method=getattr(child,f'check_{backend}_current_{kind}_candidate_json');artifactRaw=lower(bindingRaw)
 populations=[]
 for s in packet['scans']:
  cols=sorted({v['column']for v in values if v['scan']==s['scan']});actualData=DATA if data is None else data
  rows=[dict(key=r['key'],cells={c:dict(family='integer'if c=='salary'else'string',value=str(r[c]))for c in cols})for r in actualData]
  populations.append(dict(scan=s['scan'],expectedRowCount=str(len(rows)),rows=rows))
 frame=dict(version='weft.current-query.refinement-input/0.1-candidate',sourceRequestSha256=packet['sourceRequestSha256'],designationSha256=packet['designationSha256'],materializationBindingSha256=sha(bindingRaw.encode()),compiledArtifactSha256=sha(artifactRaw.encode()),scans=populations,resultRows=[])
 return dict(parent=parent,child=child,packet=packet,binding=binding,bindingRaw=bindingRaw,artifactRaw=artifactRaw,method=method,lower=lower,frame=frame,profile=profile,sql=sql)

def result(c,values,keys):
 scan=[s['scan']for s in c['frame']['scans']]
 tuples=[[dict(scan=s,key=k)for s,k in zip(scan,t)]for t in keys]
 if c['profile']=='pg-rows':assert len(tuples)==1;private=dict(version='weft.stage-row-tuple/0.1-candidate',rows=tuples[0])
 else:private=dict(version='weft.stage-contributor-bag/0.1-candidate',tuples=tuples)
 return list(values)+[text(private)]
def yes(label,c,rows):
 f=copy.deepcopy(c['frame']);f['resultRows']=rows;raw=text(f);report=json.loads(c['method'](c['bindingRaw'],raw))
 wanted=dict(version='weft.current-query.refinement-result/0.1-candidate',matched=True,authority=False,securityReady=False,nativeAdmission='required',**{k:f[k]for k in['sourceRequestSha256','designationSha256','materializationBindingSha256','compiledArtifactSha256']},refinementInputSha256=sha(raw.encode()))
 note(label,report==wanted);cases.append(dict(label=label,sql=c['sql'],profile=c['profile'],binding=c['bindingRaw'],artifact=c['artifactRaw'],frame=f,report=report))
 return f

MISSING=object()
def no(label,c,frame=None,binding=MISSING,raw=MISSING):
 try:c['method'](c['bindingRaw']if binding is MISSING else binding,text(c['frame']if frame is None else frame)if raw is MISSING else raw)
 except ValueError as e:note(label,str(e)==ERROR,error=str(e))
 else:note(label,False)

# Every actual adapter method, raw predicate and transformed projection of one Field.
for profile in ['pg-rows','pg-bag','db-bag']:
 c=make('SELECT r.salary FROM Resource r WHERE r.salary=9 ORDER BY r.token ASC LIMIT 1',profile)
 f=yes(profile+'/same-field-different-domains',c,[result(c,['mask-Z'],[('α',)])])
 for label,value in [('raw-not-mask','9'),('same-family-wrong-cell','mask-A'),('null-not-mask',None)]:
  bad=copy.deepcopy(f);bad['resultRows'][0][0]=value;no(profile+'/'+label,c,bad)
 bad=copy.deepcopy(f);bad['resultRows'][0][-1]=result(c,['x'],[('β',)])[-1];no(profile+'/predicate-rejected-resource',c,bad)
 bad=copy.deepcopy(f);bad['resultRows'][0][-1]=result(c,['x'],[('γ',)])[-1];no(profile+'/correct-tie-wrong-public-cell',c,bad)
 yes(profile+'/other-tie-occurrence',c,[result(c,['mask-M'],[('γ',)])])
 # Hidden raw order: public strings have a deliberately different ordering.
 o=make('SELECT r.salary FROM Resource r ORDER BY r.salary ASC LIMIT 1',profile)
 yes(profile+'/hidden-raw-order',o,[result(o,['mask-A'],[('β',)])])
 no(profile+'/hidden-order-not-mask',o,dict(o['frame'],resultRows=[result(o,['mask-Z'],[('α',)])]))
 # Original parameters cannot be replaced by frame metadata.
 p=make('SELECT r.token FROM Resource r WHERE r.token=:needle',profile,{'needle':{'family':'string','value':'e\u0301'}})
 yes(profile+'/unicode-parameter',p,[result(p,['e\u0301'],[('β',)])])
 bad=copy.deepcopy(p['frame']);bad['resultRows']=[result(p,['é'],[('α',)])];no(profile+'/unicode-not-normalized',p,bad)

for profile in ['pg-bag','db-bag','pg-sum','db-sum']:
 c=make('SELECT COUNT(*) FROM Resource r',profile)
 f=yes(profile+'/count-full-population',c,[result(c,['3'],[('α',),('β',),('γ',)])])
 bad=copy.deepcopy(f);bad['resultRows'][0][-1]=result(c,['3'],[('α',),('α',),('γ',)])[-1];no(profile+'/same-count-different-bag',c,bad)
 bad=copy.deepcopy(f);bad['resultRows'][0][0]='03';no(profile+'/noncanonical-count',c,bad)
 bad=copy.deepcopy(f);bad['scans'][0]['expectedRowCount']='2';no(profile+'/declared-count-mismatch',c,bad)
 bad=copy.deepcopy(f);bad['scans'][0]['rows']=bad['scans'][0]['rows'][:1];bad['scans'][0]['expectedRowCount']='1';bad['resultRows']=[result(c,['1'],[('α',)])]
 conditional=json.loads(c['method'](c['bindingRaw'],text(bad)));note(profile+'/consistent-truncation-not-discoverable',conditional['matched']and conditional['authority']is False)
 j=make('SELECT COUNT(*) AS n,COUNT(DISTINCT a.token) AS d FROM Resource a JOIN Resource b ON a.token=b.token',profile)
 pairs=[('α','α'),('α','γ'),('γ','α'),('γ','γ'),('β','β')]
 jf=yes(profile+'/join-multiplicity',j,[result(j,['5','2'],pairs)])
 bad=copy.deepcopy(jf);bad['resultRows'][0][-1]=result(j,['5','2'],[('α','α')]*4+[('β','β')])[-1];no(profile+'/join-pair-identity',j,bad)
 g=make('SELECT COUNT(*) FROM Resource r GROUP BY r.token ORDER BY r.token ASC',profile)
 gf=yes(profile+'/hidden-group-order',g,[result(g,['1'],[('β',)]),result(g,['2'],[('α',),('γ',)])])
 bad=copy.deepcopy(gf);bad['resultRows'].reverse();no(profile+'/group-order-reversed',g,bad)
 z=make('SELECT COUNT(*) FROM Resource r WHERE FALSE LIMIT 0',profile)
 zf=yes(profile+'/zero-after-full-validation',z,[])
 for label,value in [('null-key',None),('empty-key',''),('utf8-key-overflow','é'*129)]:
  bad=copy.deepcopy(zf);bad['scans'][0]['rows'][0]['key']=value;no(profile+'/'+label,z,bad)
 bad=copy.deepcopy(zf);bad['scans'][0]['rows'][0]['cells']['unknown']={'family':'string','value':'SECRET'};no(profile+'/zero-unknown-cell',z,bad)
 # Force actual lowerer failure even with syntactically valid empty result frame.
 b=copy.deepcopy(z['binding']);b['version']='forged';no(profile+'/actual-lowerer-first',z,zf,binding=text(b))

for profile in ['pg-sum','db-sum']:
 c=make('SELECT SUM(r.salary),COUNT(*) FROM Resource r',profile)
 f=yes(profile+'/exact-signed-sum',c,[result(c,['11','3'],[('α',),('β',),('γ',)])])
 big=[dict(r,salary=9223372036854775807)for r in DATA]
 b=make('SELECT SUM(r.salary) FROM Resource r',profile,data=big)
 yes(profile+'/sum-beyond-i64',b,[result(b,['27670116110564327421'],[('α',),('β',),('γ',)])])
 e=make('SELECT SUM(r.salary),COUNT(*) FROM Resource r WHERE FALSE',profile)
 ef=yes(profile+'/empty-null-sum',e,[result(e,[None,'0'],[])])
 bad=copy.deepcopy(ef);bad['resultRows'][0][0]='0';no(profile+'/empty-sum-not-zero',e,bad)
 bad=copy.deepcopy(f);bad['scans'][0]['rows'][1]['cells']['salary']['value']='-9223372036854775809';no(profile+'/input-underflow',c,bad)
 bad=copy.deepcopy(f);bad['scans'][0]['rows'][1]['cells']['salary']['value']='-0';no(profile+'/input-negative-zero',c,bad)
 e0=make('SELECT SUM(r.salary) FROM Resource r WHERE FALSE LIMIT 0',profile)
 bad=copy.deepcopy(e0['frame']);bad['scans'][0]['rows'][1]['cells']['salary']['value']='not-an-integer';no(profile+'/false-does-not-hide-invalid-scalar',e0,bad)

# Exact strings, framing, duplicate member rejection and coarse errors through Python.
c=make('SELECT COUNT(*) FROM Resource r','pg-bag');good=dict(c['frame'],resultRows=[result(c,['3'],[('α',),('β',),('γ',)])]);raw=text(good)
class Sub(str):pass
class Trap:
 def __str__(self):raise AssertionError('coercion must not execute')
for i,v in enumerate([Sub(raw),b'{}',{},None,Trap(),42]):
 no('exact-input-'+str(i),c,raw=v);no('exact-binding-'+str(i),c,good,binding=v)
for label,v in [('duplicate-frame',raw[:-1]+',"version":"secret"}'),('malformed','{"secret":'),('surrogate','"\ud800"')]:no(label,c,raw=v)
for anchor in ['sourceRequestSha256','designationSha256','materializationBindingSha256','compiledArtifactSha256']:
 bad=copy.deepcopy(good);bad[anchor]='0'*64;no('wrong-'+anchor,c,bad)
no('binding-exact-bytes',c,good,binding=c['bindingRaw']+' ')
bad=copy.deepcopy(good);carrier=bad['resultRows'][0][-1];bad['resultRows'][0][-1]=carrier[:-1]+',"tuples":[]}';no('duplicate-private-member',c,bad)
bad=copy.deepcopy(good);bad['resultRows'][0].append('SECRET');no('extra-public-column',c,bad)
bad=copy.deepcopy(good);bad['resultRows'][0][-1]=None;no('null-private-carrier',c,bad)
# Byte-exact full input digest distinguishes whitespace without changing semantics.
r1=json.loads(c['method'](c['bindingRaw'],raw));r2=json.loads(c['method'](c['bindingRaw'],raw+' '));note('full-frame-digest-byte-sensitive',r1['refinementInputSha256']!=r2['refinementInputSha256']and all(r1[k]==r2[k]for k in r1 if k!='refinementInputSha256'))
after={p:sha(pathlib.Path(p).read_bytes())for p in raws};assert before==after
assert mp.read_bytes()==wheel_zip.read('weft/'+mp.name)
report=dict(scope=__doc__,counts=dict(checks=len(checks),passed=sum(c['passed']for c in checks)),checks=checks,pinsBefore=before,pinsAfter=after,nativeModule=dict(path=str(mp),sha256=sha(mp.read_bytes())),shim=dict(path=weft.__file__,sha256=sha(pathlib.Path(weft.__file__).read_bytes())),python=sys.version,authority=False,nativeExecution=False)
(R/'pure-controls.json').write_text(json.dumps(report,indent=2,ensure_ascii=True)+'\n');(R/'pure-cases.json').write_text(json.dumps(cases,ensure_ascii=True,indent=2)+'\n');print(json.dumps(report['counts']))
