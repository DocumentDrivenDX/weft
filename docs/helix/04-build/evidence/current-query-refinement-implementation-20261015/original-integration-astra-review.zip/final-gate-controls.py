"""Focused exact frozen publication-validator checks; no publication/native claim."""
from pathlib import Path
import json,hashlib,zipfile,copy,runpy,textwrap
R=Path(__file__).resolve().parent;S=Path('/private/tmp/weft-integrated035-review-v2-20261015');Z=Path(str(S)+'.zip');sha=lambda b:hashlib.sha256(b).hexdigest();p=json.loads((S/'source-pins.json').read_bytes());old=json.loads((R/'initial-source-pins.json').read_bytes())
assert sha(Z.read_bytes())=='adb73a62f1f391acf167631fbdfab9dd4c656e13d9c07e0e5d857da43de82f38'
with zipfile.ZipFile(Z)as z:
 for rel,h in p['files'].items():
  b=(S/rel).read_bytes();assert sha(b)==h and b==z.read(rel);out=R/'final-frozen-source'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
(R/'final-source-pins.json').write_bytes((S/'source-pins.json').read_bytes());delta={f:'new'if f not in old['files']else'changed'for f,h in p['files'].items()if old['files'].get(f)!=h};assert set(delta)=={'.github/workflows/release.yml','docs/helix/02-design/module-boundaries.json','scripts/release/verify-refinement-smoke.py','scripts/release/test-refinement-smoke-gate.py'}
G=R/'final-frozen-source/scripts/release/verify-refinement-smoke.py';gate=runpy.run_path(str(G))['validate'];checks=[]
# Independent canonical list, without importing validator constants.
expected=[]
for name in ['postgresql/rows','postgresql/contributors','postgresql/sum','databricks/contributors','databricks/sum']:
 expected.append({'id':name,'matched':True})
 for suffix in ['foreign-source','wrong-public','duplicate-key','missing-input','unknown-frame']:expected.append({'id':name+'/'+suffix,'refused':True})
base=[{'wheel':f'platform-{i}.whl','pinsBeforeAfter':{'wheelSha256':str(i)*64,'nativeModuleSha256':'a'*64,'shimSha256':'b'*64}}for i in range(5)]
reports=[dict(x,sourceCommit='c'*40,version='0.4.35',controls=30,nativeAdmission=False,securityReady=False,checks=copy.deepcopy(expected))for x in base]
def run(label,values,want):
 try:gate(values,base,'c'*40,'0.4.35');accepted=True
 except (AssertionError,KeyError,TypeError):accepted=False
 checks.append({'id':label,'accepted':accepted,'expected':want,'passed':accepted==want});assert accepted==want,label
run('positive-exact30x5',reports,True)
mutations=[('empty-lists',lambda x:[r.update(checks=[])for r in x]),('reordered-method-block',lambda x:x[2]['checks'].__setitem__(slice(0,12),x[2]['checks'][6:12]+x[2]['checks'][:6])),('duplicate-last',lambda x:x[4]['checks'].__setitem__(29,copy.deepcopy(x[4]['checks'][28]))),('numeric-match',lambda x:x[1]['checks'][0].update(matched=1)),('numeric-refusal',lambda x:x[1]['checks'][1].update(refused=1)),('float-total',lambda x:x[0].update(controls=30.0)),('extra-status',lambda x:x[0]['checks'][0].update(refused=True)),('missing-report',lambda x:x.pop()),('duplicate-wheel',lambda x:x.__setitem__(2,copy.deepcopy(x[0]))),('foreign-module',lambda x:x[3]['pinsBeforeAfter'].update(nativeModuleSha256='d'*64)),('wrong-commit',lambda x:x[0].update(sourceCommit='e'*40)),('numeric-false-native',lambda x:x[0].update(nativeAdmission=0)),('wrong-security-ready',lambda x:x[0].update(securityReady=True))]
for name,change in mutations:
 x=copy.deepcopy(reports);change(x);run(name,x,False)
# Execute exact historical new-block bytes with identical empty-list reports.
yaml=(R/'initial-frozen-source/.github/workflows/release.yml').read_text();start=yaml.index('          refinement=[json.loads(');end=yaml.index('          runtimes=',start);oldblock=textwrap.dedent(yaml[start:end]);(R/'historical-publish-block.py').write_text(oldblock)
fixture=R/'synthetic-reports';fixture.mkdir(exist_ok=True);empty=copy.deepcopy(reports)
for i,x in enumerate(empty):x['checks']=[];(fixture/f'current-refinement-smoke-{i}.json').write_text(json.dumps(x))
exec(compile(oldblock,'historical-publish-block.py','exec'),dict(json=json,root=fixture,features=['current-query-refinement-candidate'],wheels=[Path(x['wheel'])for x in base],smoke=base,commit='c'*40,version='0.4.35'))
checks.append({'id':'historical-block-accepts-empty-lists','accepted':True,'expected':True,'passed':True,'scope':'Historical isolated validator counterexample, not full publisher bypass'})
assert all(sha((S/f).read_bytes())==h for f,h in p['files'].items())
(R/'final-gate-controls.json').write_text(json.dumps({'scope':__doc__,'controls':checks,'count':len(checks),'allPassed':all(x['passed']for x in checks),'final34PinsStable':True,'finalZipSha256':sha(Z.read_bytes()),'deltaFromFirstAddendum':delta},indent=2)+'\n');print(json.dumps({'controls':len(checks),'allPassed':True,'final34PinsStable':True}))
