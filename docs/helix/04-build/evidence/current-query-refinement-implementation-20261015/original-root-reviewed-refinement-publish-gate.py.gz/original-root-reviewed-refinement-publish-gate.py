refinement=[json.loads(p.read_text()) for p in sorted(root.glob('current-refinement-smoke-*.json'))]
if 'current-query-refinement-candidate' in features:
    assert len(refinement)==5 and {r['wheel'] for r in refinement}=={p.name for p in wheels}
    by_wheel={r['wheel']:r for r in smoke}
    for report in refinement:
        assert report['sourceCommit']==commit and report['version']==version and report['controls']==30
        assert report['nativeAdmission'] is False and report['securityReady'] is False
        assert report['pinsBeforeAfter']==by_wheel[report['wheel']]['pinsBeforeAfter']
        assert report['checks']==refinement[0]['checks']
else:
    assert refinement==[]

