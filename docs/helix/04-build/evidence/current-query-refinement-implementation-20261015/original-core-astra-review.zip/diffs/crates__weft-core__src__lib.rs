--- base/crates/weft-core/src/lib.rs
+++ frozen/crates/weft-core/src/lib.rs
@@ -175,3 +175,7 @@
 
 /// Original relational operand domain/presence checks; no native authority.
 pub mod security_operand_values;
+
+/// Optional conditional relational conformance; never native authority.
+#[cfg(feature="current-query-refinement-candidate")]
+pub mod current_query_refinement;
