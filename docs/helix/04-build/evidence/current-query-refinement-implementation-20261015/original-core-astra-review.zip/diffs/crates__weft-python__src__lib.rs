--- base/crates/weft-python/src/lib.rs
+++ frozen/crates/weft-python/src/lib.rs
@@ -165,6 +165,36 @@
  fn lower_databricks_current_contributors_candidate_json(&self,py:Python<'_>,binding:&str)->PyResult<String>{self.check_original(py)?;self.inner.lower_databricks_current_contributors_candidate_json(binding).map_err(|d|pyo3::exceptions::PyValueError::new_err(format!("{}: {}",d.code,d.message)))}
  #[cfg(feature="current-databricks-scalar-candidate")]
  fn lower_databricks_current_sum_candidate_json(&self,py:Python<'_>,binding:&str)->PyResult<String>{self.check_original(py)?;self.inner.lower_databricks_current_sum_candidate_json(binding).map_err(|d|pyo3::exceptions::PyValueError::new_err(format!("{}: {}",d.code,d.message)))}
+ #[cfg(feature="current-query-refinement-candidate")]
+ fn check_postgresql_current_rows_candidate_json(&self,py:Python<'_>,original_binding_json:&Bound<'_,PyAny>,refinement_input_json:&Bound<'_,PyAny>)->PyResult<String>{
+  self.check_original(py).map_err(|_|refinement_python_failure())?;
+  let binding=refinement_text(original_binding_json,4_000_000)?;let input=refinement_text(refinement_input_json,16_777_216)?;
+  self.inner.check_postgresql_current_rows_candidate_json(&binding,&input).map_err(|_|refinement_python_failure())
+ }
+ #[cfg(feature="current-query-refinement-candidate")]
+ fn check_postgresql_current_contributors_candidate_json(&self,py:Python<'_>,original_binding_json:&Bound<'_,PyAny>,refinement_input_json:&Bound<'_,PyAny>)->PyResult<String>{
+  self.check_original(py).map_err(|_|refinement_python_failure())?;
+  let binding=refinement_text(original_binding_json,4_000_000)?;let input=refinement_text(refinement_input_json,16_777_216)?;
+  self.inner.check_postgresql_current_contributors_candidate_json(&binding,&input).map_err(|_|refinement_python_failure())
+ }
+ #[cfg(feature="current-query-refinement-candidate")]
+ fn check_postgresql_current_sum_candidate_json(&self,py:Python<'_>,original_binding_json:&Bound<'_,PyAny>,refinement_input_json:&Bound<'_,PyAny>)->PyResult<String>{
+  self.check_original(py).map_err(|_|refinement_python_failure())?;
+  let binding=refinement_text(original_binding_json,4_000_000)?;let input=refinement_text(refinement_input_json,16_777_216)?;
+  self.inner.check_postgresql_current_sum_candidate_json(&binding,&input).map_err(|_|refinement_python_failure())
+ }
+ #[cfg(feature="current-query-refinement-candidate")]
+ fn check_databricks_current_contributors_candidate_json(&self,py:Python<'_>,original_binding_json:&Bound<'_,PyAny>,refinement_input_json:&Bound<'_,PyAny>)->PyResult<String>{
+  self.check_original(py).map_err(|_|refinement_python_failure())?;
+  let binding=refinement_text(original_binding_json,4_000_000)?;let input=refinement_text(refinement_input_json,16_777_216)?;
+  self.inner.check_databricks_current_contributors_candidate_json(&binding,&input).map_err(|_|refinement_python_failure())
+ }
+ #[cfg(feature="current-query-refinement-candidate")]
+ fn check_databricks_current_sum_candidate_json(&self,py:Python<'_>,original_binding_json:&Bound<'_,PyAny>,refinement_input_json:&Bound<'_,PyAny>)->PyResult<String>{
+  self.check_original(py).map_err(|_|refinement_python_failure())?;
+  let binding=refinement_text(original_binding_json,4_000_000)?;let input=refinement_text(refinement_input_json,16_777_216)?;
+  self.inner.check_databricks_current_sum_candidate_json(&binding,&input).map_err(|_|refinement_python_failure())
+ }
  fn operand_count(&self,py:Python<'_>)->PyResult<usize>{self.check_original(py)?;Ok(self.inner.operand_count())}
  fn native_request_json(&self,py:Python<'_>)->PyResult<String>{self.check_original(py)?;self.inner.native_request_json().map_err(|d|pyo3::exceptions::PyValueError::new_err(format!("{}: {}",d.code,d.message)))}
 
@@ -181,3 +211,11 @@
   if !self.inner.is_from(&self.original.bind(py).borrow().inner){return Err(pyo3::exceptions::PyValueError::new_err("WFT-CURRENT-QUERY-CONTEXT: Original current query context refused"))}Ok(())
  }
 }
+
+#[cfg(feature="current-query-refinement-candidate")]
+fn refinement_python_failure()->PyErr{pyo3::exceptions::PyValueError::new_err("WFT-CURRENT-QUERY-REFINEMENT: Conditional current-query refinement refused")}
+#[cfg(feature="current-query-refinement-candidate")]
+fn refinement_text(value:&Bound<'_,PyAny>,maximum:usize)->PyResult<String>{
+ if !value.is_exact_instance_of::<pyo3::types::PyString>()||value.len().map_err(|_|refinement_python_failure())?>maximum{return Err(refinement_python_failure())}
+ let text=value.extract::<String>().map_err(|_|refinement_python_failure())?;if text.len()>maximum{return Err(refinement_python_failure())}Ok(text)
+}
