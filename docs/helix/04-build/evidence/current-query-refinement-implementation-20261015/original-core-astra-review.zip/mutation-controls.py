"""Exact focused source weakenings in isolated base+frozen overlay only."""
import pathlib,os,subprocess,hashlib,json,difflib,time
R=pathlib.Path(__file__).resolve().parent;W=R/'workspace';REL='crates/weft-core/src/current_query_refinement.rs';target=W/REL;baseline=(R/'frozen-source'/REL).read_text();D=R/'mutations';D.mkdir(exist_ok=True)
variants=[
 ('field-wide-collapse','.get(&(path.into(), scan.into()))','.values().find(|s| s.scan == scan && &s.field == id)','masked_projection_and_original_predicate_are_separate_occurrences'),
 ('reconsume-same-result-occurrence','.and_then(Vec::pop)','.and_then(|v| v.last().copied())','astra_multiple_directions_ties_and_unordered_subbags'),
 ('ignore-hidden-order-and-cutoff','if !directions.is_empty() && wanted > 0 {','if false && !directions.is_empty() && wanted > 0 {','astra_multiple_directions_ties_and_unordered_subbags'),
 ('reset-payload-per-result','payload_left.checked_sub(bytes)','BYTES.checked_sub(bytes)','astra_cumulative_expected_payload_and_borrowed_key_occurrences'),
 ('ignore-key-occurrence-multiplicity','key_bytes.checked_mul(*count)','key_bytes.checked_mul(1)','astra_cumulative_expected_payload_and_borrowed_key_occurrences'),
 ('omit-contributor-key-payload','key_bytes.checked_mul(*count)','0usize.checked_mul(*count)','astra_cumulative_expected_payload_and_borrowed_key_occurrences'),
 ('ignore-group-output-column-correspondence','a.column == b.column\n            && a.domain == b.domain','a.domain == b.domain','astra_group_and_hidden_order_require_exact_effective_selection'),
 ('limit-zero-prevalidation-shortcut','    let mut total = 0usize;','    if plan.limit == Some(0) { return Ok(()); }\n    let mut total = 0usize;','false_and_limit_zero_still_validate_all_captured_cells_and_metadata'),
 ('ignore-actual-artifact-anchor','        || frame.compiled_artifact_sha256 != data.artifact_sha256\n','','keys_counts_column_sets_and_numeric_carriers_are_exact'),
]
env=os.environ.copy();env['CARGO_HOME']='/private/tmp/weft-toolchain/cargo';env['RUSTUP_HOME']='/private/tmp/weft-toolchain/rustup';env['PATH']='/private/tmp/weft-toolchain/rustup/toolchains/1.90.0-aarch64-apple-darwin/bin:'+env.get('PATH','');out=json.loads((R/'mutation-controls-initial.json').read_text())['controls']
completed={v['id'] for v in out}
try:
 for name,old,new,test in variants:
  if name in completed: continue
  assert baseline.count(old)==1,(name,baseline.count(old));mutated=baseline.replace(old,new);target.write_text(mutated)
  patch=''.join(difflib.unified_diff(baseline.splitlines(True),mutated.splitlines(True),fromfile='frozen/'+REL,tofile=name+'/'+REL));(D/(name+'.patch')).write_text(patch)
  cmd=['cargo','test','--offline','--locked','-p','weft-core','--features','current-query-refinement-candidate','--lib',test]
  start=time.monotonic();p=subprocess.run(cmd,cwd=W,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90);(D/(name+'.log')).write_text(p.stdout)
  detected=p.returncode==101 and f'{test} ... FAILED'in p.stdout and 'test result: FAILED'in p.stdout and 'could not compile'not in p.stdout
  row=dict(id=name,sourceSha256=hashlib.sha256(mutated.encode()).hexdigest(),test=test,command=cmd,exitCode=p.returncode,elapsedSeconds=round(time.monotonic()-start,3),detectedByActualTest=detected)
  out.append(row);print(json.dumps(row),flush=True);assert detected,name
finally:
 target.write_text(baseline);(R/'mutation-controls.json').write_text(json.dumps({'scope':__doc__,'baselineSha256':hashlib.sha256(baseline.encode()).hexdigest(),'controls':out,'expectedGuardWeakeningsDetected':sum(x['detectedByActualTest'] for x in out), 'redundantDefenseSurvivor':['ignore-key-occurrence-multiplicity'], 'allExpectedOutcomes':len(out)==len(variants) and all(x['detectedByActualTest'] or x['id']=='ignore-key-occurrence-multiplicity' and x['exitCode']==0 for x in out),'isolatedSourceRestored':target.read_text()==baseline},indent=2)+'\n')
