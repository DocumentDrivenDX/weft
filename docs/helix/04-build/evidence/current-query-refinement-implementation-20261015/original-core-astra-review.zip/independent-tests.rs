
// Astra controls: original source factory borrowed; populations/expectations authored here.
#[test]
fn astra_cumulative_expected_payload_and_borrowed_key_occurrences() {
    // Each individual row is below the cap, but two repeated public columns
    // across both rows must share one pre-LIMIT payload allowance.
    for (characters, accepted) in [(4_194_303usize,true),(4_194_304,false)] {
        assert_eq!(run("SELECT r.token AS a,r.token AS b FROM Resource r LIMIT 0",false,json!([]),|f,_|{
            f["scans"][0]["rows"]=json!([
                {"key":"a","cells":{"token":{"family":"string","value":"x".repeat(characters)}}},
                {"key":"b","cells":{"token":{"family":"string","value":"y".repeat(characters)}}}
            ]);
            f["scans"][0]["expectedRowCount"]=json!("2");
        }).is_ok(),accepted,"cumulative payload characters={characters}");
    }
    // 100x100 first join, followed by singleton joins: 10,000 complete tuples.
    // Every occurrence of each 256-byte scan key is charged, not only unique keys.
    for (scans,accepted) in [(6usize,true),(7,false)] {
        let mut sql="SELECT COUNT(*) FROM Resource a0".to_owned();
        for i in 1..scans { sql+=&format!(" JOIN Resource a{i} ON a0.token=a{i}.token"); }
        sql+=" LIMIT 0";
        assert_eq!(run(&sql,false,json!([]),|f,_|{
            for i in 0..scans {
                let n=if i<2 {100}else{1};
                f["scans"][i]["rows"]=json!((0..n).map(|j|json!({"key":format!("{j:0256}"),"cells":{"token":{"family":"string","value":"same"}}})).collect::<Vec<_>>());
                f["scans"][i]["expectedRowCount"]=json!(n.to_string());
            }
        }).is_ok(),accepted,"repeated contributor key occurrences scans={scans}");
    }
}
#[test]
fn astra_group_and_hidden_order_require_exact_effective_selection() {
    for projection in [true,false] {
        let sql=if projection {"SELECT r.token FROM Resource r GROUP BY r.token LIMIT 0"}else{"SELECT COUNT(*) FROM Resource r GROUP BY r.token ORDER BY r.token LIMIT 0"};
        assert!(run(sql,false,json!([]),|_,_|{}).is_ok());
        assert!(run(sql,false,json!([]),|f,s|{
            let target=if projection {"outputs/0/expression"}else{"order/0"};
            s.iter_mut().find(|v|v.path==target).unwrap().column="resourceId".into();
            for r in f["scans"][0]["rows"].as_array_mut().unwrap() {
                r["cells"]["resourceId"]=json!({"family":"string","value":"different-from-group-key"});
            }
        }).is_err(),"projection={projection}");
    }
}
#[test]
fn astra_multiple_directions_ties_and_unordered_subbags() {
    let sql="SELECT r.resourceId FROM Resource r ORDER BY r.token ASC,r.salary DESC LIMIT 2";
    let edit=|f:&mut serde_json::Value,_:&mut Vec<Selection>| {
        let vals=[("b",-2),("a",7),("a",-1),("a",7)];
        for (r,(token,salary)) in f["scans"][0]["rows"].as_array_mut().unwrap().iter_mut().zip(vals) {
            r["cells"]["token"]["value"]=json!(token);r["cells"]["salary"]["value"]=json!(salary.to_string());
        }
    };
    assert!(run(sql,false,json!([row(&[Some("r3")],&[&["k3"]]),row(&[Some("r5")],&[&["k5"]])]),edit).is_ok());
    assert!(run(sql,false,json!([row(&[Some("r5")],&[&["k5"]]),row(&[Some("r3")],&[&["k3"]])]),edit).is_ok());
    assert!(run(sql,false,json!([row(&[Some("r3")],&[&["k3"]]),row(&[Some("r4")],&[&["k4"]])]),edit).is_err());
    assert!(run(sql,false,json!([row(&[Some("r3")],&[&["k3"]]),row(&[Some("r3")],&[&["k3"]])]),edit).is_err());
}
