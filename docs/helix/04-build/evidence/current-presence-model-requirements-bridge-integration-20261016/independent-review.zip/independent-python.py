from pathlib import Path
import sys,json,hashlib,gzip,copy,gc,pickle,time,shutil
r=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'installed/combined'))
import weft
h=lambda b:hashlib.sha256(b).hexdigest()
enc=lambda v:json.dumps(v,separators=(',',':'),ensure_ascii=False)
prior=Path('/private/tmp/weft-model-requirements-astra-r1-20261016')
inputs=prior.joinpath('adversarial.json').read_bytes();r.joinpath('prior-core-controls.json.gz').write_bytes(gzip.compress(inputs,mtime=0))
checks=[];replays=[]
def ok(name,cond):
 checks.append({'id':name,'passed':bool(cond)});assert cond,name
for c in json.loads(inputs)['cases']:
 raw=enc(c['input']);expected=c['result'];stage='parent';out=None;error=None
 try:
  p=weft.prepare_application_lineage(raw);stage='context';child=p.prepare_current_presence();stage='requirements';out=child.model_requirements_json();stage='issued'
 except ValueError as e:error=str(e)
 ok(c['case']+':stage',stage==expected['stage'])
 if out is not None:
  actual=json.loads(out)
  ok(c['case']+':full-Core-report',actual==expected['report'])
  ok(c['case']+':actual-context',child.json()==expected['contextJson'])
  ok(c['case']+':byte-count',len(out.encode())==expected['reportBytes'])
  ok(c['case']+':full-source',actual['sourceRequestJson']==raw and actual['sourceRequestSha256']==h(raw.encode()))
  ok(c['case']+':same-parent',child.source_preparation() is p)
 else:ok(c['case']+':Core-error-code',error.startswith(expected['error']+': '))
 replays.append({'id':c['case'],'stage':stage,'error':error,'outputSha256':h(out.encode()) if out else None,'outputBytes':len(out.encode()) if out else None})
# Capacity crosses the new native-Python return boundary, retaining the actual Core bound.
capacity=[]
for n in [40,180]:
 b=(prior/f'capacity-{n}-input.json').read_bytes();(r/f'capacity-{n}-input.json').write_bytes(b)
 p=weft.prepare_application_lineage(b.decode().removesuffix('\n'));c=p.prepare_current_presence();start=time.monotonic();out=None;error=None
 try:out=c.model_requirements_json()
 except ValueError as e:error=str(e)
 if n==40:ok('capacity40-return-exact-size',out is not None and len(out.encode())==6841616)
 else:ok('capacity180-original-Core-refusal',out is None and error.startswith('WFT-CURRENT-PRESENCE-MODEL-REQUIREMENTS: '))
 capacity.append({'graphFields':n,'outputBytes':len(out.encode()) if out else None,'outputSha256':h(out.encode()) if out else None,'error':error,'seconds':time.monotonic()-start})
# A bound native descriptor alone must keep both child and actual parent alive.
raw=(r/'source/tests/current-query-presence/fixtures/unadmitted-context.request.json').read_text();p=weft.prepare_application_lineage(raw);c=p.prepare_current_presence();expected=c.model_requirements_json();pid=id(p);bound=c.model_requirements_json;del p,c;gc.collect()
ok('bound-descriptor-retains-child-parent',bound()==expected and id(bound.__self__.source_preparation())==pid)
c=bound.__self__;calls=[]
class Trap:
 def __str__(self):calls.append('str');raise AssertionError('coercion')
 def __len__(self):calls.append('len');raise AssertionError('coercion')
 def __getattr__(self,name):calls.append('getattr:'+name);raise AssertionError('coercion')
 def __index__(self):calls.append('index');raise AssertionError('coercion')
def refuses(name,fn,types=(TypeError,AttributeError)):
 try:fn()
 except types as e:ok(name,True);return {'id':name,'type':type(e).__name__,'message':str(e)}
 raise AssertionError(name)
errors=[]
wrong=[None,False,0,{},[],expected,json.loads(expected),b'{}',memoryview(b'{}'),Trap(),c.source_preparation()]
for i,v in enumerate(wrong):errors.append(refuses('receiver-'+str(i),lambda v=v:weft.CurrentPresencePreparation.model_requirements_json(v)))
for name,fn in [
 ('extra-positional',lambda:bound(Trap())),('extra-keyword',lambda:bound(source=Trap())),('fake-self-keyword',lambda:weft.CurrentPresencePreparation.model_requirements_json(self=c)),
 ('deepcopy',lambda:copy.deepcopy(c)),('pickle',lambda:pickle.dumps(c)),('reduce',lambda:c.__reduce_ex__(4)),
 ('instance-dict',lambda:vars(c)),('class-swap',lambda:setattr(c,'__class__',weft.CurrentQueryPreparation)),('instance-method-override',lambda:setattr(c,'model_requirements_json',lambda:'{}')),
 ('no-blank-construct',lambda:object.__new__(weft.CurrentPresencePreparation)),('no-json-reconstruction',lambda:weft.CurrentPresencePreparation(expected)),
]:errors.append(refuses(name,fn))
ok('no-trap-callbacks',calls==[]);ok('after-adversaries-still-identical',bound()==expected)
# Python class namespace mutability is not instance forgery or native descriptor replacement.
native_descriptor=weft.CurrentPresencePreparation.model_requirements_json
try:
 weft.CurrentPresencePreparation.model_requirements_json=lambda self:'{}'
 ok('local-monkeypatch-is-ordinary-Python',c.model_requirements_json()=='{}')
 ok('captured-native-descriptor-unchanged',native_descriptor(c)==expected and bound()==expected)
 errors.append(refuses('native-descriptor-still-refuses-dictionary',lambda:native_descriptor({})))
finally:weft.CurrentPresencePreparation.model_requirements_json=native_descriptor
ok('native-method-restored',c.model_requirements_json()==expected)
# Full requested identities and the authored ordered key survive, independently of names.
base=json.loads(expected);ident=lambda el:{'documentId':'domain','revision':'query-presence-core-r1','module':'m','element':el}
for name,fields in {'Staff':['staffId'],'Project':['projectId'],'Resource':['resourceId'],'Ownership':['ownerId'],'Assignment':['assignmentId']}.items():
 record=next(x for x in base['records'] if x['record']==ident(name));ok('full-key-'+name,record['selectedKey']=={'id':'pk','fields':[ident(x) for x in fields]})
receipt={'passed':all(x['passed'] for x in checks),'checks':checks,'checkCount':len(checks),'coreCases':len(replays),'replays':replays,'capacity':capacity,'boundaryErrors':errors,'nativeSha256':h(Path(weft.weft.__file__).read_bytes()),'priorInputsSha256':h(inputs),'SQLExecuted':False}
(r/'independent-python.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'checks':len(checks),'coreCases':len(replays),'passed':True}))
