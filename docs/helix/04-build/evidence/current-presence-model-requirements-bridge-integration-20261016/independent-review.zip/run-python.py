from pathlib import Path
import subprocess,json,time,hashlib
r=Path(__file__).resolve().parent
rows=[]
for label,script,installed,mode in [('new','python-model-requirements-bridge.py','combined','combined'),('old','python-model-requirements-bridge.py','old-presence','old-presence'),('default','python-model-requirements-bridge.py','default','default'),('existing','python-bridge.py','combined','combined')]:
 cmd=['/private/tmp/truss-practical-performance-env/bin/python','-B',str(r/'source/tests/current-query-presence'/script),str(r/'installed'/installed),mode,str(r/(label+'-checks.json'))]
 start=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True);(r/(label+'.stdout')).write_text(p.stdout);(r/(label+'.stderr')).write_text(p.stderr)
 rows.append({'id':label,'command':cmd,'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-start})
 print(label,p.returncode,flush=True)
(r/'python-executions.json').write_text(json.dumps(rows,indent=2)+'\n')
assert all(x['exitCode']==0 for x in rows)
