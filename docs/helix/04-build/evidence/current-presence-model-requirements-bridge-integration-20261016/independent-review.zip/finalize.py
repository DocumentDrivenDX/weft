from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
e='frozen/docs/helix/04-build/evidence/current-presence-model-requirements-bridge-20261016/'
source=json.loads((r/e/'retention.json').read_text())['source']
report={
 'status':'passed-scoped-source-runtime-python-review','remainingFindings':[],
 'packet':{'path':'review.zip','sha256':H((r/'review.zip').read_bytes()),'bytes':(r/'review.zip').stat().st_size},
 'candidate':'27c028d4101ae1af816574ecc185068ea069ed0f','baseline':'84fddd1090ee4549d126de514ae863949854c9e0','sourcePins':source,
 'conclusions':[
  'The new runtime method reuses private with_context over the same retained immutable Arc, checks the stored context report and returns actual Core requirements JSON. Python checks the actual retained Python parent/runtime Arc before this call; no source/report importer or callback is introduced.',
  'Existing original requested Field/Record identity and nested descriptor identity remain distinct; complete membership, ordered Key identity and Core refusal/capacity behavior survive the bridge. Independent runtime output equals actual Core output byte-for-byte.',
  'New feature enables the lower-layer requirements feature. Fresh old-presence wheel lacks the method; fresh default wheel lacks presence type/factory. Existing whole-disclosure bridge behavior remains intact.',
  'CONTRACT-016 correctly leaves closed/stale native-operation custody to the later host join. This preparation has no host operation handle and its returned JSON is incomplete data, not native authority.'
 ],
 'validation':[
  {'command':'python3.12 reconstruct.py; python3.12 candidate-audit.py','result':'7 source and31 evidence pins, all4468 inherited pins, all39 candidate Git deltas and3 wheels/15 package entries verified. All1855 present reconstructed input endpoints match after controls.','receipts':['source-audit.json','candidate-audit.json','source-after.json']},
  {'command':'python3.12 run-python.py (four fresh Python3.11.17 processes)','result':'56 new +415 existing combined-wheel controls;3 old-presence method-absence +2 default class/factory-absence controls pass.','receipts':['python-executions.json','new-checks.json','existing-checks.json','old-checks.json','default-checks.json']},
  {'command':'python3.11 -B independent-python.py','result':'148 checks pass, including36 retained reviewer-authored Core adversarial scenarios against actual native Python output, complete Keys/identities, nested array/map/structured graphs, wrong receivers/no coercion, bound-method parent GC retention,6,841,616-byte successful return and original oversize refusal.','receipt':'independent-python.json'},
  {'command':'cargo test --offline -p weft-runtime --features current-presence-model-requirements-candidate --lib','result':'8 passed;2.28s tests after46.18s build.','log':'runtime-tests.log'},
  {'command':'python3.12 runtime-controls.py','result':'3 fresh downstream feature clients produce expected E0432/E0599/success;3 independent runtime custody tests pass. Removing the context comparison causes both stored-report corruption and original-parent substitution tests to fail.','receipt':'runtime-controls.json'},
  {'command':'cargo check --offline -p weft-python --no-default-features --features current-presence-model-requirements-candidate','result':'Exact reconstructed Python extension source checks successfully with the new feature alone;20.65s.','log':'python-feature-source-check.log'}
 ],
 'wheels':[
  {'profile':label,'wheelSha256':json.loads((r/e/(label+'-wheel.json')).read_text())['wheelSha256'],'nativeSha256':json.loads((r/e/(label+'-wheel.json')).read_text())['entries']['weft/weft.abi3.so']['sha256']} for label in ['combined','old-presence','default']
 ],
 'qualifications':[
  'Independent execution used the supplied macOS ARM abi3 wheels and a separately compiled exact-source runtime/Python source check. Wheel build logs/source/package pins correspond as supplied evidence; no independent byte-reproducible wheel rebuild or hermetic toolchain attestation is claimed.',
  'Python extension class namespaces remain mutable by trusted local Python code. A local monkeypatch can return arbitrary data; it cannot change the captured original native descriptor or import a native preparation from a dictionary. Frozen refers to instance state, not hostile-code isolation within one interpreter.',
  'The16,000,000-byte Core output guard is retained. It is not a peak-memory/CPU or whole-host decoder capacity theorem.',
  'Owner75 artifact/96 schema and11 package/16 boundary results are retained and inspected, not independently rerun here. Original415 bridge controls were rerun on the new wheel.',
  'No SQL/native correspondence campaign, native source mapping/codec/graph proof, authenticated caller/current-cut/closing release admission, default/public wheel repin, WASM extension, or132 Weft/158 UMF case promotion. The separate paired-native source/evidence review is not retroactively expanded by this bridge review.',
  'Input hashes establish captured Git/package and endpoint correspondence, not continuously held-file/ABA protection. External compiler/Python/cache closure remains non-hermetic.'
 ],
 'retainedAttempts':[
  'Owner initial wrong-class placement E0599 source/log remains verbatim in frozen packet; no wheel from that failed attempt is treated as final.',
  'Reviewer first capacity expectation retained the line-delimited fixture newline; exact source preservation adds two JSON-escaped bytes. The corrected replay strips only that protocol newline to match the prior Core input.',
  'Reviewer second probe incorrectly expected immutable class namespace; retained failure now explicitly qualified above, with captured-native-descriptor control passing.',
  'Reviewer first mutation selector included a nonexistent space and refused before mutating source; corrected exact selector produced the expected two test failures. Original source restored.'
 ],
 'artifactManifest':{'path':'manifest.json','format':'relative path -> {sha256,bytes}; excludes itself','excludedReproducibleTrees':['source/ (base Git +7 retained overlays)','installed/ (three exact retained wheels)','target/ (external build products)']}
}
assert report['packet']['sha256']=='d6a199e1cdd6aeb7a06fb324656a24854fa0567b107b9f622500f56769b72b7c'
(r/'review.json').write_text(json.dumps(report,indent=2)+'\n')
manifest={}
for p in sorted(r.rglob('*')):
 rel=p.relative_to(r)
 if not p.is_file() or rel.parts[0] in {'source','installed','target'} or '__pycache__' in rel.parts or str(rel)=='manifest.json':continue
 b=p.read_bytes();manifest[str(rel)]={'sha256':H(b),'bytes':len(b)}
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'reviewSha256':H((r/'review.json').read_bytes()),'manifestSha256':H((r/'manifest.json').read_bytes()),'artifacts':len(manifest),'bytes':sum(x['bytes'] for x in manifest.values())},indent=2))
