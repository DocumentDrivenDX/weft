
#[cfg(all(test,feature="current-presence-model-requirements-candidate"))]
mod astra_requirements_controls{
 use super::*;
 const RAW:&str=include_str!("../../../tests/current-query-presence/fixtures/unadmitted-context.request.json");
 #[test] fn cached_context_corruption_refuses(){
  let p=prepare_application_lineage(RAW).unwrap();let mut c=p.prepare_current_presence().unwrap();c.preparation_json.push(' ');
  let e=c.model_requirements_json().unwrap_err();assert_eq!(e.code,"WFT-CURRENT-PRESENCE-BRIDGE");
 }
 #[test] fn original_replacement_is_detected_against_stored_context(){
  let p=prepare_application_lineage(RAW).unwrap();let mut c=p.prepare_current_presence().unwrap();let changed=format!("{} ",RAW);let other=prepare_application_lineage(&changed).unwrap();c.original=other.inner.clone();
  let e=c.model_requirements_json().unwrap_err();assert_eq!(e.code,"WFT-CURRENT-PRESENCE-BRIDGE");
 }
 #[test] fn byte_equal_other_arc_is_distinct_but_data_equal(){
  let p=prepare_application_lineage(RAW).unwrap();let other=prepare_application_lineage(RAW).unwrap();let a=p.prepare_current_presence().unwrap();let b=other.prepare_current_presence().unwrap();
  assert!(a.is_from(&p));assert!(!a.is_from(&other));assert!(b.is_from(&other));assert!(!b.is_from(&p));assert_eq!(a.model_requirements_json().unwrap(),b.model_requirements_json().unwrap());
 }
}
