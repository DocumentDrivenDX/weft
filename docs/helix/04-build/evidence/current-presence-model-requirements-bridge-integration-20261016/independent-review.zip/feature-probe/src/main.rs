use weft_runtime::CurrentPresencePreparation;
fn probe(c:&CurrentPresencePreparation){let _=c.model_requirements_json();}
fn main(){}
