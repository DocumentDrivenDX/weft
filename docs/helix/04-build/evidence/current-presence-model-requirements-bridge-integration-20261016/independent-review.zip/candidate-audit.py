from pathlib import Path
import json,subprocess,hashlib,gzip
r=Path(__file__).resolve().parent;f=r/'frozen';ep=Path('docs/helix/04-build/evidence/current-presence-model-requirements-bridge-20261016');m=json.loads((f/ep/'retention.json').read_text());repo='/Users/erik/Projects/weft';commit='27c028d4101ae1af816574ecc185068ea069ed0f';base=m['baseline'];rows=[]
for group in ['source','evidence']:
 for path,pin in m[group].items():
  b=subprocess.check_output(['git','-C',repo,'show',commit+':'+path]);assert hashlib.sha256(b).hexdigest()==pin['sha256'] and len(b)==pin['bytes'],path;rows.append({'path':path,'sha256':pin['sha256'],'bytes':pin['bytes']})
parent=subprocess.check_output(['git','-C',repo,'rev-parse',commit+'^'],text=True).strip();assert parent==base
changed=subprocess.check_output(['git','-C',repo,'diff','--name-only',base,commit],text=True).splitlines();expected=set(m['source'])|set(m['evidence'])|{str(ep/'retention.json')};assert set(changed)==expected,(set(changed)-expected,expected-set(changed))
# Separate source placement failure remains a failed attempt, not wheel evidence.
failed=gzip.decompress((f/ep/'new-wheel-build.log.gz').read_bytes()).decode();assert 'error[E0599]' in failed and 'could not compile' in failed
for label in ['combined','old-presence','default']:
 log=gzip.decompress((f/ep/(label+'-wheel-build.log.gz')).read_bytes()).decode();assert 'Built wheel' in log and 'error[E' not in log
(r/'candidate-audit.json').write_text(json.dumps({'passed':True,'candidate':commit,'parent':parent,'verified':rows,'changedPaths':changed,'initialFailureRetained':'E0599 Python method initially placed on wrong Rust receiver','buildQualification':'Supplied non-hermetic build logs; source and exact wheel package pins verified independently. Binary reproducibility not claimed.'},indent=2)+'\n');print(len(rows),len(changed))
