from pathlib import Path
import subprocess,os,json,hashlib,time,shutil
r=Path(__file__).resolve().parent;s=r/'source';target=r/'target';env=os.environ.copy();env.update(PATH='/Users/erik/.rustup/toolchains/1.90.0-aarch64-apple-darwin/bin:/opt/homebrew/bin:'+env['PATH'],CARGO_HOME='/private/tmp/ashlar-weft-compatible-toolchain-20261013-a/cargo',CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='2')
rows=[]
def run(label,args):
 t=time.monotonic();p=subprocess.run(args,cwd=s,env=env,capture_output=True,text=True);(r/(label+'.log')).write_text(p.stdout+p.stderr);row={'id':label,'command':args,'exitCode':p.returncode,'seconds':time.monotonic()-t};rows.append(row);return p
probe=r/'feature-probe';(probe/'src').mkdir(parents=True,exist_ok=True);(probe/'src/main.rs').write_text('use weft_runtime::CurrentPresencePreparation;\nfn probe(c:&CurrentPresencePreparation){let _=c.model_requirements_json();}\nfn main(){}\n')
for label,features,error in [('default',[],'E0432'),('old-presence',['current-presence-candidate'],'E0599'),('new',['current-presence-model-requirements-candidate'],None)]:
 (probe/'Cargo.toml').write_text('[package]\nname="astra-requirements-bridge-boundary"\nversion="0.0.0"\nedition="2021"\n[dependencies]\nweft-runtime={path='+json.dumps(str(s/'crates/weft-runtime'))+',default-features=false,features='+json.dumps(features)+'}\n[patch.crates-io]\nahash={path='+json.dumps(str(s/'vendor/ahash'))+'}\n')
 shutil.copy2(probe/'Cargo.toml',r/('feature-'+label+'.toml'))
 p=run('feature-'+label,['cargo','check','--offline','--manifest-path',str(probe/'Cargo.toml')]);valid=p.returncode==0 if error is None else p.returncode==101 and ('error['+error+']') in p.stderr and p.stderr.count('error[')==1
 rows[-1]['expectedError']=error;rows[-1]['passed']=valid;assert valid,label
path=s/'crates/weft-runtime/src/lib.rs';original=path.read_bytes()
extra=r'''\n#[cfg(all(test,feature="current-presence-model-requirements-candidate"))]
mod astra_requirements_controls{
 use super::*;
 const RAW:&str=include_str!("../../../tests/current-query-presence/fixtures/unadmitted-context.request.json");
 #[test] fn cached_context_corruption_refuses(){
  let p=prepare_application_lineage(RAW).unwrap();let mut c=p.prepare_current_presence().unwrap();c.preparation_json.push(' ');
  let e=c.model_requirements_json().unwrap_err();assert_eq!(e.code,"WFT-CURRENT-PRESENCE-BRIDGE");
 }
 #[test] fn original_replacement_is_detected_against_stored_context(){
  let p=prepare_application_lineage(RAW).unwrap();let mut c=p.prepare_current_presence().unwrap();let changed=format!("{} ",RAW);let other=prepare_application_lineage(&changed).unwrap();c.original=other.inner.clone();
  let e=c.model_requirements_json().unwrap_err();assert_eq!(e.code,"WFT-CURRENT-PRESENCE-BRIDGE");
 }
 #[test] fn byte_equal_other_arc_is_distinct_but_data_equal(){
  let p=prepare_application_lineage(RAW).unwrap();let other=prepare_application_lineage(RAW).unwrap();let a=p.prepare_current_presence().unwrap();let b=other.prepare_current_presence().unwrap();
  assert!(a.is_from(&p));assert!(!a.is_from(&other));assert!(b.is_from(&other));assert!(!b.is_from(&p));assert_eq!(a.model_requirements_json().unwrap(),b.model_requirements_json().unwrap());
 }
}
'''.replace('\\n','\n',1).encode()
(r/'runtime-extra-tests.rs').write_bytes(extra)
cmd=['cargo','test','--offline','-p','weft-runtime','--features','current-presence-model-requirements-candidate','--lib','astra_requirements_controls']
try:
 path.write_bytes(original+extra);p=run('runtime-independent',cmd);assert p.returncode==0,p.stderr[-1000:]
 mutant=(original+extra).replace(b'if prepared.json()!=self.preparation_json{',b'if false {')
 assert mutant!=original+extra
 (r/'runtime-mutant-no-context-comparison.rs').write_bytes(mutant);path.write_bytes(mutant);p=run('runtime-mutant-no-context-comparison',cmd)
 valid=p.returncode==101 and 'cached_context_corruption_refuses ... FAILED' in p.stdout and 'original_replacement_is_detected_against_stored_context ... FAILED' in p.stdout
 rows[-1]['passed']=valid;assert valid,p.stdout[-1500:]
finally:path.write_bytes(original)
(r/'runtime-controls.json').write_text(json.dumps({'executions':rows,'sourceRestoredSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'passed':True},indent=2)+'\n');print(json.dumps({'executions':len(rows),'passed':True}))
