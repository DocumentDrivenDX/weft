from pathlib import Path
import hashlib,json,subprocess,tarfile,shutil,difflib
r=Path(__file__).parent;e=r/'frozen/docs/helix/04-build/evidence/current-presence-model-requirements-bridge-20261016';m=json.loads((e/'retention.json').read_bytes());inherited=json.loads((e/'inherited-baseline-inputs.json').read_bytes());expected={x['path']:x for x in inherited['files']};checked=set();baseblobs={}
p=subprocess.Popen(['git','archive','--format=tar',m['baseline']],cwd='/Users/erik/Projects/weft',stdout=subprocess.PIPE)
with tarfile.open(fileobj=p.stdout,mode='r|') as t:
 for member in t:
  if not member.isfile():continue
  b=t.extractfile(member).read();n=member.name;h=hashlib.sha256(b).hexdigest()
  if n in expected:
   assert len(b)==expected[n]['bytes'] and h==expected[n]['sha256'],n;checked.add(n)
  if n in m['source']:baseblobs[n]=b
  if not n.startswith('docs/helix/04-build/evidence/') or n in {'docs/helix/04-build/evidence/B-006-cross-module-native/compile.json','docs/helix/04-build/evidence/B-005-row-tree-custody-native.json','docs/helix/04-build/evidence/B-005-row-custody-native.json','docs/helix/04-build/evidence/B-005-original-recursive-row-native.json','docs/helix/04-build/evidence/mutation-current-truss-20261014/native-query-bundle.json'}:
   d=r/'source'/n;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
assert p.wait()==0 and checked==set(expected)
rows=[]
for group in ['source','evidence']:
 for n,pin in m[group].items():
  b=(r/'frozen'/n).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'],n
  if group=='source':
   old=baseblobs.get(n);assert (hashlib.sha256(old).hexdigest() if old is not None else None)==pin['baselineSha256'],n
   q=r/'diffs'/(n.replace('/','__')+'.diff');q.parent.mkdir(exist_ok=True);q.write_text(''.join(difflib.unified_diff((old or b'').decode().splitlines(True),b.decode().splitlines(True),fromfile='base/'+n,tofile='candidate/'+n)))
   dest=r/'source'/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
  rows.append({'group':group,'path':n,**pin})
(r/'source-audit.json').write_text(json.dumps({'status':'passed','baseline':m['baseline'],'inheritedVerified':len(checked),'packetEntries':rows,'reconstruction':'Exact baseline source/config/docs/test roots; inherited bulk historical evidence excluded except static compiler fixture includes. All inherited bytes independently checked from Git archive.'},indent=2)+'\n')
for label in ['combined','old-presence','default']:
 manifest=json.loads((e/(label+'-wheel.json')).read_bytes());w=e/(label+'-weft-sql-local-candidate.whl');assert hashlib.sha256(w.read_bytes()).hexdigest()==manifest['wheelSha256']
 import zipfile
 with zipfile.ZipFile(w) as z:
  assert set(z.namelist())==set(manifest['entries'])
  for n,pin in manifest['entries'].items():
   b=z.read(n);assert hashlib.sha256(b).hexdigest()==pin['sha256'] and len(b)==pin['bytes'];d=r/'installed'/label/n;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
print(json.dumps({'source':len(m['source']),'evidence':len(m['evidence']),'inherited':len(checked),'wheels':3,'wheelMembers':15}))
