from pathlib import Path
import subprocess,tarfile,io,json,hashlib,shutil
out=Path(__file__).parent;repo=Path('/Users/erik/Projects/weft');base='377a5530f8aecd8c2ecbe3ae4f67cd0c0fbce3b5'
raw=(out/'baseline.tar').read_bytes()
with tarfile.open(fileobj=io.BytesIO(raw)) as t:t.extractall(out/'source',filter='data')
m=json.loads((out/'frozen/docs/helix/04-build/evidence/current-presence-model-requirements-20261016/retention.json').read_bytes());checks=[]
for group in ['source','evidence']:
 for rel,pin in m[group].items():
  p=out/'frozen'/rel;b=p.read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'],rel
  if group=='source':
   old=out/'source'/rel;h=hashlib.sha256(old.read_bytes()).hexdigest() if old.exists() else None;assert h==pin['baselineSha256'],rel
  checks.append({'path':rel,**pin})
  dest=out/'source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
(out/'packet-audit.json').write_text(json.dumps({'status':'passed','baseline':base,'sourceFiles':len(m['source']),'evidenceFiles':len(m['evidence']),'entries':checks},indent=2)+'\n')
print('reconstructed',len(raw),len(checks))
