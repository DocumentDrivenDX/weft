use std::io::{self,BufRead};
use serde_json::{Value,json};
use weft_core::{application_lineage,current_presence,current_presence_model_requirements};
fn run(raw:&str)->Value{
 let p=match application_lineage::prepare(raw){Ok(x)=>x,Err(e)=>return json!({"stage":"parent","error":e.code,"message":e.message})};
 let c=match current_presence::prepare(&p){Ok(x)=>x,Err(e)=>return json!({"stage":"context","error":e.code,"message":e.message})};
 let q=match current_presence_model_requirements::derive(&c){Ok(x)=>x,Err(e)=>return json!({"stage":"requirements","error":e.code,"message":e.message})};
 let other=application_lineage::prepare(raw).unwrap();let oc=current_presence::prepare(&other).unwrap();let oq=current_presence_model_requirements::derive(&oc).unwrap();
 json!({"stage":"issued","report":serde_json::from_str::<Value>(q.json()).unwrap(),"reportBytes":q.json().len(),"parentPointer":std::ptr::eq(q.context().preparation(),&p),"contextPointer":std::ptr::eq(q.context(),&c),"otherContextPointer":std::ptr::eq(q.context(),&oc),"equalDataDifferentContext":q.json()==oq.json(),"contextJson":c.json()})
}
fn main(){for l in io::stdin().lock().lines(){let l=l.unwrap();println!("{}",run(&l));}}
