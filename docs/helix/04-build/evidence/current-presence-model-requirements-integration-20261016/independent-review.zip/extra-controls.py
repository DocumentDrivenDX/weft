from pathlib import Path
import json,copy,subprocess,time
r=Path(__file__).parent
# Load only fixture/control authoring definitions; avoid rerunning the first matrix.
ns={"__file__":str(r/"adversarial.py")};exec(compile((r/'adversarial.py').read_text().split('rows=[]\np=subprocess')[0],str(r/'adversarial.py'),'exec'),ns)
D,H,fixture,src,profile,ontology,model,el,ref=[ns[k] for k in ['D','H','fixture','src','profile','ontology','model','el','ref']]
rows=[]
def run(name,q,expected):
 t=time.time();s=D(q);p=subprocess.run([str(r/'target/debug/astra-model-requirements-probe')],input=s+'\n',capture_output=True,text=True,timeout=60);assert p.returncode==0,(name,p.stderr);o=json.loads(p.stdout);ok=expected(o)
 rows.append({'name':name,'input':q,'result':o,'passed':ok,'seconds':time.time()-t});print(name,o['stage'],ok,flush=True)
q=fixture()
def move(d):
 es=d['modules'][0]['elements'];picked=[copy.deepcopy(x) for x in es if x['id'] in ['Staff','staffId']]
 for x in picked:
  if x['id']=='Staff':
   for f in x['members']+x['keys'][0]['fields']:f['module']='n'
 d['modules'].append({'id':'n','namespace':'other','extensions':{},'elements':picked})
model(q,move);q['modules'][0]['selectedModuleIds'].append('n')
ontology(q,lambda o:(o['entities'][0]['type'].update(moduleId='n'),o['entities'][0]['fields'][0]['ref'].update(moduleId='n')))
run('same-local-ids-different-module',q,lambda o:o['stage']=='issued' and o['report']['records'][-1]['record']['module']=='n' and o['report']['records'][-1]['fields'][0]['field']['module']=='n')
q=fixture();other=copy.deepcopy(q['modules'][0]);d=json.loads(other['documentJson']);d['id']='other-domain';d['modules'][0]['elements']=[x for x in d['modules'][0]['elements'] if x['id'] in ['Staff','staffId']];d['modules'][0]['namespace']='other';other['documentJson']=D(d);other['pin'].update(documentId='other-domain',revision='second-r9',sha256=H(other['documentJson']));q['modules'].append(other);profile(q,lambda p:p.update(modelPins=[m['pin'] for m in q['modules']]))
ontology(q,lambda o:(o['entities'][0]['type'].update(documentId='other-domain'),o['entities'][0]['fields'][0]['ref'].update(documentId='other-domain')))
run('same-local-ids-different-document-revision',q,lambda o:o['stage']=='issued' and o['report']['records'][-1]['record']['documentId']=='other-domain' and o['report']['records'][-1]['fields'][0]['field']['revision']=='second-r9')
q=fixture()
def many(d):
 es=d['modules'][0]['elements']
 for i in range(4091):es.append({'id':f'R{i:04}','kind':'record','name':f'R{i:04}','extensions':{},'members':[{'module':'m','element':'staffId'}],'keys':[{'id':'pk','name':'Key','fields':[{'module':'m','element':'staffId'}]}]})
model(q,many)
ontology(q,lambda o:o['entities'].extend({'type':ref(f'R{i:04}'),'keyId':'pk','fields':[{'ref':ref('staffId')}]} for i in range(4091)))
run('entity-limit4096-complete-valid-records',q,lambda o:o['stage']=='issued' and len(o['report']['records'])==4096)
model(q,lambda d:d['modules'][0]['elements'].append({'id':'R4091','kind':'record','name':'R4091','extensions':{},'members':[{'module':'m','element':'staffId'}],'keys':[{'id':'pk','name':'Key','fields':[{'module':'m','element':'staffId'}]}]}))
ontology(q,lambda o:o['entities'].append({'type':ref('R4091'),'keyId':'pk','fields':[{'ref':ref('staffId')}]}))
run('entity-limit4097-complete-valid-records',q,lambda o:o['stage']=='requirements')
(r/'extra-controls.json').write_text(json.dumps({'cases':rows,'passed':all(x['passed'] for x in rows)},indent=2)+'\n')
