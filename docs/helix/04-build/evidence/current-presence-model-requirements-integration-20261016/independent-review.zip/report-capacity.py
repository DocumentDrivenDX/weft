from pathlib import Path
import json,subprocess,time
r=Path(__file__).parent;ns={'__file__':str(r/'adversarial.py')};exec(compile((r/'adversarial.py').read_text().split('rows=[]\np=subprocess')[0],str(r/'adversarial.py'),'exec'),ns)
D,fixture,model,ontology,ref=[ns[k] for k in ['D','fixture','model','ontology','ref']]
rows=[]
for count,expected in [(40,'issued'),(180,'requirements')]:
 q=fixture()
 def add(d):
  es=d['modules'][0]['elements'];names=[f'inner{i:03}' for i in range(500)]
  es.extend({'id':n,'kind':'field','name':n,'scalarType':'string','cardinality':'one','nullability':'required','extensions':{}} for n in names)
  es.append({'id':'Nested','kind':'record','name':'Nested','members':[{'module':'m','element':n} for n in names],'extensions':{}})
  es.append({'id':'container','kind':'field','name':'container','cardinality':'one','nullability':'required','references':[{'module':'m','element':'Nested','role':'record-type'}],'extensions':{}})
  es.extend({'id':f'Extra{i:03}','name':f'Extra{i:03}','kind':'record','extensions':{},'members':[{'module':'m','element':'staffId'},{'module':'m','element':'container'}],'keys':[{'id':'pk','name':'Key','fields':[{'module':'m','element':'staffId'}]}]} for i in range(count))
 model(q,add);ontology(q,lambda o:o['entities'].extend({'type':ref(f'Extra{i:03}'),'keyId':'pk','fields':[{'ref':ref('staffId')},{'ref':ref('container')}]} for i in range(count)))
 raw=D(q);t=time.time();p=subprocess.run([str(r/'target/debug/astra-model-requirements-probe')],input=raw+'\n',capture_output=True,text=True,timeout=60);assert p.returncode==0,p.stderr;o=json.loads(p.stdout)
 # Retain exact inputs; avoid duplicating the whole large positive report.
 (r/f'capacity-{count}-input.json').write_text(raw+'\n')
 row={'count':count,'requestBytes':len(raw.encode()),'stage':o['stage'],'reportBytes':o.get('reportBytes'),'error':o.get('error'),'seconds':time.time()-t,'passed':o['stage']==expected};rows.append(row);print(row,flush=True)
(r/'report-capacity.json').write_text(json.dumps({'cases':rows,'passed':all(x['passed'] for x in rows)},indent=2)+'\n')
