from pathlib import Path
import json,subprocess,hashlib,time
r=Path(__file__).parent;p=r/'source/crates/weft-core/src/current_presence_model_requirements.rs';original=p.read_text();data=json.loads((r/'adversarial.json').read_text());cases={x['case']:x for x in data['cases']};rows=[]
mutants=[('omit-member-census','if seen!=members{return Err(fail())}','if false{return Err(fail())}','missing-member',lambda o:o['stage']=='issued'),('omit-association-key','if selected.get(&r).map(String::as_str)!=association["keyId"].as_str(){return Err(fail())}','if false{return Err(fail())}','association-key-different',lambda o:o['stage']=='issued'),('collapse-requested-field-to-nested-descriptor','"field":id,"descriptors":descriptors','"field":descriptors.last().unwrap().identity,"descriptors":descriptors','nested-array',lambda o:o['stage']=='issued' and any(f['field']['element']=='inner' for x in o['report']['records'] if x['record']['element']=='Staff' for f in x['fields'])),('reverse-key-order','"fields":ordered','"fields":ordered.into_iter().rev().collect::<Vec<_>>()','composite-key-reversed',lambda o:o['stage']=='issued' and next(x for x in o['report']['records'] if x['record']['element']=='Resource')['selectedKey']['fields'][0]['element']=='resourceId')]
try:
 for name,old,new,case,caught in mutants:
  assert original.count(old)==1,name
  s=original.replace(old,new);p.write_text(s);d=r/'mutants'/name;d.mkdir(parents=True,exist_ok=True);(d/'source.rs').write_text(s)
  cmd=['/private/tmp/weft-toolchain/venv/bin/python',str(r/'run-cargo.py'),'build','--offline','--manifest-path',str(r/'probe/Cargo.toml')]
  t=time.time();build=subprocess.run(cmd,capture_output=True,text=True);(d/'build.log').write_text(build.stdout+build.stderr);assert build.returncode==0,(name,build.stderr[-1000:])
  raw=json.dumps(cases[case]['input'],separators=(',',':'),ensure_ascii=False);x=subprocess.run([str(r/'target/debug/astra-model-requirements-probe')],input=raw+'\n',capture_output=True,text=True,timeout=30);assert x.returncode==0;o=json.loads(x.stdout);(d/'result.json').write_text(json.dumps(o,indent=2)+'\n')
  rows.append({'id':name,'case':case,'sourceSha256':hashlib.sha256(s.encode()).hexdigest(),'binarySha256':hashlib.sha256((r/'target/debug/astra-model-requirements-probe').read_bytes()).hexdigest(),'caught':caught(o),'seconds':time.time()-t});print(name,rows[-1]['caught'],flush=True)
finally:
 p.write_text(original)
 build=subprocess.run(['/private/tmp/weft-toolchain/venv/bin/python',str(r/'run-cargo.py'),'build','--offline','--manifest-path',str(r/'probe/Cargo.toml')],capture_output=True,text=True);(r/'restored-build.log').write_text(build.stdout+build.stderr);assert build.returncode==0
(r/'mutations.json').write_text(json.dumps({'cases':rows,'passed':len(rows)==4 and all(x['caught'] for x in rows),'sourceRestored':p.read_text()==original,'restoredBinarySha256':hashlib.sha256((r/'target/debug/astra-model-requirements-probe').read_bytes()).hexdigest()},indent=2)+'\n')
