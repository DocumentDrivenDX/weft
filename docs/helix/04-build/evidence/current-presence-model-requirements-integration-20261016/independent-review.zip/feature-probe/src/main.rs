use weft_core::current_presence_model_requirements::CurrentPresenceModelRequirements;
fn main(){let _:Option<CurrentPresenceModelRequirements>=None;}
