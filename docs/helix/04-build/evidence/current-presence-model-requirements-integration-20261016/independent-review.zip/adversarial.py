from pathlib import Path
import json,hashlib,copy,subprocess,time
r=Path(__file__).parent
D=lambda v:json.dumps(v,separators=(',',':'),ensure_ascii=False)
H=lambda s:hashlib.sha256(s.encode()).hexdigest()
raw=json.loads((r/'source/tests/current-query-presence/fixtures/optional-token-lineage.request.json').read_text())
def src(q,role):return next(s for s in q['opaqueSources'] if s['role']==role)
def fixture():
 q=copy.deepcopy(raw);pins=[{'role':s['role'],'identity':s['identity'],'sha256':s['sha256']} for s in q['opaqueSources']]
 o=json.loads(src(q,'ontology')['utf8']);action=next(x['action'] for x in o['actionPurposes'] if 'read' in x['purposes'])
 native=D({'version':'weft.presence-test-source/0.1-candidate','scope':'unadmitted fixture'});ident={'documentId':'presence-test-native-source','revision':'test-r1'}
 q['opaqueSources'].append({'role':'native-binding','identity':ident,'mediaType':'application/json','utf8':native,'sha256':H(native)})
 p={'version':'weft.current-presence.designation-profile/0.1-candidate','id':'presence-profile','revision':'presence-r1','modelPins':[m['pin'] for m in q['modules']],'sources':pins,'binding':{'backendId':'test.presence-source','backendVersion':'0.1-candidate','targetProfile':'unadmitted-fixture','source':ident,'sha256':H(native)},'targets':[{'documentId':'domain','moduleId':'m','elementId':'Resource'}],'primaryAction':action,'capabilities':['tagged-current-projection'],'producer':{'protocol':'umf.security.logical-disclosure-batch/0.1-candidate','entrypoint':'evaluateCandidateCatalogReadDisclosureBatchWithinOperation'}}
 p=D(p);q['opaqueSources'].append({'role':'presence-designation','identity':{'documentId':'presence-profile','revision':'presence-r1'},'mediaType':'application/json','utf8':p,'sha256':H(p)})
 return q
def profile(q,fn):
 s=src(q,'presence-designation');p=json.loads(s['utf8']);fn(p);s['utf8']=D(p);s['sha256']=H(s['utf8'])
def ontology(q,fn):
 s=src(q,'ontology');o=json.loads(s['utf8']);fn(o);s['utf8']=D(o);s['sha256']=H(s['utf8']);profile(q,lambda p:next(x for x in p['sources'] if x['role']=='ontology').update(sha256=s['sha256']))
def model(q,fn):
 m=q['modules'][0];d=json.loads(m['documentJson']);fn(d);m['documentJson']=D(d);m['pin']['sha256']=H(m['documentJson']);profile(q,lambda p:p.update(modelPins=[x['pin'] for x in q['modules']]))
def el(d,name):return next(e for e in d['modules'][0]['elements'] if e['id']==name)
def rec(out,name):return next(x for x in out['report']['records'] if x['record']['element']==name)
def field(out,owner,name):return next(x for x in rec(out,owner)['fields'] if x['field']['element']==name)
def ref(name,module='m',document='domain'):return {'documentId':document,'moduleId':module,'elementId':name}
cases=[]
def case(name,edit=lambda q:None,stage='issued',extra=None):
 q=fixture();edit(q);cases.append((name,q,stage,extra))
case('base')
case('entity-and-field-order',lambda q:ontology(q,lambda o:(o['entities'].reverse(),[e['fields'].reverse() for e in o['entities']])),extra=lambda o,q: [f['field']['element'] for f in rec(o,'Resource')['fields']]==['token','salary','resourceId'])
case('source-whitespace-and-unicode',lambda q:ontology(q,lambda o:o.update({'x-original':{'unknown':'e\u0301\U0001f642','precision':'9007199254740993.000000001'}})))
for name,fn in [
 ('missing-member',lambda o:o['entities'][2]['fields'].pop()),
 ('duplicate-member',lambda o:o['entities'][2]['fields'].append(copy.deepcopy(o['entities'][2]['fields'][0]))),
 ('foreign-member',lambda o:o['entities'][2]['fields'][0].update(ref=ref('staffId'))),
 ('duplicate-entity',lambda o:o['entities'].append(copy.deepcopy(o['entities'][0]))),
 ('no-entities',lambda o:o.update(entities=[])),
 ('entity-limit4097',lambda o:o.update(entities=[copy.deepcopy(o['entities'][0]) for _ in range(4097)])),
 ('association-limit4097',lambda o:o.update(associations=[{'kind':'future'} for _ in range(4097)])),
 ('unknown-key',lambda o:o['entities'][2].update(keyId='missing')),
 ('association-key-different',lambda o:o['associations'][0].update(keyId='other')),
 ('association-unlisted-record',lambda o:o['associations'][0].update(type=ref('notAnEntity'))),
 ('association-missing-key',lambda o:o['associations'][0].pop('keyId')),
 ('ref-unknown-field',lambda o:o['entities'][0]['type'].update(revision='r1')),
 ('ref-wrong-type',lambda o:o['entities'][0]['type'].update(moduleId=3)),
 ('ref-cross-module',lambda o:o['entities'][0]['type'].update(moduleId='other')),
 ('ref-cross-document',lambda o:o['entities'][0]['type'].update(documentId='other')),
]:case(name,lambda q,f=fn:ontology(q,f),'requirements')
case('unknown-graph4096-not-admitted',lambda q:ontology(q,lambda o:o.update(associations=[{'kind':'future','direction':'uninterpreted','x':None} for _ in range(4096)])))
case('unknown-graph-null-retained-not-admitted',lambda q:ontology(q,lambda o:o.update(associations=[None])))
for shape in ['array','map','structured']:
 def add(q,shape=shape):
  def addmodel(d):
   es=d['modules'][0]['elements'];es.append({'id':'inner','kind':'field','name':'Nested value','extensions':{},'scalarType':'string','nullability':'absent-allowed','cardinality':'one'})
   f={'id':'staffContainer','kind':'field','name':'Container','extensions':{},'nullability':'absent-allowed','cardinality':shape if shape!='structured' else 'one'}
   if shape=='structured':
    es.append({'id':'Nested','kind':'record','name':'Nested','extensions':{},'members':[{'module':'m','element':'inner'}]});f['references']=[{'module':'m','element':'Nested','role':'record-type'}]
   else:f['itemType']={'module':'m','element':'inner'}
   es.append(f);el(d,'Staff')['members'].append({'module':'m','element':'staffContainer'})
  model(q,addmodel);ontology(q,lambda o:o['entities'][0]['fields'].append({'ref':ref('staffContainer')}))
 case('nested-'+shape,add,extra=lambda out,q,shape=shape:field(out,'Staff','staffContainer')['field']['element']=='staffContainer' and [x['identity']['element'] for x in field(out,'Staff','staffContainer')['descriptors']]==(['staffContainer','Nested','inner'] if shape=='structured' else ['staffContainer','inner']))
case('renamed-authored-names-still-exact-identity',lambda q:model(q,lambda d:(el(d,'Staff').update(name='Different Record Label'),el(d,'staffId').update(name='Different Field Label'))))
case('composite-key-reversed',lambda q:model(q,lambda d:el(d,'Resource')['keys'][0].update(fields=[{'module':'m','element':'salary'},{'module':'m','element':'resourceId'}])),extra=lambda out,q:[x['element'] for x in rec(out,'Resource')['selectedKey']['fields']]==['salary','resourceId'])
for name,fn in [
 ('duplicate-key-component',lambda d:el(d,'Resource')['keys'][0].update(fields=[{'module':'m','element':'resourceId'}]*2)),
 ('foreign-key-component',lambda d:el(d,'Resource')['keys'][0].update(fields=[{'module':'m','element':'staffId'}])),
 ('empty-key',lambda d:el(d,'Resource')['keys'][0].update(fields=[])),
 ('optional-key-component',lambda d:el(d,'Resource')['keys'][0].update(fields=[{'module':'m','element':'token'}])),
 ('unknown-key-metadata',lambda d:el(d,'Resource')['keys'][0].update(future='unknown')),
 ('member-unknown-cardinality',lambda d:el(d,'active').update(cardinality='many')),
 ('member-unspecified-availability',lambda d:el(d,'active').update(nullability='unspecified')),
]:case(name,lambda q,f=fn:model(q,f),'refused')
case('binding-pin-drift',lambda q:src(q,'native-binding').update(utf8='{}'),'parent')
case('profile-version-unknown',lambda q:profile(q,lambda p:p.update(version='weft.current-presence.designation-profile/999')),'context')
case('model-sha-drift',lambda q:q['modules'][0]['pin'].update(sha256='0'*64),'parent')
case('unknown-model-revision',lambda q:q['modules'][0]['pin'].update(revision='different'),'context')
# Exact parent/context issuance is part of every control, not mocked.
rows=[]
p=subprocess.Popen([str(r/'target/debug/astra-model-requirements-probe')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
for name,q,stage,extra in cases:
 s=D(q);t=time.monotonic();p.stdin.write(s+'\n');p.stdin.flush();line=p.stdout.readline();assert line,name
 out=json.loads(line);ok=out['stage']==stage if stage!='refused' else out['stage']!='issued'
 checks={'expectedStage':ok}
 if out['stage']=='issued':
  report=out['report'];checks.update({'sourceExact':report['sourceRequestJson']==s,'sourceSha':report['sourceRequestSha256']==H(s),'preparationSha':report['preparationSha256']==H(out['contextJson']),'ontologySha':report['ontologySha256']==H(src(q,'ontology')['utf8']),'authorityFalse':all(report[k] is False for k in ['authority','complete','securityReady']),'nativeRequired':report['nativeAdmission']=='required','contextCustody':out['parentPointer'] and out['contextPointer'] and not out['otherContextPointer'] and out['equalDataDifferentContext'],'size':out['reportBytes']<=16000000,'sortedRecords':[x['record'] for x in report['records']]==sorted([x['record'] for x in report['records']],key=lambda x:(x['documentId'],x['module'],x['element']))})
  if extra:checks['independentExpected']=extra(out,q)
 rows.append({'case':name,'input':q,'result':out,'checks':checks,'seconds':time.monotonic()-t})
 if not all(checks.values()):print(name,stage,out['stage'],checks,flush=True)
p.stdin.close();assert p.wait()==0
(r/'adversarial.json').write_text(json.dumps({'cases':rows,'caseCount':len(rows),'checkCount':sum(len(x['checks']) for x in rows),'passed':all(all(x['checks'].values()) for x in rows)},indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'cases':len(rows),'checks':sum(len(x['checks']) for x in rows),'failures':[x['case'] for x in rows if not all(x['checks'].values())]}))
