from pathlib import Path
import os,subprocess,json,sys,time
r=Path(__file__).parent
e=os.environ.copy();e.update(PATH='/Users/erik/.rustup/toolchains/1.90.0-aarch64-apple-darwin/bin:/opt/homebrew/bin:'+e['PATH'],CARGO_HOME='/private/tmp/ashlar-weft-compatible-toolchain-20261013-a/cargo',CARGO_TARGET_DIR=str(r/'target'),CARGO_BUILD_JOBS='2')
args=sys.argv[1:];start=time.time();x=subprocess.run(['cargo',*args],cwd=r/'source',env=e);print(json.dumps({'command':['cargo',*args],'exit':x.returncode,'seconds':time.time()-start}));sys.exit(x.returncode)
