"""Exact actual CLI record conversion; no producer or expectation rewriting."""
import argparse,gzip,hashlib,json,zlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--input',required=True,type=Path);p.add_argument('--output',required=True,type=Path);p.add_argument('--receipt',required=True,type=Path);a=p.parse_args()
with a.input.open('rb') as f:raw=f.read(4*1024*1024+1)
if len(raw)>4*1024*1024:raise ValueError('compressed-bound')
d=zlib.decompressobj(16+zlib.MAX_WBITS);decoded=d.decompress(raw,64*1024*1024+1)
if len(decoded)>64*1024*1024 or not d.eof or d.unused_data or d.unconsumed_tail:raise ValueError('single-gzip-receipt')
value=json.loads(decoded)
if value['protocolCases']!=80 or value['declaredCapabilities']!=49 or len(value['cases'])!=80:raise ValueError('full80-receipt')
rows=[]
for c in value['cases']:
 request=bytes.fromhex(c['requestHex']);response=bytes.fromhex(c['responseHex'])
 if not response.endswith(b'\n') or len(request)>16*1024*1024 or len(response)>4*1024*1024:raise ValueError('exact-record-bound')
 if hashlib.sha256(response).hexdigest()!=c['responseSha256']:raise ValueError('actual-response-pin')
 rows.append({'id':c['id'],'request':request.decode('utf8'),'expected':response[:-1].decode('utf8')})
if len({c['id'] for c in rows})!=80:raise ValueError('unique-full80')
output=(json.dumps(rows,ensure_ascii=False,separators=(',',':'))+'\n').encode()
if len(output)>32*1024*1024:raise ValueError('parity-corpus-bound')
with a.output.open('xb') as f:f.write(output)
receipt={'inputSha256':hashlib.sha256(raw).hexdigest(),'inputBytes':len(raw),'casesSha256':hashlib.sha256(output).hexdigest(),'casesBytes':len(output),'cases':80,'qualification':'Lossless CLI request/full-response conversion with exactly one CLI framing newline removed; no SQL, model, binding, response or expected artifact normalization.'}
with a.receipt.open('x') as f:json.dump(receipt,f,sort_keys=True,indent=2);f.write('\n')
