"""Guard selected venv identity around the existing reviewed bounded launcher."""
import hashlib,json,pathlib,runpy,sys
args=sys.argv[1:]
path=pathlib.Path(args[args.index('--command')+1]);pin=args[args.index('--sha256')+1]
with path.open('rb') as f:raw=f.read(1000001)
if len(raw)>1000000 or hashlib.sha256(raw).hexdigest()!=pin:raise ValueError('command-pin')
plan=json.loads(raw)
def verify_selection():
 for item in plan['interpreterSelections']:
  if str(pathlib.Path(item['selected']).resolve(strict=True))!=item['resolved']:raise ValueError('selected-interpreter-resolution')
  for entry in item['links']:
   p=pathlib.Path(entry['path'])
   if not p.is_symlink() or str(p.readlink())!=entry['target']:raise ValueError('selected-interpreter-link')
verify_selection();primary=None
try:runpy.run_path(plan['guardedLauncher'],run_name='__main__')
except BaseException as e:primary=e
finally:
 try:verify_selection()
 except BaseException as e:
  if primary is None:primary=e
  else:primary.closing_interpreter_custody_failed=True
if primary is not None:raise primary
