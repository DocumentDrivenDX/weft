use weft_postgresql::current_presence::CurrentPresenceSql; fn main(){let _:Option<CurrentPresenceSql>=None;}
