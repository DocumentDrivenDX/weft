from pathlib import Path
import subprocess,os,json
R=Path(__file__).parent;D=R/'feature-off';(D/'src').mkdir(parents=True,exist_ok=True);(D/'Cargo.toml').write_text('''[package]
name="presence-feature-off-probe"
version="0.1.0"
edition="2021"
[workspace]
[dependencies]
weft-postgresql={path="../reconstructed/crates/weft-postgresql"}
[patch.crates-io]
ahash={path="../reconstructed/vendor/ahash"}
''');(D/'Cargo.lock').write_bytes((R/'reconstructed/Cargo.lock').read_bytes());(D/'src/main.rs').write_text('use weft_postgresql::current_presence::CurrentPresenceSql; fn main(){let _:Option<CurrentPresenceSql>=None;}\n');env=dict(os.environ,PATH='/Users/erik/.rustup/toolchains/1.90.0-aarch64-apple-darwin/bin:'+os.environ['PATH'],CARGO_HOME='/private/tmp/weft-toolchain/cargo',CARGO_TARGET_DIR=str(R/'target'));p=subprocess.run(['cargo','check','--offline','--manifest-path',str(D/'Cargo.toml')],env=env,capture_output=True,text=True);(R/'feature-off.log').write_text(p.stdout+p.stderr);result={'status':'passed' if p.returncode!=0 and 'E0432' in p.stderr else 'failed','exit':p.returncode,'requiredDiagnostic':'E0432'};(R/'feature-off.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
