from pathlib import Path
import json,hashlib,shutil
R=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();s=R/'owner-supplement';s.mkdir();path=Path('/private/tmp/weft-presence-transport-final-library-verification-20261016.json');shutil.copyfile(path,s/path.name);report=json.loads(path.read_text());checks=[]
for name,h in report['logs'].items():
 p=Path('/private/tmp')/name;shutil.copyfile(p,s/name);checks.append({'path':str(p),'expected':h,'actual':sha(p.read_bytes()),'passed':sha(p.read_bytes())==h})
for x in json.loads((R/'frozen/manifest.json').read_text())['sourceFiles']:
 p=Path('/private/tmp/weft-presence-lowering-r3-owner-20261016')/x['path'];checks.append({'path':str(p),'expected':x['sha256'],'actual':sha(p.read_bytes()),'passed':sha(p.read_bytes())==x['sha256']})
assert all(c['passed'] for c in checks);(s/'independent-endpoint-verification.json').write_text(json.dumps({'status':'passed','checks':checks,'qualification':'Verified retained log hashes and current owner source endpoint only; owner full library execution was not independently rerun.'},indent=2)+'\n')
p=R/'review.json';r=json.loads(p.read_text());r['independentlyExecuted'][0]['qualification']='41 rendered actual UMF packets exercised, including 35 empty denied results; 25 original refused packets retained as refusal data, not executed transport. Tests synthesize resultRows and never connect to PostgreSQL.'
r['scopeQualifications'][3]='Full updated PostgreSQL library regression was pending in the frozen packet. A later separately retained owner supplement reports 132 unit tests passed in 509.16s, exit 0; its log hash and all twelve current owner source endpoints match. That full campaign was not independently rerun here, and 132 library unit tests are not the original 132 acceptance cases. The earlier 122-test log remains qualified to its earlier prototype.'
r['ownerSupplement']={'file':'owner-supplement/weft-presence-transport-final-library-verification-20261016.json','fullLibraryLog':'owner-supplement/weft-presence-postgresql-library-r3-20261016.log','fullLibraryLogSha256':'b093eec3d99ad6ca4181c541505a34d58e297fd0061531265184d0d24362ec02','independentEndpointVerification':'owner-supplement/independent-endpoint-verification.json'}
r['editorialClarification']={'location':'CONTRACT-013 Error Semantics','finding':False,'interpretation':'Refusal is stage-specific: lower returns no artifact on failure; check returns no transport success report or rows on failure. A later checker refusal cannot retroactively erase a previously issued SQL artifact. Explicit host zero-release and complete cleanup obligations remain in force. Clarifying these stages would remove ambiguity without changing runtime behavior.'}
p.write_text(json.dumps(r,indent=2)+'\n');files={}
for p in R.rglob('*'):
 if not p.is_file() or p==R/'manifest.json':continue
 rel=p.relative_to(R)
 if rel.parts[0] in ['target','reconstructed']:continue
 files[str(rel)]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
(R/'manifest.json').write_text(json.dumps({'version':'review-evidence-manifest/1','reviewSha256':sha((R/'review.json').read_bytes()),'files':dict(sorted(files.items())),'reconstruction':'Exact baseCommit and frozen overlays; repository-inputs.json pins all reconstructed tracked file bytes. Excludes Cargo target binaries and copied node_modules implementations; external closure explicitly non-hermetic.'},indent=2)+'\n');print(json.dumps({'reviewSha256':sha((R/'review.json').read_bytes()),'manifestSha256':sha((R/'manifest.json').read_bytes()),'remainingFindings':0}))
