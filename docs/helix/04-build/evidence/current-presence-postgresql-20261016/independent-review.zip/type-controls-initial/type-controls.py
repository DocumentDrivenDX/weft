from pathlib import Path
import subprocess,os,json,shutil
R=Path(__file__).parent;bins=R/'probe/src/bin';bins.mkdir(exist_ok=True);env=dict(os.environ,PATH='/Users/erik/.rustup/toolchains/1.90.0-aarch64-apple-darwin/bin:'+os.environ['PATH'],CARGO_HOME='/private/tmp/weft-toolchain/cargo',CARGO_TARGET_DIR=str(R/'target'));cases={
 'deserialize':('use weft_postgresql::current_presence::CurrentPresenceSql;fn main(){let _:CurrentPresenceSql=serde_json::from_str("{}").unwrap();}','E0277'),
 'old_context':('fn misuse(x:&weft_core::current_presence::CurrentPresencePreparation){let _=weft_postgresql::current_scalar::lower(x,"{}");} fn main(){}','E0308'),
 'old_to_new':('fn misuse(x:&weft_core::current_query::CurrentQueryOperands){let _=weft_postgresql::current_presence::lower(x,"{}");} fn main(){}','E0308'),
 'borrow_escape':('fn misuse()->weft_postgresql::current_presence::CurrentPresenceSql<\'static>{let raw=std::fs::read_to_string("source.json").unwrap();let p=weft_core::application_lineage::prepare(&raw).unwrap();let c=weft_core::current_presence::prepare(&p).unwrap();weft_postgresql::current_presence::lower(&c,"{}").unwrap()}fn main(){}','E0515')}
# Read the declared operand module name, never assume an unavailable API path.
for name,(src,code) in cases.items():
 (bins/(name+'.rs')).write_text(src+'\n')
results=[]
for name,(_,code) in cases.items():
 proc=subprocess.run(['cargo','check','--offline','--manifest-path',str(R/'probe/Cargo.toml'),'--bin',name],env=env,capture_output=True,text=True);(R/(name+'-compile.log')).write_text(proc.stdout+proc.stderr);results.append({'id':name,'exit':proc.returncode,'requiredDiagnostic':code,'passed':proc.returncode!=0 and code in proc.stderr})
(R/'type-controls.json').write_text(json.dumps({'status':'passed' if all(r['passed'] for r in results) else 'failed','controls':results},indent=2)+'\n');print(results)
