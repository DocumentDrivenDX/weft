from pathlib import Path
r=Path(__file__).parent;p=r/'probe/Cargo.toml';s=p.read_text();root=(r/'reconstructed/Cargo.toml').read_text();patch=root.split('[patch.crates-io]')[1].split('\n[')[0];patch=patch.replace('path = "','path = "../reconstructed/');p.write_text(s+'\n[patch.crates-io]'+patch+'\n');(r/'probe/Cargo.lock').write_bytes((r/'reconstructed/Cargo.lock').read_bytes())
