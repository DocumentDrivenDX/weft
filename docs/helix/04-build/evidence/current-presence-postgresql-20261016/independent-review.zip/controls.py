from pathlib import Path
import json,copy,subprocess,hashlib
R=Path(__file__).parent;J=lambda x:json.dumps(x,separators=(',',':'),ensure_ascii=False);clone=copy.deepcopy
cases=json.loads((R/'reconstructed/tests/current-query-presence/fixtures/actual-atomic-transport.json').read_text())['cases'];requests={c['id']:c['request'] for c in cases};emitted=json.loads((R/'emitted.json').read_text());base=emitted[0]
p=subprocess.Popen([str(R/'target/debug/presence-transport-review-probe')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=open(R/'probe-runtime.stderr','w'),text=True);records=[]
def run(id,arg,expect):
 p.stdin.write(J(arg)+'\n');p.stdin.flush();out=json.loads(p.stdout.readline());ok=out['status']==expect;records.append({'id':id,'passed':ok,'expected':expect,'input':arg,'output':out});return out
arg={'request':requests[base['id']],'binding':base['binding'],'frame':base['frame']}
for e in emitted:run('original:'+e['id'],{'request':requests[e['id']],'binding':e['binding'],'frame':e['frame']},'passed')
def setpath(x,path,value):
 for k in path[:-1]:x=x[k]
 x[path[-1]]=value
for field in ['version','sourceRequestSha256','preparationSha256','sourceBindingSha256']:
 a=clone(arg);a.pop('frame');a['binding'][field]='0'*64;run('binding:'+field,a,'refused')
for field in ['capabilities','cells']:
 a=clone(arg);a.pop('frame');a['binding'][field]=[];run('binding:empty:'+field,a,'refused')
for path in [['relation'],['header'],['header','policy'],['header','protection'],['header','domains',0],['header','columns',0],['header','columns',0,'field'],['header','columns',0,'storageTransform'],['cells',0],['cells',0,'field']]:
 a=clone(arg);a.pop('frame');v=a['binding']
 for k in path:v=v[k]
 v['unknown']=True;run('binding:extra:'+str(path),a,'refused')
for part in ['schema','table','eligibleColumn','rowKeyColumn']:
 for value,expect in [('', 'refused'),('x\0y','refused'),('é'*31+'x','passed'),('é'*32,'refused'),('x"; DROP TABLE anything; --','passed')]:
  a=clone(arg);a.pop('frame');a['binding']['relation'][part]=value;r=run('identifier:'+part+':'+repr(value),a,expect)
  if expect=='passed':assert '"'+value.replace('"','""')+'"' in r['artifact']['sql']
for path,value in [(['cells',0,'column'],'eligible'),(['cells',0,'column'],'private_key'),(['header','domains'],[]),(['header','domains'],arg['binding']['header']['domains']*2),(['header','columns',0,'storageTransform'],None),(['header','columns',0,'valueProfile'],'unknown'),(['cells',0,'field','revision'],'stale')]:
 a=clone(arg);a.pop('frame');setpath(a['binding'],path,value);run('binding:negative:'+str(path)+':'+str(value),a,'refused')
for field in ['version','sourceRequestSha256','preparationSha256','materializationBindingSha256','compiledArtifactSha256']:
 a=clone(arg);a['frame'][field]='0'*64;run('frame:pin:'+field,a,'refused')
for v in ['01','+1','1.0','2','-1',' 1','١']:
 a=clone(arg);a['frame']['expectedRowCount']=v;run('count:'+v,a,'refused')
for where in ['frame','row','header','tuple','tuple-row']:
 a=clone(arg);v=a['frame']
 if where=='row':v=v['rows'][0]
 if where=='header':v=v['header']
 if where in ['tuple','tuple-row']:
  t=json.loads(v['resultRows'][0][-1]);(t if where=='tuple' else t['rows'][0])['extra']=True;v['resultRows'][0][-1]=J(t)
 else:v['extra']=True
 run('extra:'+where,a,'refused')
cell={'disposition':'original','value':{'string':'opaque-token'}}
malformed=[None,[],{},'null',{'disposition':'original'},dict(cell,extra=1),{'disposition':'absent','value':None},{'disposition':'withheld','value':None},{'disposition':'original','value':1},{'disposition':'unknown'}, {'disposition':'transformed','value':None}]
transform={'disposition':'transformed','value':None,'selection':{'ruleIndex':0,'disclosureIndex':1},'outputDomain':{'documentId':'domain','moduleId':'m','elementId':'token'},'transform':{'id':'presentation-null','version':'1'}}
for path,value in [(['selection','ruleIndex'],-1),(['selection','ruleIndex'],4096),(['selection','disclosureIndex'],1.5),(['transform','id'],''),(['transform','version'],'x\0y'),(['outputDomain','documentId'],'foreign'),(['outputDomain','moduleId'],''),(['valueProfile'],'unknown')]:
 t=clone(transform);setpath(t,path,value);malformed.append(t)
for i,c in enumerate(malformed):
 a=clone(arg);raw=J(c);a['frame']['rows'][0]['cells'][0]=raw;a['frame']['resultRows'][0][0]=raw;run('malformed-cell:'+str(i),a,'refused')
# Byte identity, SQL native null, missing row, duplicate row, private key mismatch.
for name in ['whitespace','json-null','native-null','drop-row','duplicate-row','wrong-key','wrong-scan','wrong-private-version']:
 a=clone(arg);f=a['frame']
 if name=='whitespace':f['resultRows'][0][0]=' '+f['resultRows'][0][0]
 elif name=='json-null':f['resultRows'][0][0]='null'
 elif name=='native-null':f['resultRows'][0][0]=None
 elif name=='drop-row':f['resultRows']=[]
 elif name=='duplicate-row':f['resultRows'].append(clone(f['resultRows'][0]))
 else:
  t=json.loads(f['resultRows'][0][-1]);
  if name=='wrong-key':t['rows'][0]['key']='unknown'
  if name=='wrong-scan':t['rows'][0]['scan']='s1'
  if name=='wrong-private-version':t['version']='old'
  f['resultRows'][0][-1]=J(t)
 run(name,a,'refused')
# True mixed bag with duplicate public values but different private identities; repeated projections.
a=clone(arg);a['request']['sql']='SELECT r.token AS first, r.token AS second FROM Resource r';a['repin']=True
values=[cell,{'disposition':'original','value':None},{'disposition':'absent'},{'disposition':'withheld'},transform,cell]
rows=[{'key':'k'+str(i),'cells':[J(v)]} for i,v in enumerate(values)];a['frame']['rows']=rows;a['frame']['expectedRowCount']=str(len(rows));a['frame']['resultRows']=[[r['cells'][0],r['cells'][0],J({'version':'weft.stage-row-tuple/0.1-candidate','rows':[{'scan':'s0','key':r['key']}]})] for r in reversed(rows)]
r=run('mixed-bag-repeated-projections',a,'passed');assert [c['headerColumn'] for c in r['artifact']['resultColumns']]==[0,0]
b=clone(a);b['frame']['resultRows'][0][1]=J({'disposition':'withheld'});run('repeated-position-tamper',b,'refused')
b=clone(a);b['frame']['resultRows'][0]=b['frame']['resultRows'][1];run('bag-duplicate-key-replaces-distinct',b,'refused')
b=clone(a);b['frame']['rows'][0]['key']=b['frame']['rows'][1]['key'];run('expected-duplicate-key',b,'refused')
b=clone(a);b['frame']['rows'][-1]['cells'][0]='null';b['frame']['resultRows']=[];run('malformed-late-expected-with-empty-results',b,'refused')
for key,expect in [('é'*128,'passed'),('é'*128+'a','refused'),('','refused'),('a\0b','refused')]:
 b=clone(arg);b['frame']['rows'][0]['key']=key;t=json.loads(b['frame']['resultRows'][0][-1]);t['rows'][0]['key']=key;b['frame']['resultRows'][0][-1]=J(t);run('key-utf8:'+repr(key),b,expect)
for n,expect in [(4096,'passed'),(4097,'refused')]:
 b=clone(arg);b['frame']['rows']=[{'key':'k'+str(i),'cells':[J(cell)]} for i in range(n)];b['frame']['resultRows']=[[J(cell),J({'version':'weft.stage-row-tuple/0.1-candidate','rows':[{'scan':'s0','key':'k'+str(i)}]})] for i in range(n)];b['frame']['expectedRowCount']=str(n);run('rows:'+str(n),b,expect)
for sql in ['SELECT r.token FROM Resource r WHERE FALSE','SELECT r.token FROM Resource r LIMIT 0','SELECT r.* FROM Resource r','SELECT r.token FROM Resource r ORDER BY r.token']:
 b=clone(arg);b['request']['sql']=sql;b['repin']=True;run('parent-restricted:'+sql,b,'refused')
# Whole-UMF validation is explicitly outside transport: record, do not mistake acceptance for authority.
b=clone(arg);b['frame']['rows'][0]['cells'][0]=J({'disposition':'original','value':{'unknownLiteral':True}});b['frame']['resultRows'][0][0]=b['frame']['rows'][0]['cells'][0];run('scope-only-unknown-CoreLiteral-shape',b,'passed')
b=clone(arg);t=clone(transform);t['selection']={'ruleIndex':7,'disclosureIndex':7};b['frame']['rows'][0]['cells'][0]=J(t);b['frame']['resultRows'][0][0]=J(t);run('scope-only-not-actual-policy-selection',b,'passed')
p.stdin.close();p.wait();out={'status':'passed' if all(r['passed'] for r in records) else 'failed','count':len(records),'checks':records,'scope':'Independent finite Rust transport controls. Mock resultRows are transport data, not native DB execution. Scope-only positive controls demonstrate mandatory whole-UMF semantic validation remains external.'};(R/'independent-controls.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');print(J({'status':out['status'],'count':len(records),'failures':[{k:v for k,v in r.items() if k!='input'} for r in records if not r['passed']]}));assert out['status']=='passed'
