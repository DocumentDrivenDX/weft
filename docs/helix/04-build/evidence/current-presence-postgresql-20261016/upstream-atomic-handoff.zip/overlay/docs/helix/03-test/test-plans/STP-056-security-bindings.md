---
ddx:
  id: STP-056
  type: story-test-plan
  activity: test
  status: draft
  authoring:
    home: repo
  links:
    - id: US-056
      kind: informed_by
    - id: TD-056
      kind: informed_by
    - id: SD-008
      kind: informed_by
---

# STP-056: security-bindings

## Story Reference

**User Story:** [[US-056-security-bindings]] **Technical Design:** [[TD-056-security-bindings]]
**Solution Design:** [[SD-008]] **Project Test Plan:** TP-001.

## Scope and Objective

All P0 criteria in this story must have exercising evidence. The machine-readable
case inventory is `../security/cases.json`; plans are not passing executions.
Spikes supply qualified feasibility evidence only. No deferred or missing native
case can be represented as a pass.

## Acceptance Criteria Test Mapping

| AC ID | Named tests | Asserted behavior | Citation | Primary layer |
| --- | --- | --- | --- | --- |
| US-056-AC1 | pg-raw.B01, pg-raw.B02, pg-raw.B03, pg-raw.B13 | Selected native ordinary identity sees exact oracle resource IDs; active/inactive/sibling/no-owner cases. | `@covers US-056-AC1` required in exercising test | native integration |
| US-056-AC2 | truss.B01, truss.B02, truss.B03, truss.B13 | Selected native ordinary identity sees exact oracle resource IDs; active/inactive/sibling/no-owner cases. | `@covers US-056-AC2` required in exercising test | native integration |
| US-056-AC3 | delta-raw.B01, delta-raw.B02, delta-raw.B03, delta-raw.B13 | Selected native ordinary identity sees exact oracle resource IDs; active/inactive/sibling/no-owner cases. | `@covers US-056-AC3` required in exercising test | native integration |
| US-056-AC4 | ashlar.B01, ashlar.B02, ashlar.B03, ashlar.B13 | Selected native ordinary identity sees exact oracle resource IDs; active/inactive/sibling/no-owner cases. | `@covers US-056-AC4` required in exercising test | native integration |
| US-056-AC5 | pg-raw.B04, pg-raw.B05, pg-raw.B06, pg-raw.B14, truss.B04, truss.B05, truss.B06, truss.B14, delta-raw.B04, delta-raw.B05, delta-raw.B06, delta-raw.B14, ashlar.B04, ashlar.B05, ashlar.B06, ashlar.B14 | Direct tables, child homes, property bags, raw retained bytes, files and alternate query endpoints cannot bypass admitted policy. | `@covers US-056-AC5` required in exercising test | native integration |
| US-056-AC6 | pg-raw.B07, pg-raw.B08, pg-raw.P01, pg-raw.P02, pg-raw.P03, pg-raw.P08, truss.B07, truss.B08, delta-raw.B07, delta-raw.B08, delta-raw.P02, delta-raw.P03, delta-raw.P08, ashlar.B07, ashlar.B08 | Original null, absence, redaction and transform differ; forbidden property never escapes bag/retained carrier. P-cases (2026-10-14): catalog transforms, disclosure-profile query use, column-privilege withhold and tokenization stand-ins disclose faithfully. | `@covers US-056-AC6` required in exercising test | native integration |
| US-056-AC7 | pg-raw.B09, pg-raw.B15, pg-raw.P05, pg-raw.P07, truss.B09, truss.B15, delta-raw.B09, delta-raw.B15, delta-raw.P01, delta-raw.P07, ashlar.B09, ashlar.B15 | Unsupported path/mask/history/composition cannot install report-mode weakening; prior protected profile remains. P-cases (2026-10-14): unqualified mask carriers and native masking/ABAC rules are refused or archived without weakening. | `@covers US-056-AC7` required in exercising test | native integration |
| US-056-AC8 | pg-raw.B10, truss.B10, delta-raw.B10, ashlar.B10 | Authorization can consult hidden Assignment facts; ordinary direct/list/count/diagnostic paths disclose none. | `@covers US-056-AC8` required in exercising test | native integration |
| US-056-AC9 | pg-raw.B11, truss.B11, delta-raw.B11, ashlar.B11 | Change owner/grant/membership/routine/policy/column mapping after qualification; admission detects and refuses. | `@covers US-056-AC9` required in exercising test | native integration |
| US-056-AC10 | pg-raw.B12, pg-raw.B16, truss.B12, truss.B16, delta-raw.B12, delta-raw.B16, ashlar.B12, ashlar.B16 | Pin exact engine/build/model/policy/mapping/source/actual-role and per-case outcomes; missing or fabricated receipt refuses. | `@covers US-056-AC10` required in exercising test | native integration |

## Executable Proof

Run `bun docs/helix/02-design/spikes/security/acceptance.ts` for the release gate.
It must reject missing commands, nonpassing evidence and incomplete coverage.
Per-backend procedures in `../security/` specify original-role execution and
scenario expansions. Named cases currently without commands are implementation
obligations, explicitly not executable proof. Formal and native spike receipts
are under `../../04-build/evidence/security/` with scope limits.

Gate arithmetic (2026-10-14): `cases.json` holds 145 required cases: the
original 132 plus 13 field-protection P-cases added by owner direction (seven
`pg-raw.P*`, six `delta-raw.P*`), all `not-run`. The 26 cases accepted at the
26/132 checkpoint keep their status; nothing is retired or promoted, so the
current state is 26 accepted of 145 required with 119 open (118 `not-run`,
pg-raw.B10 `counterexample-found`). The committed `acceptance.json` receipt
predates the amended plan digest and must be re-executed by the next slice that
runs the gate; an old receipt never substitutes for execution (CONTRACT-063).

### Field-protection amendment — 2026-10-14

Owner direction (2026-10-14) applies proposal P-F of the
[field-protection plan](../../04-build/security-field-protection-plan.md),
governed by FEAT-008 SEC-13..15 and CONTRACT-062/063 §Field protection. Rules:

- New `P` case IDs exist only for obligations no existing required case owns.
  Obligations an existing ID already owns are executed as procedural expansions
  of that ID (B04/B05/B14 privileged bypass and direct access, B07
  null/absence/withheld/transformed distinctness, B08 weakened-barrier and
  query-use controls, L08 historical reads, L10 propagation). The plan's slice
  labels pg-raw.P06, delta-raw.P05 and delta-raw.P06 are therefore not case
  IDs; `pg-raw.md` and `delta-raw.md` record where each executes.
- The `P` prefix names cases only; proposals P-A..P-G are plan items.
- Every P-case is `required: true`, `status: not-run`, `command: null` until a
  reviewed runner, independent oracle and implementation sources are bound.
  Truss and Ashlar gain no cases; raw evidence closes raw cases only.
- Prerequisites: PostgreSQL 18.x disposable container with the exact minor,
  image digest and client build pinned at execution (17.9 fixtures are not
  PG 18 evidence); Unity Catalog workspace with two independent ordinary
  identities, an isolated catalog/schema, pinned DBR/warehouse versions and
  compute tuple, and the SHA-256 of the cloud documentation copy read at
  execution (AWS, Azure and GCP copies differ).

| Case | AC | Owns |
| --- | --- | --- |
| pg-raw.P01 | US-056-AC6 | Column-privilege withhold; 42501 is a statement-level refusal, not a `withheld` cell; no table-level SELECT |
| pg-raw.P02 | US-056-AC6 | Barrier-view catalog transforms match the independent oracle per actor |
| pg-raw.P03 | US-056-AC6 | Disclosure-profile query-use admissibility versus native operator behavior |
| pg-raw.P04 | US-057-AC1 | Mask write-back refusal; absent UPDATE as direct-SQL control; `RETURNING old/new` pre-image control |
| pg-raw.P05 | US-056-AC7 | PG 18 virtual generated column as mask carrier qualified or refused |
| pg-raw.P07 | US-056-AC7 | Anonymizer `SECURITY LABEL` rules archived, uninterpreted, `unverified` |
| pg-raw.P08 | US-056-AC6 | Tokenization stand-in: token disclosure, unreachable detokenize, declared propagation |
| delta-raw.P01 | US-056-AC7 | View-based withhold; NULL-mask carrier refused |
| delta-raw.P02 | US-056-AC6 | Column-mask UDF catalog transforms match the oracle per actor |
| delta-raw.P03 | US-056-AC6 | Masked-column operator behavior versus disclosure profile (Q6) |
| delta-raw.P04 | US-057-AC1 | Native write surface `unsupported`; invisible-row INSERT witness |
| delta-raw.P07 | US-056-AC7 | ABAC policy archive preserved; `EXCEPT` principals inventoried |
| delta-raw.P08 | US-056-AC6 | Tokenization stand-in with time-travel/clone/share propagation observed |

Semantic cases S13–S25 named in the plan belong to STP-079/US-079 and are not
allocated here; their allocation remains an open M0 item.

## Data and Setup

Use Clients/Projects/Staff ownership/assignment fixtures; duplicate labels,
reversed endpoints, null/absence, multiple owners, private bags, historical owner
changes and complete/incomplete fact cuts. Disposable native installations and
independent expected outcomes are mandatory. Do not reuse compiler predicates
as the expected-result oracle.

## Edge Cases and Failure Modes

Unknown security meaning refuses interpretation while preserving source.
Collection uncertainty refuses before output. False permits add no masks;
protected output without disposition refuses. Native inventory/authority drift
invalidates prior evidence. Old snapshots cannot adopt new authority generations.

## Build Handoff

1. Implement declared typed contract and independent oracle tests.
2. Bind exact native profiles and execute positive/bypass controls.
3. Exercise lifecycle barriers and publish source-qualified evidence.
4. Require 100% P0 cases and stable AC citations before story acceptance.

Done requires actual assertions, matching command/source receipts and no skipped
required cases. Compiler/native profile gaps remain open rather than assumed.

## Ordered owner result-declaration controls

SPIKE-010 and the actual private Weft requirement inventory govern this next
component implementation. All controls below are P0. The pure direct-field
checker now has partial component execution evidence recorded below; the full
controls, including runtime/native observations, remain open. They supplement
B07/B08/B09 and US-056-AC6/AC7; they do
not replace or accept any of the original required backend cases.

Use actual source-admitted public compiler contexts and independently authored
expected declarations. Invoke the pure owner declaration checker in
the registration callback; the final public compiler response must still refuse
lowering. A successful declaration check never grants execution or publication.

| Control | Expected observation |
| --- | --- |
| R01 ordered aliases | Two aliases of one source field produce two distinct output positions/names, despite one deduplicated projection dependency. Swapped/missing/extra columns refuse. |
| R02 revision and namespace | Exact document/revision/module/element lineage and model domain pass. Same local field ID in another revision/document/module, or a scalar-family replacement, refuses. |
| R03 protected defaults | A protected projected field with no conservative disclosed outcome refuses; no invented Original outcome. Unprotected default retains Original. |
| R04 complete permit union | Every scoped permit disclosure is retained, including false-condition sources. Omitting a late mask or using another target/action's rule refuses declaration correspondence. Runtime false permits still contribute no mask. |
| R05 exact transform classes | Numerically equivalent exact token spellings coalesce under the admitted domain; different values, output fields, domains or versions remain distinct. Floating-point coercion cannot identify classes. |
| R06 all class sources | A shared transform outcome retains every exact rule/target/field source in its class. Missing, duplicate, unrelated or misqualified sources refuse. |
| R07 distinct transformations | All conservative classes appear in the declaration; conflicting simultaneously true classes still refuse runtime disclosure. The declaration cannot pick one convenient class. |
| R08 withheld precedence | Withheld remains declared alongside potential transforms/original. A native row with active Withheld must disclose no original/transform value even when those outcomes are listed. |
| R09 null and absence | No missing column/property or SQL NULL can fabricate Absent/Withheld. An absent outcome needs independently admitted presence semantics; unsupported presence selections refuse. Typed literal null stays distinct from absence metadata. |
| R10 aggregate requirements | COUNT and SUM remain explicit owner outputs with every scan/action/operator obligation. The initial direct-field checker refuses unresolved aggregate contracts; no silent omission or inherited source-field mask/domain. |
| R11 bounded issuance | Excess outcome/source counts, identifier bytes, work or literal-normalization budgets refuse before checked output issuance; no accepted prefix. |
| R12 ownership and freshness | Caller-constructed declarations cannot replace owner requirements. Changed source/profile/binding and attempted context/inventory substitution refuse before checker dispatch or fail external compilation. |

Retain separate evidence for declaration correspondence and runtime/native cells.
R08/R09 require actual ordinary-role native observations before their B07/B08
criteria pass. Model envelopes and a pure checker cannot prove installed masks,
absence codecs, current authority, private-fact completeness or final release.

### Astra implementation review refinements

The owner checker must retain the output's actual scan occurrence internally:
two self-join outputs can have identical revision-qualified sourceFields yet
different policy evaluation scopes. Transformed value domains reference the
transform's outputField, which may differ from the projected input field.
Normalized numeric coefficients alone cannot identify transforms across domains:
integer 1 and decimal 0.1 at scale one can share a coefficient. R05 must exercise
that collision while preserving exact output-domain identity.

Only transformed wire outcomes currently carry dispositionSources. Original and
Withheld provenance must remain in the complete owner rule inventory; the checker
must not invent undeclared wire members. R09 must retain a null constant as
Transformed(null), never turn normalized-literal None into Absent or Withheld.
R11 must test the actual 256-outcome wire limit: 256 distinct scoped transforms
plus conservative unprotected Original yields 257 and must refuse atomically.
The checker requires exact semantic outcome coverage, rejecting extra classes,
duplicate classes/IDs and omissions. One unsupported expression, including an
unresolved aggregate beside valid direct-field columns, blocks complete checking.

Conservative Original remains required for unprotected defaults even when every
authored permit transforms the field. Protected Original needs an explicit scoped
permit. A declared Withheld never removes potential transform classes: it may be
false for another row. Validate closed contract version/encoding and collection/
text limits before normalization, then charge aggregate literal/provenance/output
work and bytes so individually bounded masks cannot amplify retained memory.

### Partial component execution — 2026-10-10

Actual Rust owner verification passes 63 library and 55 security-admission tests.
The direct-field checker exercises ordered repeated aliases and source/domain
revision mutations; complete false-permit transform provenance; equivalent exact
integer spellings and distinct values; Withheld alongside retained transform
classes; optional Original presence refusal; the 256/257-outcome boundary; and
COUNT refusal both alone and after a valid field. Short exponent tokens are
charged for normalized numeric payload. Isolated wrong literal, unknown element
and Record-domain mutations require LOWERING-UNSUPPORTED while source custody
checks retain their diagnostics. The public compiler still refuses lowering.

These observations partially cover R01/R02/R04–R12; they do not close the table
or any backend case. Self-join scope distinctions, explicit integer/decimal
coefficient collisions, null-transform controls, protected missing outcomes and
full collection/budget mutations still need dedicated correspondence cases.
Runtime presence/cells, active-mask behavior and ordinary-role native release
remain unqualified. Astra's scoped installed-source review retains eleven
reviewed artifact pins and audits all 408 admission pins; it explicitly attributes
the Rust execution to the parent rather than claiming independent execution.
Receipt: `owner-result-checker-astra-review.json`.

### Protected default and null transformation control — 2026-10-10

The source-admitted owner regression now exercises a protected optional salary
with no disclosure and with an explicit constant null disclosure. Neither admits
an invented Original result. The explicit null declaration passes as
Transformed(null); replacing it with Absent or Withheld refuses the exact
LOWERING-UNSUPPORTED diagnostic. Both configurations reach the actual owner
callback and finish with the public backend-required refusal. Actual owner
verification passes 63 library and 56 security-admission tests. This adds
component observations for R03/R09, not runtime/native presence qualification.
Dedicated self-join scope and integer/decimal coefficient-collision controls
still remain, along with complete runtime/physical/backend obligations.

### Runtime batch parser foundation — 2026-10-10

The private owner JSON reader now accepts explicit byte/depth/value-node bounds
for a future cell consumer. Three actual Rust tests verify UTF8 and whitespace
byte accounting, root-depth-one and scalar/container counts, exact limits and
one-over refusal, nested escaped duplicate names and malformed JSON. Ordinary
request parsing preserves its original limits. Verification passes 66 library
and 56 security-admission tests. These are parser component observations only.
Production cell limits (32MiB/depth64/1000000 nodes), rows/domain/hash/constant
checks and atomic selection/release still require an actual consumer and dedicated
end-to-end tests. Raw-entry allocation is bounded by the input byte limit rather
than a constant-memory bound. No original backend case closes.

### Pure cell correspondence component — 2026-10-10

Actual owner-context cell checking now rechecks declaration/source correspondence,
retained exact contract bytes/hash and full structural equality before accepting
a closed batch envelope. Both JSON inputs use 32MiB/depth64/1000000-node limits,
rows cap at4096 and exact ordered column width. Tests reach source-admitted
contexts and exercise valid/empty batches, wrong/missing/extra columns, unknown
outcome and wrong tags, missing/extra value members, null/domain mismatch,
contract byte/hash/object mismatch, nested duplicate contract/batch keys,
equivalent exact numeric tokens, distinct valid constants, refined signed64
overflow, value on Withheld and Transformed(null) versus another valid value.
Owner verification passes 66 library and 57 security-admission tests.

This is a pure unit-returning correspondence method, not authorized policy
selection or a checked/releasable batch. Production boundary tests at32MiB,
depth64,1000000 nodes and4096 rows, complete aggregate work exhaustion, native
codec/source correspondence, ordinary-role mask evaluation/current authority and
atomic final release remain required. The method does not admit Scalar result
domains outside the direct-field owner slice. No backend case closes.

Astra's cell-budget feedback is implemented: runtime literal/normalized-payload
ledger exhaustion returns WFT-LIMIT in result phase, preserving declaration
coverage errors before cell work. The actual two-column batch test admits one
and three rows of independently valid one-million-byte strings, then refuses
four rows (eight cells) on the aggregate sixteen-million-byte ledger while JSON
remains below32MiB. Both smaller whole batches pass; refusal returns no partial
result. Production exact byte/depth/node/row boundaries remain separate tests.

### Original native string-cell inspection link — 2026-10-10

The PostgreSQL17.9 original-use probe now builds an experimental owner inspection
example, freezing selected crate/vendor/spec/fixture/config and installed Rust
bin/lib inputs before Cargo and verifying them afterward before capturing the
produced binary. Cargo registry/dependency artifact cache, platform linker/SDK and environment
remain explicit trusted fixture premises; this is not hermetic build attestation.
Exact selected file inventory and all four Cargo config-presence states are
rechecked after build, before native acquisition and at the final check.

For predicate/order/join populated and empty samples, an ordinary SCRAM-role
query captures binary psql stdout, including trailing LF. Exact bytes/hash and
strict UTF8 decoded text are retained. The bridge receives that exact text and
a fresh admitted compiler request, derives ordered Original direct-field
declarations from the owner outputs, encodes string cells and calls the actual
cell checker. It returns counts/hashes and releasedRows0; compilation still
refuses backend activation. Null and wrong-width mutations require parsed exact
WFT-SECURITY-CELL-INSPECTION/input diagnostics and empty stdout.

This links six original fixture samples to string-cell interpretation. It does
not admit protected projections, numeric/aggregate native codecs, selection
truth, all-key/fact populations, coherent live cuts or guarded release. It does
not close B07/B08/B09 or any original backend case.

### Conditional owner cell selection — 2026-10-10

The owner now conditionally checks supplied per-row scan/action/rule truths
against its complete source-bound inventory and existing composition fold.
Each required scan/action must Permit. Ordered cells then match the selected
Original/Withheld or exact constant transform for that output's actual scan.
Tests run actual admitted single-scan and self-join contexts: raw and masked
positives, Withheld precedence even with competing masks, wrong potential
outcomes, unknown/failed require/no permit/forbid/conflicting masks, missing and
foreign scope entries, and swapping distinct self-join truth scopes while field
identities and cell domains still match. Additional isolated controls cover a
failing admitted secondary original-use action while primary actions Permit, a
valid first row followed by a failing second-row fold, and selection-ledger
exhaustion after valid declaration and 4096 small-cell checks. Owner verification passes66 library
and58 security-admission tests.

These truths remain caller-supplied simulation inputs and can include assignments
that actual source conditions cannot jointly realize. The control is conditional
fold/selection correspondence, not condition evaluation, authenticated facts,
row provenance or permission to release. Empty batches grant no query permission.
Original-action query-wide guards, actual condition/correlation evaluation,
original-value correspondence/current authority/native final release remain
required. The ledger charges ontology bytes before each composition, supplied
rule IDs, initial field references and selected transform literals/normalized
payloads. Other policy/model inspection and active-mask normalization remain
outside that ledger; composition CPU/allocation is not fully bounded. No case closes.


### Conditional evaluated owner facts — 2026-10-10

An actual owner-context path now evaluates every required scan/action/rule from
one explicit simulated cut rather than accepting caller truth assignments.
Rows use a closed versioned scan-to-Fact envelope; exact owner scan/target
inventory, finite bounds, source conditions, declared complete dependencies and
same-identity field/absence coherence are checked. Original cells additionally
match their scan fact's exact normalized field value and declared field coverage.
This connects the source-expression and cell-selection components for R01/R02,
R04/R05/R07/R11/R12 and B07/B08/B09 without qualifying native fact authority.

Actual Rust controls cover single scans and self-joins, Original and conditionally
masked outputs, Project/Staff membership, field-value substitution, inactive or
missing associations, incomplete coverage even for empty rows, stale caller
generation, work exhaustion, missing fields, duplicate population identity,
missing/foreign scans, later-row same-identity inconsistency, distinct-scan fact
swaps and valid repeated bag rows. Owner evidence passes66 library and60
security-admission tests. Conditions now evaluate against the supplied facts;
trust/coverage/generation are still caller assertions. This does not establish
native query predicates/join provenance, complete result enumeration, authenticated
facts, query-wide empty-result original-action admission, current native authority
or guarded release. No original backend acceptance case closes.

Astra feedback adds a separate pre-clone metadata ledger for generated truth-map
rule/action/scan IDs. An actual admitted129-rule fixture passes512 repeated fact
rows, then1024 valid small rows refuse that ledger at WFT-SECURITY-EVALUATION/model
before the downstream selection identifier ledger. Declaration/cell checks pass
both inputs. Additional controls isolate missing projected Original values and
coverage, normalized-equivalent versus conflicting scoped/population Resource
assignments, and identical versus differing subject-population assignments.


### Captured native fact correspondence — 2026-10-10

A separate experimental `security_fact_inspection` owner executable consumes
closed compile-request/native-row/cut/scoped-fact texts and calls the actual
evaluated-fact owner API. It emits only hashes/counts/actual scan identities and
releasedRows0. It has no connection, installation, checked batch or release.
The native producer is tools/security/pg-owner-fact-selection.py; retained evidence
is pg-owner-fact-selection.json. It creates an isolated PostgreSQL17.9 raw fixture,
captures privileged complete declared fact populations and ordinary TCP SCRAM
RLS string rows for Alice/Bob single-scan, Cartesian self-join with distinct
scan values and empty queries.
Every declared natural Key matches the independent native mapping. Staff,
Project and Resource census plus Ownership/Assignment tuples match the authored
fixture; exact native bytes and passed cut/row texts are retained. The owner
evaluates source membership and checks normalized Original values against these
captured facts. Each actual output scan is checked against the retained report.

Controls refuse stale/incomplete cuts, inactive membership and substituted
Original values, with exact code/phase and empty stdout. Empty batches still
require complete dependencies and grant no query permission. This adds native
fixture evidence for partial R01/R02/R04/R11/R12 and B07/B08/B09 correspondence,
not a completed backend case. The privileged fact reader is an excluded assessor;
caller trust/generation/coverage and fixed model/native mappings remain premises.
Facts and rows use separate connections: equal before/after native fact bytes
are fixture evidence, not shared MVCC snapshot or general anti-ABA proof. No
production authenticated issuer/census, compatible authority/revocation protocol,
native compiler refinement, new WASM parity or guarded release is qualified.
Selected build inputs/config presence are frozen before Cargo and rechecked;
Cargo dependency cache, platform linker/SDK and environment remain trusted build
premises, not a hermetic-build proof.

Astra review found and independently reproduced positional-array acceptance in
both inspection envelopes and the new nested fact carriers. Both examples now
require object roots. The new evaluated-fact path requires object Cut/ScopedRows,
Fact/FieldValue/Coverage and qualified reference carriers before typed serde
conversion;11 actual owner-context carrier mutations refuse. Legacy pure
simulate_json remains separately scoped. Native producer controls cover the
same nested grammar plus outer example carrier, rather than assuming serde
`deny_unknown_fields` forbids positional sequences. Source execution now uses
helper/plan/oracle/closure bytes frozen before exec and frozen fixture SQL, with
exact producer location and selected build-input guards. Native salary capture
retains JSON kind and exact token, matches authored typed fixture facts and
refuses a transactionally substituted JSON string source before owner dispatch.
Distinct self-join pairs exercise swapped scan facts against unchanged native
row bytes. These controls improve wire/source/correspondence evidence without
promoting any original backend case.


### Caller planner diagnostics — original B10 remains open

The pg-private-diagnostics producer now tests ordinary SCRAM caller-enabled
planner/parse/rewrite stderr under the deny-first routine candidate. Actual
private relation OIDs and plan estimate vectors remain observable despite catalog
ACL denial. Unrelated private population changes preserve authorized rows but
alter traces. Final94 observations include guarded exact two-world trace equality,
nonvacuous outer logging, individual setting weakening, restored caller settings
and independent wrapper body/owner/ACL/proconfig inventory. Reviewed helper plan/
oracle/closure and SQL execute from captured bytes.

Future B10 qualification must additionally cover prepared/cached guard mutation,
all reachable observation paths and settings/body drift through actual admission.
See [design annex](../../02-design/spikes/security/pg-planner-observation-v0.1.md).
This is native spike evidence; no original acceptance case is promoted.


## Original-layout native graph witness — 2026-10-10

For US-056-AC2/AC5, execute `python3 tools/security/truss-native-membership-probe.py`
from the repository root with disposable fixture access. The exact original
Truss0.16 owner export and shared independently authored raw membership oracle
are mandatory inputs. TD-056 defines the fixed synthetic mapping and excluded
owner boundary; no original case status is promoted by this component.

Required controls compare complete actor rows and native typed identities;
multiple owners must not duplicate Resources. Inactive assignment, sibling
Client, no owner, wrong relationship decoys and outsider remain denied. Direct
bag/retained/edge reads, mutation and owner-role transition must return42501
without rows. A reversed edge must fail23503 specifically at the endpoint FK,
with independently checked existing objects and absent index collision.
Individually erasing active, ownership-rel, assignment-rel and root-type guards
must expose the recorded counterexamples; restoration must recover every actor's
oracle rows and Resource-only direct RLS types. Copied executable, extra arguments
and wrong working directory must refuse before acquisition. Freeze inputs before
effects, retain SQLSTATE/output/diagnostics, verify source stability and clean up
only the UUID-labelled owned fixture.

The retained final run has110 observations/51 transcripts; three separate custody
controls pass. Prior failed and superseded runs remain diagnostic history with
exact attempt source snapshots. Required follow-on backend tests replace fixture
source enums/field IDs/storage IDs with authentic accepted model/property/key
custody and actual Weft lowering, then exercise missing/ambiguous Staff refusal,
full reachable native inventory, diagnostics and current-authority publication.
No fixed overlay can satisfy those remaining acceptance obligations.


### Unique Staff binding controls

The expanded original-layout producer retains217 native observations. In
addition to the prior membership/bypass matrix, missing or duplicate Staff login
bindings must return42501 without output on evaluated projection and count,
for both nonempty and genuinely empty Resource collections. A valid bound
principal with no Resources must instead return successful empty. Restore every
original actor after each changed world. A matching login on a foreign native
type must not count as Staff. Direct helper execution must remain denied.

Use real ordinary native login `true` to distinguish Boolean JSON `true` from
string JSON `"true"`; only the string may bind. Erase cardinality, projection
preflight and JSON string guards separately to record their failure witnesses,
then restore the original behaviors. Retain outer false-filter/LIMIT0 controls
as unevaluated/no-output observations, never admission or refusal evidence.

Four conditional formal laws retain12 exact SMT assertions; independently replay
all expected solver outcomes and confirm actual source hashes. Native and formal
correspondence is reviewed, not mechanically proved. This matrix supplements
US-056-AC2/AC5/AC7 under CONTRACT-062/063 and does not promote any original case.
Complete backend context/source/fact/cut/publication/diagnostics qualification
remains mandatory before acceptance.

The principal-binding count/preflight formulas are explicit guard-definition
sanity checks; they do not independently model publication or prove SQL ordering.
The final cardinality-erasure control retains JSON string typing. Earlier217
and formal source snapshots remain historical rather than repinned.


### Actual installed role routes: logical, semantic and native controls

For US-056-AC5/AC9/AC10, keep the fixed invoker policy separate from baseline
correspondence. Native tests must demonstrate direct and indirect INHERIT FALSE /
SET TRUE routes while direct effective UPDATE remains false, actual SET ROLE
registry writes, ADMIN-only self-grant escalation, before/after-reset denial and
exact revocation restoration. Identical unsafe comparison packets still refuse;
MEMBER-only without SET/ADMIN/INHERIT can match a fresh scoped baseline. Require
all eleven sections, exact Boolean fields and self-role OID correspondence.
An exact aggregate row budget succeeds; minus-one refuses at the final role read.

Run `tools/security/truss-role-transition-proof.py` from the exact repository root
with Z3 4.15.4. The [current source-qualified run](../../04-build/evidence/security/truss-role-guard-formal/ddff3684-cae4-4029-bd7a-4ac7cb518b5b/proof.json)
requires5 UNSAT violations,3 SAT populations and3 SAT erasures,32 actual-expression
truth vectors,29 original native inventory predicate replays and11 saved formula
byte digests. Independently replay every SMT result and verify source/preimage/
formula hashes. Refuse unsupported source tails, filtered iteration, foreign
columns, changed original pins or early success returns outside the selected tail.
Previous receipts remain historical rather than repinned to changed producers.

Complete native rows, authentic current SET/ADMIN facts and finite immutable fold
inputs are explicit analysis premises. Neither this proof nor successful native
fixture effects qualify the full protected cut, production authentication,
arbitrary mutator closure or complete backend operations. These controls augment
the original132-case plan without replacing or promoting any required case.


### Truss SCRAM authentication and session lifetime — 2026-10-10

[Direct-main integration evidence](../../04-build/evidence/security/truss-scram-authentication/integration.json) records Truss main
`bb5eb75a018e068c281c565ae49e9a50825ee400`. The separately installed combined wheel matches53 source,
owner-asset and typing files, passes328 tests and212 Python boundary imports.
The original PostgreSQL16.15 / pgserver0.1.4+truss.pg16.15 / pg8000
1.31.5 Unix-socket SCRAM fixture passes82 observations across31 inventories,
with21 frozen source/preimage pins. Native authentication log entries bind the
ordinary role and SCRAM method to its backend PID. Wrong credentials and missing
roles refuse28P01. NOLOGIN changes inventory qualification and refuses new
sessions28000, but two established authenticated sessions remain usable.
Restoring LOGIN allows a fresh connection. Thus authentication establishes a
connection identity; login permission alone cannot revoke current operation
authority or retire existing sessions. Protected admission must independently
establish current authority at its coherent cut.

Four failure controls cover receipt/stderr secret redaction, an unwritable receipt
sink, continued connection cleanup and cluster cleanup after failures. Astra ultra
feedback was applied and the captured helper bytes execute directly. The final
read-only review verifies current pins and preserves the qualification boundary.
Historical Truss development evidence retains its original source hashes.

This supplies component evidence for US-056-AC5/AC9/AC10. It does not prove
production/TLS authentication, native protected ontology mapping, complete
collection/current cuts, PA01/PA02 completion, seven semantic operation bodies
or complete backend acceptance. Historical acceptance remains26/132; every
original required case remains governed by the existing plan and the goal stays
active. No source-derived formal theorem gains native/temporal premises merely
from this fixture's success.


### Native elevation routes outside the registered namespace — 2026-10-10

[Verified direct-main integration](../../04-build/evidence/security/truss-definer-routes/integration.json) records Truss
`71ba19f8373657cca34085250819220efd5ea79c`. The fixed invoker observer now requires a twelfth census
section enumerating native EXECUTE-accessible SECURITY DEFINER routines across
all schemas. Schema USAGE is retained independently and cannot filter the census.
Any nonempty census refuses even against an identical unsafe baseline; legacy
eleven-section packets refuse. This is a conservative profile-specific rule.
Protected registered definer chains require a distinct admitted profile; UMF
logical semantics do not prohibit all definers.

The PostgreSQL16.15 / pgserver0.1.4+truss.pg16.15 / pg8000
1.31.5 SCRAM fixture passes97 observations across35 inventories with21 frozen
inputs. An ordinary session with no direct UPDATE right invokes an external
PUBLIC-executable definer owned by a distinct nonlogin role. The actual committed
row UPDATE changes xmin, independently observed, while logical revision remains
unchanged. Original and matching unsafe baselines refuse. Revoking EXECUTE removes
the route; revoking only schema USAGE retains and refuses it. Native prepared-call
revalidation in this fixed fixture returns42501 with unchanged xmin; it does not
demonstrate a surviving write or prove behavior of every retained statement.

Astra identified and verified fixes for the schema-USAGE filter and replayed
packet budgets skipping empty final-section columns. Exact80164-unit budget
passes;80163 and80076 refuse. Native final-section row overflow refuses. The
separately installed wheel matches53 source/owner/typing files and passes334
tests; Python boundary checks pass212 imports. Exact source/preimage, test,
wheel/log/native digests and the read-only Astra review are retained. Owner
historical attempts preserve earlier pins and two rejected prepared-call
predictions instead of being repinned to the final producer.

This advances US-056-AC5/AC9/AC10 and Truss PA01/PA02 component evidence.
It is not complete installed call closure: operator/type/extension routes,
trigger/default/RLS paths, indirect resolution, protected capture, current
authority cuts and seven semantic operation bodies remain unqualified. Earlier
source-derived role proofs retain their historical source scope; no fresh
whole-program, SQL or temporal refinement proof follows. No original required
case is promoted; acceptance remains26/132 and the full goal remains active.


### Operator-backed hidden definer and source-derived guard laws — 2026-10-10

[Native integration](../../04-build/evidence/security/truss-operator-routes/integration.json) records Truss main
`f48975262c74317940329c4f70bd193db81b68fa`. A native operator invokes a SECURITY DEFINER
implementation in a distinct function schema to which the ordinary caller has
no USAGE. The caller also lacks direct UPDATE, but the operator commits a row
UPDATE whose changed xmin is independently observed. The merged census retains
that hidden function and refuses an identical unsafe baseline. Revoking function
EXECUTE then returns42501 with unchanged xmin; scoped correspondence and operator
removal restore the baseline. The proposed EXECUTE-ignoring operator bypass was
not observed. No thirteenth inventory section or new permission semantics is
introduced: this validates an actual route covered by the existing conservative
function census.

The fixed PostgreSQL16.15 / pgserver0.1.4+truss.pg16.15 / pg8000
1.31.5 SCRAM fixture passes107 observations across38 inventories with21 frozen
inputs. The unchanged separately installed53-source wheel passes336 tests,
including original-native operator packet regressions. The read-only Astra review
verifies the native source/preimage and wheel pins. Library source remains the
reviewed71ba19f8 implementation; no unchanged owner build is attributed as new
implementation.

[Source-derived analysis](../../04-build/evidence/security/truss-definer-census-formal/cfa978ae-c2c9-4fef-b244-4495aab10da9/proof.json) recognizes the complete exact
census SQL subset and extracts the actual final three Python classifier
statements. Three UNSAT violation queries show the selected hidden executable
definer cannot be filtered by schema access, a nonempty census cannot match and
an earlier refusal cannot clear. Three SAT controls populate a safe empty
profile, the hidden operator witness and a namespace-filter-erasure leak. All six
SMT byte digests replay independently. Sixty-four Boolean vectors execute the
extracted actual tail;38 original native inventory tail replays preserve refusal
when the census is nonempty. The role-route fold is retained, without replacing
the full classifier with a handwritten policy implementation.

Complete faithful immutable native rows and effective privilege facts are explicit
analysis premises. This is a recognized-filter and pure-tail proof, not native SQL
semantics, full Python ingress/admission, authenticated producer, dependency
closure, temporal-cut or protected-publication refinement. Operator
support/selectivity/planner, type/extension and trigger/default/RLS paths remain
required. The actual protected capture/writer protocol and seven semantic bodies
remain open. This augments US-056-AC5/AC9/AC10 component evidence without
promoting any original requirement. Full acceptance remains26/132 and the goal
stays active.


### Protected caller capture: post-elevation information loss — 2026-10-10

[Native observability evidence](../../04-build/evidence/security/truss-capture-observability/533c90f6-3dbe-4d7d-ae83-484617149b4a/native.json) passes10
observations on PostgreSQL16.15 / pgserver0.1.4+truss.pg16.15 / pg8000
1.31.5. In one physical connection and transaction, direct and unregistered
wrapper paths enter the same privileged function. Their original effective actors
differ; the nine post-elevation fields are identical: session person, effective
writer owner, role setting, database, backend PID, xid, session-role OID, writer
role OID and entry-routine OID. The wrapper explicitly captures its actor in
PLpgSQL before entering the writer; direct host capture precedes its native call.
This avoids relying on SQL target-expression evaluation order.

[Formal equal-input analysis](../../04-build/evidence/security/truss-capture-observability-formal/4b3dbd6b-1c44-49f6-8480-0e84fd4c6a69/proof.json) retains two
UNSAT separation attempts for arbitrary deterministic decisions over that exact
tuple, including equal extra state. A SAT population shows that adding a distinct
trusted pre-entry actor can distinguish the paths. This does not authenticate an
added caller label or implement capture. The formulas do not prove all PostgreSQL
protocols impossible: unequal history/nonce/state, trusted host original-call
custody, native frame/stack evidence and additional provenance remain outside
the equal-input premise. No HMAC/signature primitive is implemented or proved.

PA02's protected realization therefore must name the independently trusted
pre-elevation provenance or qualified original-call restriction that enforces
the registered chain. Sealing only these post-elevation fields cannot recover
the missing actor; same-entry OID/xid/PID binding alone cannot classify these
paths. One-use custody must remain, but refusing a second invocation is distinct
from establishing the original caller of a first invocation. The accepted trusted
embedding host can supply original call facts under Truss ADR-008 only through
qualified exclusive physical-connection custody and protected carriers. Native
SQL arguments do not themselves authenticate Python object identity. Preserve
the existing invoker elevation guard; neither writer-owner substitution nor
caller-supplied JSON/GUC fields is an implementation shortcut.

Required protocol tests now include this collision witness, independently
authenticated pre-entry capture, a forged added actor, copied public context,
first-use submission through a different wrapper, same/different native attempt,
transaction and connection, and native plus trusted-host one-use custody across
savepoint rollback. Original PA-N01–PA-N12 and all132 required cases remain
required; this supplies US-056-AC5/AC9/AC10 design evidence only. The fixture
uses local trust actors and synthetic routine/role names, no actual Truss registry
or business effects, and no authenticated subject/production capture qualification.
PA02 and full backend acceptance remain open at26/132. Earlier cleanup failure
and preliminary SQL-expression-order run retain their original sources; the
final receipt alone qualifies the explicit capture order.


### Trusted-host protected capture candidate — 2026-10-10

The [native candidate receipt](../../04-build/evidence/security/truss-protected-capture-candidate/90e12409-3a54-466f-8184-2a54c961669d/native.json) retains23 matching observations on
PostgreSQL16.15, corrected pgserver0.1.4+truss.pg16.15 and pg8000 1.31.5.
Original source bytes, seven source pins and actual installed routine OIDs,
owners, settings and complete definitions accompany the receipt. The earlier
19-observation run and preliminary23 run remain historical; the final run
adds same-transaction absence checks, original frozen AdmissionCustody execution
and guaranteed sanitized failure reporting even if the receipt sink fails.
Two retained subprocess controls exercise secret-bearing exceptions with writable
and unwritable evidence sinks; both suppress secret text and exception chaining.

This implements an isolated physical candidate for the PA02 prerequisite:
an INVOKER query captures native person/actor OIDs, database, backend PID and
xid before elevation. A separately privileged trusted registrar inserts a
private random 32-byte capability bound to those facts, original attempt and
exact synthetic payload. The fixed host dispatch invokes an INVOKER gate and
DEFINER writer; the writer atomically consumes the matching capability before
inserting the synthetic effect. Ordinary callers cannot read capabilities,
write effects directly, create routines in the candidate schema, or inherit
writer/registrar roles. The wrapper gate refuses elevated acting identities.
The capability is never public context or included in retained evidence.

Actual native negatives refuse forged/copied public context, a different
connection (even with the private capability), another login route, attempt/input
substitution, unregistered wrapper invocation and direct private access.
The exact native positive effect is inspected in its original transaction.
For this inspection only, the fixture administrator temporarily grants effect
SELECT, immediately revokes it, and verifies the final prohibition. This is
an administrative test observation, not an adopted ordinary read surface.

Native same-transaction reuse refuses, but savepoint rollback restores the
native capability's unused state. The producer independently demonstrates
successful direct native replay after rollback and verifies its actual effect.
The existing original Truss AdmissionCustody ticket refuses that resubmission
and retains one fixed dispatch. Therefore the composed candidate requires
trusted exclusive host dispatch and private carrier custody; its native table
alone does not provide rollback-resistant one-use authorization. This is not
a qualified SQL-only route or protection from a malicious same-credential host.
A changed transaction also refuses the old capability.

The adjacent acceptance-map.json ties all23 observations to original requirement
IDs without marking a complete schedule passed. The adjacent astra-review.json
retains independent review: all three harness findings were fixed and the final
seven pins, installed definitions and failure controls were independently checked.

This advances US-056-AC5/AC10 physical component evidence and PA-N03/04/05/09
schedule development, without promoting them to complete acceptance cases.
Local trust authentication, synthetic registrar inputs and the fixed actor
profile do not establish production authenticated subject mapping, SET ROLE,
current owner authority, generation/configuration checks, complete callable
closure, resource admission or publication. PA01–PA04 and all seven Truss
semantic bodies remain unfinished; the original132-case goal remains26/132.
Next integration must replace synthetic registrar facts with the original
owner authority/artifact and coherent-cut protocol, qualify installed closure
and protect the carrier throughout the registered adapter. No public API or
ordinary registry grants are added to Truss.


### Native current-authority primitive and lock boundary — 2026-10-10

The [final native receipt](../../04-build/evidence/security/truss-protected-capture-candidate/85d31486-2f88-48e5-b492-ec15b9d730f3/native.json) extends the protected capture candidate to39
matching observations. Seven original source pins/preimages and six actual
installed routine identities, owners, settings and complete bodies are retained.
READ COMMITTED is independently observed and explicitly required by the writer.
RR/Serializable refusal is currently source-reviewed, not natively exercised.
The earlier23/33/38 schedules and their preimages remain historical evidence.

A separate non-login authority responsibility owns a private, fixed single-actor
row with permitted/generation fields. Only the writer can execute its private
check helper. The helper locks the selected row FOR SHARE, then checks complete
row presence, permission and exact captured generation before the writer inserts
its synthetic effect. Ordinary authority SELECT/UPDATE/helper execution and
revoker direct UPDATE refuse. The registered revoker routine updates the row;
it is the selected native mutation route in this fixture, not a complete policy
administration or ontology resolver interface.

Actual revocation after capture refuses without effects. A separately issued
capability matching the revoked generation independently isolates permission
false; regrant advances the generation and the earlier capability remains stale.
A fresh matching generation produces an independently inspected original effect.
An independently submitted revoker times out with native55P03 while the writer
retains the authority row lock; authority remains unchanged. After writer rollback,
the same revoker succeeds and advances the generation. This is one bounded native
row-lock schedule, not proof of complete writer participation, fair termination,
deadlock freedom or final publication. PostgreSQL16's documented FOR SHARE
conflicts and transaction/savepoint release rules govern this candidate:
https://www.postgresql.org/docs/16/explicit-locking.html.

[Formal guard analysis](../../04-build/evidence/security/truss-capture-authority-formal/19fe84d8-27c7-4bc7-b323-52ad9fe0223d/proof.json) saves eight independently replayable formulas:
four UNSAT laws and four SAT positive/weakened controls. Positive generation
integers are unbounded in the model. Exact authority-check and writer routine
bodies are recognized, but SQL execution/FOUND/atomic exception behavior and
complete faithful current authority are premises. The held-lock serialization
law explicitly assumes revoker exclusion; it is not derived PostgreSQL semantics.
The stale mutant requires captured<current; advancement requires next>current.
Originally parsed native bytes are frozen, canonical invocation is required,
and saved formula bytes are rechecked before publication. No SQL/Python/compiler
refinement, ontology resolution or publication-drain theorem is asserted.

The adjacent native acceptance-map.json links all39 observations to original
US-056-AC5/AC9/AC10 and PA-N01/03/04/05/07/08/09/11 component schedules without
claiming those complete schedules passed. The two sanitized failure controls
remain passing; new UUID receipts use exclusive creation, preserving reruns.
Astra review findings about independent permission evidence and proof source
custody/directional controls were applied before final qualification.

This supplies a current-authority physical primitive only. Production subject
mapping, original ontology/policy/artifact admission, coherent complete source
cuts, all authority mutation/callable dependencies, resource/family bindings,
protected carrier lifecycle and final release remain required. Savepoint rollback
releases the native authority lock and restores native capability reuse; the
existing host ticket remains burned. This cannot replace durable pending-buffer
custody or L03 revocation/drain. No Truss public API or supported backend profile
is promoted. PA01–PA04, seven semantic bodies and the original132 required cases
remain open at the historical26/132 checkpoint.


## Raw ontology read-admission candidate — 2026-10-10

The retained Weft `natural-count-self-join` logical plan now drives the captured Truss PostgreSQL predicate lowerer in a private raw-table experiment. Exact original lowerer and graph-source bytes are frozen with the bridge; no fresh Rust compilation or production owner-artifact admission is asserted. Staff, Projects, resources, assignments and ownership form five private relational tables. The rule requires an active Staff assignment to the same Project that owns the resource. This is a synthetic read-admission receipt, not authorization to mutate resources.

Final native evidence is `truss-ontology-capture-candidate/a91be6ca-a0de-417d-bc51-aec34faaeb41/native.json` under `docs/helix/04-build/evidence/security/`: 76 observations, 11 source pins, eight installed routine bodies and three complete five-table fact cuts. PostgreSQL 16.15, corrected pgserver 0.1.4+truss.pg16.15, pg8000 1.31.5 and Bun 1.4.2 qualify this run. Alice can obtain RA/RAB receipts; inactive, unrelated, ownerless and unknown resources refuse. Ordinary private-fact access and predicate execution refuse. The selected membership revoker receives 55P03 while the authority lock is held, then succeeds after rollback. Only Alice/A's active flag changes. Independent current authority `[[6,true]]` precedes denial of all six resources after membership revocation, isolating ontology denial from stale-generation or permission-false denial. Two sanitized failure-boundary controls pass; earlier run receipts remain historical.

Formal evidence is `truss-ontology-capture-formal/e48c8318-302b-4b23-8fd4-f4d25c00a167/proof.json`: seven replayable formulas (three UNSAT laws, four SAT positive/weakened controls), 14 source pins and three complete finite-population replays. Typed unbounded relational semantics establish the natural-witness join law and refusal without active assignment or ownership. Erasing active status, project equality or the mandatory rule admits counterexamples. Faithful facts, native keys, subject binding and serialized current authority remain premises; exact source coupling is not a compiler, SQL or Rust refinement proof. Exact ordered cuts, unique observations and one actor/Staff mapping prevent vacuous replay.

Astra ultra independently verified final pins, formulas and seven rejected mutation controls; review receipts are adjacent. The acceptance map ties all 76 observations to original US-056 criteria and PA schedules as component evidence only. Historical acceptance remains 26/132. Actual typed graph execution (AC2), Ashlar/Delta, authenticated production subjects and owner artifacts, coherent complete current cuts, installed callable closure, four-family protected admission, seven Truss semantic bodies, field publication and final publication/drain remain open. No supported public backend profile or complete PA02/L03 qualification is promoted. Next integration must use the same owner artifact across actual typed graph storage and raw tables, with production owner admission and final release obligations.


## Original-policy graph/raw population parity — 2026-10-10

A separate installer-only spike now executes the same retained Weft `natural-count-self-join` IR through the frozen actual Truss row-predicate and graph-source modules against the exact captured `qualified-property-layout-0.15.owner-export.sql` object/edge tables. Predecessor IR and both lowerer pins must equal the raw candidate's pins before lowering. The current exported layout bytes, including property declaration modules and definition provenance constraints, are retained; synthetic catalog seeds satisfy those constraints without weakening them. These are fixture assertions, not original catalog staging or authenticated owner metadata.

Final evidence `docs/helix/04-build/evidence/security/truss-ontology-graph-parity/9b5634ec-caf8-4624-9c02-00ed637b3a94/native.json` contains 53 passing observations and nine source pins, SHA256 `e957e0d3de95338d5df53743bd9548fe4fd5ca0d17672894b9d49aed501b1f64`. PostgreSQL16.15, corrected pgserver0.1.4+truss.pg16.15, pg8000 1.31.5 and Bun1.4.2 qualify this run. Five complete native projected relation populations match the independently retained raw initial cut, and five match the raw final membership-revocation cut. Alice admits RA/RAB initially and none after her assignment is deactivated; Bob admits RB/RAB both before and after Alice's revocation. Both six-resource corpora include ownerless and unknown resources. A deliberately reused native object ID across Staff/Project verifies qualified type incidence rather than untyped ID equality.

The authored host preflight checks all five source-validity programs (including outer Resource), six unique natural-key/login groups and both native edge-incidence/logical-endpoint correspondences. Eleven malformed-source controls refuse with42501: absent or wrong-domain active properties, logical/native endpoint mismatches, duplicate Staff keys or logins, retired resource/association metadata, absent ownership/resource fields and wrong active metadata. The two endpoint controls independently observe all11 validity/uniqueness components true, Assignment incidence false and Ownership incidence true before refusal. This isolates incidence from both native and logical duplicate-key constraints. The exact installed read-receipt routine is retained. Ordinary callers have no object/edge SELECT; the fixture's PostgreSQL-owner definer returns only synthetic booleans.

Earlier failures are retained, including missing synthetic definition-provenance fields and a corruption initially blocked by native edge uniqueness. Final controls use existing ProjectD to isolate incidence. No new theorem is asserted: the prior typed relational laws apply conditionally, while native correspondence evidence does not prove automatic SQL/Rust/compiler refinement. Natural key properties remain fixture-attested and explicitly checked; canonical key-bucket codecs/namespaces, current coherent cuts, authenticated production subjects/owner artifacts, original staging, production role/callable closure, protected four-family admission, concurrent authority participation and final publication/drain remain required. The adjacent acceptance map links all53 observations to US-056-AC1/AC2/AC5/AC10 as components only. Complete typed-graph AC2 and full backend acceptance remain open at26/132; no public supported profile is promoted.

Astra ultra independently verified all53 observations, nine current/preimage pins, exact frozen lowering, complete initial/final fact parity, all13 installed preflight components and both isolated incidence controls. The adjacent review receipt records no remaining blocker within this installer-only scope.


## Composed protected graph read-admission candidate — 2026-10-10

The actual graph predicate and explicit full preflight now run behind the private original-call capture primitive. The original INVOKER entry still requires the actor/captured native tuple; the writer checks its registrar-issued capability, exact original transaction/attempt/resource bytes and READ COMMITTED, then calls its private authority helper. That helper obtains the same authority row FOR SHARE, verifies permission and captured generation, executes all13 authored graph-preflight components separately, and evaluates the original compiled owner predicate before inserting a synthetic read-admission receipt. There are no raw shadow fact tables. Exact captured Truss object/edge layout and frozen lowerer bytes are used; synthetic catalog seeding remains installer-authored, not original catalog admission.

Native evidence `docs/helix/04-build/evidence/security/truss-graph-capture-candidate/8ea0b9dd-a0c3-4ecc-b8cb-0d5fbf26998a/native.json` passes135 unique observations with14 source pins, SHA256 `108096e8eb0bace54a4ce709cd44e6ef1b995a4aeb52abd7241f3be9576de7db`. PostgreSQL16.15, corrected pgserver0.1.4+truss.pg16.15, pg8000 1.31.5 and Bun1.4.2 qualify the run. The captured graph predecessor's IR, bridge, both lowerer modules and layout pins must match before composition. Nine installed protected routine bodies, exact generated SQL and frozen fixture/lowerer code are retained. The private authority role owns the edge table and can read required catalog/object facts; actor and revoker cannot directly read/write graph tables or invoke preflight. No public graph support claim follows from those fixture grants.

Eleven deliberately committed installer corruptions now traverse genuine fresh private capabilities and the original native entry. Every malformed source independently yields preflight false,42501, an unconsumed native capability, zero effects inspected in the actual actor transaction, and restored preflight true. Both endpoint corruptions observe the exact13-component vector isolating Assignment incidence. Authority [[5,true]] is independently observed before these controls. These fault injections deliberately sit outside the admitted mutation closure; they do not prove complete participation or coherent source-cut authority.

The selected membership revoker updates the authority generation before changing the actual graph Assignment edge. An independent revoker receives55P03 while the read-admission writer holds the authority row; all five projected fact populations remain unchanged. After actor rollback the revoker succeeds, only Alice/A's active flag changes, independent authority [[6,true]] is observed, and all six resource admissions refuse. Three complete projected fact cuts are retained. Transaction rollback still restores native capability reuse; the original host custody restriction remains necessary and is independently exercised. This is synthetic read admission, not permission for canonical resource writes or a complete publication protocol.

Formal evidence `truss-graph-capture-formal/c2b4aa2a-f28e-4434-bb0a-ce96071da3a3/proof.json` under the same evidence root saves14 formulas: six UNSAT laws and eight SAT positive/weakened controls, with17 source pins and all three complete population replays. Original typed natural-witness laws are supplemented by an explicit authored conjunction of original capability, current authority, full graph preflight and ontology membership. A positive composed SAT control prevents an always-false conjunction from passing; independently erasing each admission guard yields a counterexample. These are conditional model laws, not automatic SQL/gate extraction, compiler refinement, native snapshot/lock semantics or final publication proofs. Source custody and observed native controls are separate evidence.

Two sanitized failure-boundary controls pass. The adjacent acceptance map links all135 observations to original US-056-AC1/AC2/AC5/AC9/AC10 and PA component schedules without promoting complete cases. Authenticated production subjects/owner artifacts, canonical graph key-bucket and namespace authority, original catalog staging, complete authority/callable closure, coherent source cuts, all four protected admission families, seven Truss semantic bodies, field publication and final release/drain remain required. Full graph AC2/PA02/L03 and the original132-case acceptance plan remain open at26/132. No public Truss backend profile is promoted.

Astra ultra verified all135 observations, fourteen native pins, nine installed bodies and eleven corruption groups, then independently replayed the final fourteen formulas with seventeen source/preimage pins. The always-false composition mutant fails the added positive control. Adjacent review receipts record no remaining landing blocker within the declared experimental scope.


## SCRAM-authenticated graph composition and owner-binding audit — 2026-10-10

The composed graph candidate now authenticates fresh ordinary, registrar and revoker sessions with PostgreSQL SCRAM on its owned Unix socket. Four role secrets are generated only in memory and never retained or included in receipt hashes or exception chains. The original bootstrap postgres session remains an explicitly trusted installer; the exact HBA admits local postgres trust, requires SCRAM for other local sessions and rejects both loopback host families. Reload completion, parsed rules, stored SCRAM-verifier presence (booleans only) and unchanged final rule rows are independently observed. This is an authenticated owned fixture, not a production issuer/Staff/owner mapping or general connection-authority profile.

Final native evidence `docs/helix/04-build/evidence/security/truss-graph-capture-candidate/f4186d8d-38ff-461d-9f0c-deefd7b8969f/native.json` passes147 observations with14 current/preimage pins (SHA256 `7cbb71735a60b89f622968eb5426ef6457c826f47914f8dfa0b30b8d1dbb5e4b`). Four wrong-secret attempts and an absent role yield28P01; correctly authenticated sessions independently expose the five expected original native identities, including two distinct connections using the same actor credential. NOLOGIN refuses a fresh actor session with28000 while the existing session still has its original identity. Admission revocation remains an independent current-authority obligation; NOLOGIN alone is not an existing-session revocation mechanism. All135 original graph/protected-capture/authority/corruption controls also pass on these freshly authenticated sessions. SQL, lowerer packet, nine installed protected bodies and complete fact cuts are unchanged from the reviewed135 run. Two sanitized failure controls match the updated producer.

Refreshed formal evidence `truss-graph-capture-formal/0e186858-5aca-40cf-b1a6-53b2e792bbb7/proof.json` under the same evidence root replays14 formulas (six UNSAT/eight SAT),17 source pins and three complete populations, SHA256 `f52b59906718137e426c9b959e0652159a31a872f486b3a7e036cae3e47d5aec`. This rebinds the previously qualified conditional model to the authenticated native run; no SCRAM cryptographic, SQL/compiler or publication theorem is added. Historical135 receipts retain their original source bytes and narrower trust-authentication scope.

The next catalog integration cannot silently rewrite the owner source. The actual frozen Truss declaration collector, executed on the retained original owner document, exposes five keys with unspecified primary roles, zero core relationship declarations and two ontology associations with ordered typed endpoints. Resource's complete required signed64 integer salary declaration is preserved alongside key-only read projections. Current native staging source explicitly requires a Boolean primary selection; its guard is source inspection here, not a performed native refusal. These facts require owner-issued storage key-role choices and relationship bindings with original accepted-binding provenance. Key-only graph projection cannot stand in for complete Record/property catalog staging or field publication.

[Owner-binding audit](../../04-build/evidence/security/truss-owner-binding-audit/9d296d60-1dd6-48cd-bb6e-2b63d7d4778e/audit.json) is located under `docs/helix/04-build/` and passes14 observations with five current/preimage pins, SHA256 `46a649c19af2f370518c27667e45de4177b59e0b954ba6f4a12426809d938f01`. A separately parsed frozen oracle checks the complete post-call document, exact ordered keys, complete Field/reference inventories and full ordered ontology endpoints. Composite-key reversal, integer-width deletion, unknown-extension mutation, omitted Record and omitted Field controls all refuse. The initial eight-observation audit had aliased preservation checks and provides no independent preservation qualification; its receipt remains historical. The twelve-observation correction predates the final completeness controls. No fresh owner validation, original catalog preparation/staging or binding authority is claimed by this audit.

Astra ultra independently verified147 native observations/14 pins, replayed14 formulas/17 pins and verified the final14 audit observations/five pins, including all five mutation/omission controls. Adjacent reviews are clean within their declared scopes. The acceptance map treats authentication as a PA-N01 prerequisite, without claiming SET ROLE coverage, and retains original US-056 component links. Complete owner bindings/authenticated artifact/current-cut/installed-callable and mutation closure, all four families/seven semantic bodies, canonical graph keys and final publication/drain remain required. Complete backend acceptance stays26/132; no supported production profile is promoted.

## Original owner document/native catalog staging — 2026-10-10

The unchanged `natural-count-self-join` owner document now passes genuine original UMF preparation and actual Truss provisional catalog staging on PostgreSQL16.15, pgserver0.1.4+truss.pg16.15, pg8000 1.31.5 and Bun1.4.2. Retained evidence `docs/helix/04-build/evidence/security/truss-owner-catalog-stage/75408a57-00c9-4054-bffc-ab2a918dfb73/native.json` passes31 observations/697 source pins, SHA256 `bec358feb8942d8a5bea0208f368da2bece80dc7c08c87e9a1ae3cdbf7cefa88`. Executed copied source includes the owner bundle, actual Truss preparation/stager/native SQL/layout, and declared Ajv8.20.0 dependency closure. The private bounded stdio adapter drives one installer transaction; this does not qualify the complete installed public runtime or driver.

Independent native projections verify exactly five original Records, all nine owned Fields with full scalar/nullability/cardinality/facets and accepted-document provenance, five original ordered keys as non-primary, and zero relationships/endpoints. Exact archived source retains absent primary markers, the unowned Field and unknown content. Salary retains its required signed64 facet. A native primary substitution and a composite component reversal each refuse the intended message/55000 from an isolated genuinely new-key prestate with an agreeing successful positive; exact state is restored. The head stays unpublished and rollback removes all staged catalog rows. Passing evidence is emitted only after independently attempted cleanup succeeds.

The first retained run failed in the RPC command-result adapter. Historical13/20/21-observation runs do not independently isolate key guard refusal: their existing-key prestate can also refuse55000. The corrected29 run predates complete native type/relationship checks. These remain historical receipts, not the final qualification. Refreshed post-validation collector/literal guard audit `truss-owner-binding-audit/db1509e7-7399-4d62-8322-a1663e40a614/audit.json` passes14 observations/five pins, SHA256 `cb2b47b065313e8295a0d8e4e08428245ba1f00b358c78365b5f68b9d55c36cc`; its scope remains source inspection and post-validation preservation, separate from the new native spike.

This resolves the extra host primary-marker restriction and qualifies complete original catalog projection for the captured installer-only subset. Original ontology associations still require authenticated owner-issued physical relationship bindings with exact source provenance. Synthetic operation artifacts, trusted installer identity, absent binding/default JSON homes and rollback-only provisional revision are explicit premises. Accepted owner/binding/current-cut authority, canonical key buckets, complete mutation/callable closure, protected semantic bodies and final publication/drain remain open. US-056-AC1/AC2/AC10 gain component evidence; no whole criterion or backend profile is promoted. Historical acceptance remains26/132.

Astra ultra independently audited final31 native observations and all697 current/preimage source hashes with no remaining blocker. Review was read-only, with no native execution; the qualification remains provisional installer staging with rollback.

Catalog-stage source preimages are retained as byte-exact `preimages.zip` bundles next to each receipt. The producer checks every entry against the captured bytes before execution; independent hash verification checks all entries against the receipt source inventory. This compact representation replaces duplicated dependency trees without changing original receipts or source bytes. The earlier58932dc5 run precedes only this archive representation change.

## Ontology association storage binding implementation gate — 2026-10-10

`docs/helix/02-design/contracts/security-association-binding.proposal.md` specifies original ontology/core/binding provenance, explicit binary edge roles, ordered target-key correspondence, physical compatibility, complete source coverage and acceptance-linked positive/negative tests. Current Truss accepted-binding vocabulary covers storage keys only. A new relationship interpretation must be registered and qualified before native relationship creation; absence of core direction/multiplicity/lifecycle cannot be repaired by silently rewriting the owner document. The next implementation must consume original authenticated artifacts and compiler-owned logical predicates, retain same-witness incidence/attributes, and prove complete mutation/current-authority/publication closure. The31-observation installer-only catalog result does not close these gates or promote26/132.

## Conditional association storage compatibility — 2026-10-10

Formal evidence `docs/helix/04-build/evidence/security/association-storage-compatibility/d31be4c0-393e-4209-b775-e6563ac54c83/proof.json` saves12 independently replayed formulas (four UNSAT/eight SAT), five current/preimage source pins, Z3 4.15.4, SHA256 `0c94557e3b6e55545565d04022a66bf73312f5b30e01bfd19c7470883814ce80`. Quantification over every nonnegative participation count proves that complete preservation excludes an inferred positive minimum or finite maximum, with explicit unrestricted positive and separate restrictive-bound counterexamples. Exact distinct binary role selection preserves the same-witness key/attribute predicate in either physical orientation; assuming ontology array order is native direction has a valid-population counterexample. This is an abstract conditional model. It does not extract SQL/compiler semantics, prove lifecycle compatibility, authenticate owners/cuts, establish complete facts/keys or qualify publication. The initial8-formula run had a tautological count check and is superseded by the quantified model.

Implementation must preserve native unrestricted storage compatibility or require an explicit semantic restriction before choosing bounds. Current Truss native relationship carrier requires bounds/lifecycle/direction, while the retained ontology asserts none. No existing core source is rewritten, and no new accepted-binding vocabulary or native support is claimed by this proposal. Owner-issued role choices, original accepted binding/archive custody, exact independent native definition correspondence and compiler-owned lowering remain required. US-056-AC2/AC10 gain design/component proof obligations; historical26/132 remains unchanged.

Astra identified native `edge_out` endpoint-pair uniqueness as a separate association-instance preservation gate. The final proposal requires an authored key proving endpoint-tuple uniqueness or refusal of this layout. Three additional formulas establish conditional instance injectivity, a valid distinct-endpoint positive and a parallel same-endpoint/different-key counterexample. The nine-formula predecessor lacks this gate. Semantic count laws assume realizability over all nonnegative counts; arbitrary owner domains/keys must be compared independently, and explicit operational resource refusal is separate from semantic restriction. No infinite storage capacity is promised.

Astra ultra independently replayed final12 formulas (four UNSAT/eight SAT), verified all five current/preimage pins and found no remaining blocker within the proposal scope. These remain conditional laws, not native binding admission, SQL/compiler refinement or acceptance promotion.

## Implemented private association correspondence boundary — 2026-10-10

Truss main `fe8a67051a4ecb3c6a0ff10fdd89ab71f3d9a218` implements `packages/python/src/truss/_security_association_binding.py` as a preliminary source-correspondence boundary. It captures exact bounded original core/ontology/binding bytes and returns frozen tuples/bytes, preserving unknown numeric tokens without imposing Decimal or integer ranges. It requires complete association and role mappings, explicit orientation/unrestricted independent storage choices, exact ordered association/target-key references and an authored association key contained in endpoint Fields. Separate instance IDs and attribute-dependent keys refuse the endpoint-pair edge layout. Higher arity, non-string endpoint profiles, changed source digests/revisions, missing/defaulted metadata and duplicate mappings refuse.

Truss evidence `docs/helix/04-build/evidence/security-association-binding/b332851f-fc2d-4489-b737-536aa90bfe84/tests.json` passes39 tests under Python3.11.17, six current/preimage pins, SHA256 `d81a4d95a527948dda63e3e08fa76817a8e8a762818ab2b5bcb7603c01ca44b8`. Tests retain original fixture bytes, both explicit orientations, composite-order positives and independent reversals, endpoint-key subset positives, parallel-instance loss, duplicate/omitted mappings, Unicode/depth/byte boundaries, unknown fractions and extreme exponents/5000-digit integer tokens. Python module boundaries pass245 imports. Astra ultra verified all six pins,39 names against AST/log and the boundary result; it reviewed the corrected implementation with no remaining blocker. It did not rerun the suite or execute native operations.

This checks source correspondence only. Genuine UMF/ontology owner semantic validation, authenticated original artifact/cut and archive revision/pointer authority, registered relationship interpretation, actual catalog/namespace/key/incidence observations, original Weft lowering and complete protected mutation/publication remain independent required gates. The output dataclass is not an admission capability; no database effects/public exports or installed-wheel/backend qualification follow. The mapping carrier is a private candidate, not a newly accepted native vocabulary. US-056-AC1/AC2/AC10 gain preliminary component evidence, not completed criteria; historical26/132 remains unchanged.

## Original owner interpretation and association correspondence — 2026-10-10

`tools/security/qualify-association-owners.py` now executes the pinned UMF producer's original `inspect` API, Weft's legacy `security_mapping_handoff` owner entry point and the captured Truss Python correspondence boundary against the unchanged `natural-count-self-join` core/ontology sources. Final evidence `docs/helix/04-build/evidence/security/association-owner-interpretation/0e6a5088-80fd-4279-b8ef-4da50419248c/receipt.json` passes25 observations/292 current/preimage source pins, SHA256 `c3299918ae2594ff4da0c0063fc4857e58c3317d2ccf27405e34ba65692a5eba`, using Python3.11.17, Bun1.4.2 and rustc1.90.0. Captured Weft sources from clean main checkout `6cc7bc71e47cf31da9197c964db979f9a21ecb4d` build in a fresh temporary target with locked offline dependencies; executed UMF/Python source is copied from captured bytes. Original fixture digests and complete owner handoff match. The producer checks source, executable and archive custody before retaining a passing receipt; preimages and build logs are retained. Registry dependency bytes and the complete toolchain are not archived, so this is not a hermetic-build proof.

Independent actual-owner controls reject invalid core kind (UMF validation and Weft `WFT-MODEL`), substituted ontology document revision (`WFT-SECURITY-PIN`), removal of a declared Assignment Field classification (`WFT-SECURITY-ONTOLOGY`) and removal of an endpoint required by the policy (`WFT-SECURITY-TYPE`). Every Weft refusal has exit1 and empty stdout after the agreeing successful original. The first25-observation predecessor instead added an unknown ontology member; it cannot prove missing-classification rejection. Two intervening captured-source builds failed because compiler schema dependencies were omitted; their logs/preimages remain historical. Successful `caa02791` precedes explicit Python/Bun runtime metadata; `2eefdfc1` retains those hashes but precedes Weft's merged reliability integration. The final run preserves that integration, captures its clean main commit and reproduces the same original handoff. Astra's requested control/custody corrections are applied in the final run.

US-056-AC1/AC2/AC10 gain original interpretation and source-correspondence component evidence. Weft interprets the original legacy policy/query/binding packet; it does not register, issue or authorize the new private association mapping. The private correspondence dataclass grants no native authority. Authenticated owner/issuer/current-cut and archive-pointer custody, registered native relationship interpretation, canonical keys/incidence, complete protected mutation/callable closure and final publication/drain remain required. Historical acceptance stays26/132. Next implementation work must carry these exact owner-validated source dependencies into registered binding admission and independently observed native relationship definitions before protected graph activation.

Astra ultra independently verified the final receipt SHA, all292 current/preimage pins,25 unique matching observations, clean Weft main commit, fresh build log/removed target, runtime/tool hashes and complete handoff correspondence. It found no remaining blocker within interpretation/correspondence scope. Review was read-only and did not rerun the compiler or execute native operations.

## Private provisional binding byte custody — 2026-10-10

The native `catalog_binding_archive` candidate retains the entire original binding body, vocabulary pin, artifact identity, complete original admitted input and actual writer xid. `runtime_stage_catalog_binding` checks original admitted bytes/digest, canonical base64, exact current document cohort and unchanged prior revisions/archive before inserting; the archive participates in catalog generation and has ALWAYS immutable UPDATE/DELETE/TRUNCATE guards. The actual private TypeScript stager calls it inside the existing savepoint before native definitions. Unknown binding content remains uninterpreted, including binary NUL/invalid UTF-8 and extreme numeric token text. Present-binding default homes still refuse; these fixtures explicitly select JSON homes.

The complete native prestate capture has a distinct `truss-native-catalog-prestate/0.2-binding-custody` profile including prior archive rows. The 0.1 producer refuses when the archive relation exists. This is fresh isolated candidate DDL, not adoption/migration of the exported storage layout or populated deployments. **The 0.2 parity/finalizer is unimplemented**: existing `runtime_verify_new_catalog_prestate` does not admit this profile. No accepted report, readiness, publication or registered relationship authority is established. Native JSON aggregation is size-checked after aggregation; it is not a general CPU/allocation bound.

Captured-source native receipts (PostgreSQL16.15, pgserver0.1.4+truss.pg16.15, pg80001.31.5, Python3.11.17, Bun1.4.2):

`truss-binding-catalog-stage/4c7f2a37-f6bc-4582-a282-696b6b7374bf/native.json`: 84 observations/700 current/preimage pins; SHA256 `c183c2eed9a290fec6d1ebed4e3b553d35be0761663373bbeea526efc1f6a208`.

`truss-binding-catalog-stage/e8e65e86-4af3-4840-88ad-5e85f2a7da26/native.json`: 79 observations/700 current/preimage pins; SHA256 `0216dc8b7ee69c26fe9b4c195aba856cf6388aa56ecd0fab1d8d2741d6958bf2`.

`truss-owner-catalog-stage/af76cacd-6eb8-48a4-937e-c7e6fd7b8f4e/native.json`: 31 observations/697 current/preimage pins; SHA256 `f2839fa8c5c52e37a16408ad0fc7eddf34ab0f0b08f09ea22f9651d4d987115c`.

Occupied coverage uses an explicitly excluded installer seed on revision0 with inert original bytes, not an accepted historical cohort. All guards are restored ALWAYS before genuine capture/staging. Successful current staging and whole rollback preserve that prior row; an isolated prior identity-byte drift after original capture refuses with the intended55000 message and zero effects, following an agreeing positive. Independent byte substitution, prior revision, document revision/digest refusals, generation, immutable guards, ordinary-role privilege denial and full catalog/archive projections also pass. Ordinary-role controls use SET LOCAL ROLE in the excluded installer session, not login/SCRAM qualification. All required cleanup completes before passing receipts. Bun catalog-input preparation regression:16 tests/55 assertions.

Astra ultra reviewed source/controls, verified the earlier75-observation/700-pin receipt, and requested occupied-prestate coverage and fresh execution; both are now retained above. Historical75/77 predecessors precede current harness, and two failed attempts (including misrouted `truss-owner-catalog-stage/8bccc16f-9255-4ec0-b786-5de3cb0c9c9e`) retain failure/preimages without claiming support.

US-056-AC1/AC2/AC10 receive component evidence only. Historical acceptance remains26/132. Authenticated owner/issuer/current-cut and report custody, registered vocabulary/relationship interpretation, canonical keys/incidence, complete protected mutation/callable closure, 0.2 finalizer/publication/drain and remaining backends stay open. The archive is byte custody, not a policy engine or a semantic authority.

Astra ultra independently verified the final occupied receipt SHA, all700 current/preimage pins and84 unique matching observations, including isolated prior-byte drift, restored ALWAYS guards, before-admission old-profile refusal and exact positive/rollback preservation. It found no blocker for this narrowly scoped landing; review did not execute native probes.

## Binding-aware retained new-only parity — 2026-10-10

`runtime_verify_new_catalog_prestate` now reconstructs the complete retained catalog for exact profiles0.1 and0.2-binding-custody. The binding-aware branch includes every prior binding archive row, excluding only the selected new revision; exact JSONB parity detects prior-byte drift and missing/extra members. The verifier refuses0.1 with an installed archive or0.2 without it, using55000 `original prestate archive profile correspondence required`. A constant parameterized query keeps the optional relation out of the legacy absent-archive branch. This supersedes the earlier statement that0.2 retained parity is unimplemented; **finalization/publication remains unimplemented for this profile**.

`truss-binding-catalog-stage/ad0315c2-eb86-41ea-a50e-8d3ad3ff6ebf/native.json`: 94 matching observations/700 current/preimage pins; SHA256 `bcc3a44518a1472f6457d1486e6251e15f05d4e8f43bdd5fdb3a1f8131462a26`.

`truss-owner-catalog-stage/4e88698c-cb91-469f-af43-87ddc8b20070/native.json`: 32 matching observations/697 current/preimage pins; SHA256 `87b54f11f5071001c762bd535e4c2e637c2ce40d0b26f7f5d11501e6903fd148`.

Actual native positive verification passes before and after full original cohort staging. The occupied fixture's isolated prior identity-byte drift refuses retained parity with the intended55000 and no further effects; rollback restores prior fixture bytes exactly. Both profile/relation mismatch controls call the verifier itself after an agreeing positive, then restore the original snapshot. Profile substitution is explicitly excluded-installer fault injection: the original-operation guard function is temporarily replaced to permit substitution, then restored from exact captured original DDL before verification. Attempts to mutate without that exclusion and to ALTER the trigger with pending deferred events failed before reaching the verifier; their evidence is retained without claiming branch coverage. A separate native startup timeout is also retained. Legacy absent-archive positive coverage now directly executes the verifier, rather than inferring support from staging. Native versions and installer/SET LOCAL ROLE limitations remain those of the preceding binding-custody evidence.

This is retained new-only parity only. It does not authenticate the prestate producer, validate the excluded current cohort, authorize accepted-report provenance, register semantic vocabulary, prove native relationship/key/incidence correctness, or finalize/publish revisions. These gates, protected mutation/callable closure and remaining backends remain open. US-056-AC1/AC2/AC10 gain component evidence; acceptance remains26/132.

Astra requested a valid legacy-shaped prestate for the installed-archive mismatch: the final94-observation run changes only the profile and removes the0.2-only `bindings` member, leaving every other native catalog component unchanged. Its intended55000 demonstrates refusal of otherwise silently omitted archive state. The earlier02038994 packet retained that member and remains weaker historical evidence.

Astra ultra independently verified final94/700 and32/697 receipts/pins, corrected legacy shape, exact mismatch errors and restoration. No remaining blocker for retained-prestate parity scope. Review was read-only and did not execute native probes.

## Original full native inventory and key-default correspondence — 2026-10-10

Executing `runtime_collect_new_catalog_inventory` on the unchanged owner-validated natural-count cohort exposed a real staging/verification disagreement: `runtime_stage_new_key` already interpreted omitted `primary` as false, while the inventory compared stored false against SQL NULL. The inventory now applies the same explicit false default. It preserves authored true and false; no primary key is inferred from a key name. The original failed collector execution is retained at `truss-binding-catalog-stage/e50fdd37-6b9b-4a51-89df-33f452f632f1/failure.json`.

`truss-binding-catalog-stage/ea488fcf-d9c1-4417-b9d2-7a39153af847/native.json`: 99 matching observations/700 current/preimage pins; SHA256 `4c3a5d6efeddd78dcc8e9349e7988758a35d77f0e6ece582572dcf78260bccca`.

`truss-owner-catalog-stage/a54de9b1-c3e0-4959-a215-e8a6bc34c531/native.json`: 33 matching observations/697 current/preimage pins; SHA256 `802b9c97d036f53b3acfa8a344b4be4205586e917a86375db47718065fbe6b79`.

The actual binding-aware full inventory now returns5 original Records,9 owned Fields and5 keys; the actual count collector returns5/9/5/0/0/0. It invokes complete core declaration/definition/source and retained-prestate checks. An agreeing positive precedes isolated native substitution of one nonprimary key to primary; the collector refuses with55000 `stored original ordered Key definition correspondence`. Full key_def rows now participate in native before/after refusal and savepoint rollback snapshots, so restoration is directly checked. The final99-observation receipt supersedes951e83ac, whose snapshots omitted key rows. The absent-archive path independently invokes the full count collector and retained verifier, passing33 observations. Versions, captured source custody, cleanup and installer limitations remain as recorded above.

This does not prove present-binding current-cohort authority: the collector still interprets authored core definitions only; byte archive presence does not register ontology relationship semantics. The ingress report basis still refuses present bindings pending registered binding effect interpretation. Authenticated owner/issuer/current-cut/report custody, native relationship/key/incidence interpretation, complete protected mutation/callable closure and final publication remain open. US-056-AC1/AC2/AC10 gain component evidence only; historical acceptance remains26/132.

Astra ultra independently verified final99/700 and33/697 receipts, hashes and current/preimage pins; the isolated exactly-one-key false-to-true fault, intended refusal and full key restoration; actual inventory/counts in both profiles. It found no blocker within authored-core correspondence scope. Review did not execute native probes.

## Complete-inventory binding exclusion — 2026-10-10

The original ontology does not issue the bounds/lifecycle/direction asserted by the authored-core native relationship stager. The source-correspondence candidate cannot synthesize those assertions or use accepted-document provenance for an ontology-derived relationship. Registered physical interpretation remains required before native association effects.

A complete-inventory gap is now closed: the existing original-core implementation is explicitly `runtime_collect_new_core_catalog_inventory`; its body and source checks are unchanged. The `runtime_collect_new_catalog_inventory` wrapper reads the actual retained operation's original input bytes and admits only version0.1 with exact absent binding carrier. A present or unsupported carrier refuses with0A000 `registered binding effect inventory required` before delegation. `runtime_collect_new_catalog_counts` still calls that wrapper, so it cannot silently report zero binding-derived relationships as a complete inventory. Both functions are invoker routines with PUBLIC execution revoked. This is a binding-specific exclusion, not a general complete-effects theorem; transforms, accepted report authority and other obligations remain separately guarded/open.

`truss-binding-catalog-stage/67d0fa7d-c649-43a6-8eae-8ddb31cba4cd/native.json`: 102 matching observations/700 current/preimage pins; SHA256 `20ca5221ee8c136739d506aa7fd69f32aaa6b3b7cc8b0d450196be4166659e9a`.

`truss-owner-catalog-stage/9a26a93f-39cc-4ad7-af83-dfbfd7d4971f/native.json`: 33 matching observations/697 current/preimage pins; SHA256 `110fbc0e47f28c2e28b05833d6e9cfb470f535bce6ff1162423c6993fa675fff`.

The binding run labels its19-definition success `original-core-only-native-inventory`, preserves key mutation/refusal tests, and independently refuses complete inventory and counts with exact intended errors and unchanged native snapshots. The original absent-binding cohort independently passes actual complete inventory/counts and retained parity. Earlier18dec7b8 passed the same gate but used the misleading complete-inventory label; it remains historical. Versions, copied source/ZIP custody, cleanup and excluded installer limitations remain recorded above.

Prior99-observation results remain evidence of authored-core correspondence only; they cannot authorize complete present-binding effects. No criterion is promoted: historical acceptance stays26/132. Next implementation requires original owner-selected physical profile obligations, retained ontology/core/binding extraction provenance and registered native effect interpretation, followed by protected key/incidence/mutation closure and authenticated final publication.

Astra ultra independently verified final102/700 and33/697 observations/pins/hashes, original retained binding gating, exact0A000 refusals and unchanged native state, and found no blocker for this binding-specific exclusion. Review did not execute native probes.

## Explicit physical storage basis carry-through — 2026-10-10

The private association binding already requires eight explicit storage choices. Its immutable parsed result previously omitted them, leaving a downstream compiler to revisit bytes or reconstruct defaults. `AssociationStorageBasis` now carries source/target minimum and maximum, directed, lifecycle, composition and inverse verbatim from the validated candidate, plus the exact zero-based original `/mappings/n/storage` pointer. `AssociationBasis.storage` retains only immutable primitives. Mapping order determines the source pointer; explicit role orientation remains separate. No field is inferred from the ontology, key name or endpoint order, and missing storage continues to refuse. Original binding bytes remain retained.

This does not register the candidate or authenticate its issuer. The selected independent, unrestricted binary subset remains unchanged; alternate storage behavior still refuses. The constructible dataclass is correspondence data, not a native admission capability. A later registered interpreter must resolve this pointer against the original retained artifact and independently establish ownership, interpretation profile and current-cut authority before effects.

Captured-source qualification `association-owner-interpretation/8da2bb4f-6362-4ff1-9b29-fd86e498084e/receipt.json` passes31 observations/292 current/preimage pins, SHA256 `79bc868540dad12081332ca1b9088b246379e9f1989526b15bbe6561e1d9a763`. It executes43 captured association tests and retains their log; additional checks verify both source pointers and every declared storage value. Fresh captured Weft build and pinned UMF owner inspection preserve the complete original legacy handoff and four independent owner refusals. Versions, executable custody and nonhermetic dependency/toolchain exclusions remain in the receipt. Python module boundary check passes268 imports.

The native harness now pins that refreshed interpretation receipt instead of the stale predecessor. `truss-binding-catalog-stage/39a1513e-a668-4619-921e-5bd6573472e2/native.json` passes102 observations/700 current/preimage pins, SHA256 `8dc7ddd6469cd40181d4a4b5e0564937fb45d8e3270b6227fa5c0dc8c6067b0a`: original byte archive, occupied prestate, core-only inventory and complete binding-effect refusals remain intact. The old owner interpretation receipt remains historical with its captured preimages; its source pins are no longer current after this deliberate change.

US-056-AC1/AC2/AC10 gain preliminary source correspondence evidence only; acceptance remains26/132. Registered native association definitions/provenance, canonical key/incidence and protected mutation closure, authenticated report/issuer/current-cut and publication remain required.

Astra ultra independently verified the31-observation/292-pin receipt, exact source archives, fresh owner build and43 test names/results against captured source. It found no blocker for the frozen storage-basis carry-through; review was read-only and did not execute tests or native probes.

## Public installed preparation of the original security cohort — 2026-10-10

The newly merged public Python `prepare_acceptance` API is exercised against the unchanged original natural-count core and exact association binding candidate. Source/core bytes and caller-selected binding carrier survive exactly; owner declarations contain5 Records,9 owned Fields and5 keys, with no invented core relationships. The public provenance explicitly keeps `installation_profiles_verified=false` and scope `original_umf_preparation_only`. Unknown binding vocabulary is preserved without registration/endorsement. Invalid core kind must refuse as `invalid_document` with original owner `CORE_SCHEMA_PROPERTIES` error at `/modules/0/elements/0/kind`; the isolated valid-format binding SHA substitution must refuse as `invalid_input`, preventing a generic runtime/producer failure from satisfying either control.

`tools/security/qualify-public-security-preparation.py` captures83 source/test/configuration/asset preimages, builds a fresh wheel offline without fetching build dependencies, installs it into an isolated temporary target, verifies the imported `truss` path lies within that target, and executes the copied5-test suite. Every shipped source/asset is compared byte-for-byte with its captured original; copied execution inputs and current source pins are rechecked. Python/Bun executable hashes are checked before/after. Build/install/test logs, original wheel and ZIP source preimages are retained. Temporary build/install state is removed before the passing receipt is written. This is not a hermetic build-toolchain proof or full installed-wheel/backend qualification.

Final `public-security-preparation/4edd0e6e-ea75-47ec-8d0f-e8ae84eeb9d0/receipt.json` passes5 tests/83 current-preimage pins, SHA256 `1f0e91dc542867fc47a1095484527096e8238229d074adea10b1b5deae0e11c4`; retained wheel SHA256 `fb23c4ab910f3678776e545f49906b933b5fe31ff4fe1a103a637a706a3a6f19`. Python3.11.17 and release-pinned Bun1.4.2 execute the actual public preparation. Predecessorsd0154fef andddb37985 lack final runtime/copy or exact refusal/path controls and remain historical. An initial development assertion expected flat Field/key arrays; inspection showed the actual owner declarations nest them perRecord, and the final test checks complete sums across all five owners.

This replaces custom-bridge-only evidence at the public preparation boundary; it does not replace ontology owner interpretation, register the binding vocabulary, open a database or issue accepted identities/reports. Authenticated owner/issuer/current-cut, native physical association/provenance/key/incidence and protected mutation closure, final publication and other backends remain required. US-056-AC1/AC2/AC10 gain component evidence only; acceptance remains26/132.

Astra ultra independently verified the final receipt SHA,83 current/preimage pins,77 exact shipped sources/assets,5 installed-wheel tests and precise diagnostics, import-path isolation, runtime hashes and cleanup. No blocker for this public preparation coverage. Review was read-only and did not execute tests.

## Independent current-operation native binding source observation — 2026-10-10

`runtime_collect_original_catalog_binding` independently reads the immutable native binding archive under the actual current writer/ordinal and admitted catalog operation, with the original exclusive head admission. It invokes the established complete original-core inventory, original document carrier and retained-prestate gates, then compares full archive input/writer and original artifact body/SHA/identity/vocabulary against the retained operation's original input. It returns exact binding/input hex bytes and digest, plus the actual writer xid, operation ordinal and effect generation. It preserves opaque binary content and does not decode its semantics. The invoker routine has PUBLIC execution revoked.

This is fresh isolated candidate DDL and a source observation, not an accepted-binding source envelope, authentication or registration. Native `accepted_binding` provenance remains rooted in an immutable accepted report; provisional operation data cannot be relabeled into that category. The returned row is not a transport/reuse capability; future compiler/host custody must recheck original operation/generation and independently qualify semantic owner/current-cut authority before effects. General native CPU/allocation/aggregate transport budgets and complete runtime/driver qualification are not established by these finite fixtures.

`truss-binding-catalog-stage/c9857f9c-d1af-4198-984a-60cc3340628f/native.json`: 129 matching observations/702 current/preimage pins; SHA256 `77d37a6714279ff06614ad23a92509c128456ff407e79c0926902fec022ac346`.

`truss-binding-catalog-stage/643295c1-98b7-4e29-bd7f-30cab1b0cca4/native.json`: 121 matching observations/702 current/preimage pins; SHA256 `5522c6d07dc1db0ecc116a8ac3a73885cc1a6a4001dcb01590e67f1573d004b1`.

Each archive body, complete input, writer xid, artifact identity and vocabulary fault changes one field on the current revision following an agreeing positive. Excluded installer injection temporarily disables archive immutability solely for the fault, restoring ALWAYS guards before observation; the intended55000 refuses with unchanged fault-state and exact rollback restoration. An independent document revision fault refuses through the existing original-document carrier gate. Ordinary SET LOCAL ROLE cannot execute the routine (42501). Full native key/document/archive/operation snapshots and required cleanup remain retained. Opaque binding input includes NUL, invalid UTF-8 and extreme numeric token text; byte custody and complete-inventory refusal remain intact.

The initial125-observation predecessor included redundant document matching in the observer. A later control failed only because the existing core carrier refused earlier with its original error; that retained failureffdb4452 is not a passing new branch test. The final implementation reuses that established carrier and removes the redundant loop. The final129/121 runs use the intended existing error and unchanged source pins.

US-056-AC1/AC2/AC10 gain component evidence only; acceptance remains26/132. Registered native association definitions/extraction/provenance, complete canonical key/incidence and protected mutation closure, authenticated original issuer/current-cut/report custody and final publication remain required.

Astra ultra independently verified both final receipt hashes,702 current/preimage pins per run,129/121 unique matching observations, exact binary source observation, six isolated intended55000 refusals, ordinary42501, unchanged fault-state and restoration, and continuing0A000 complete-binding gates. No blocker for current-operation byte observation. Review was read-only; native execution was not rerun by the reviewer.

## Exact original association mapping extraction — 2026-10-10

The private association basis now retains each whole authored mapping value as immutable `definition_bytes`, its exact logical `/mappings/n` source pointer, and candidate extraction identifier `truss-original-association-json-candidate/0.1.0`. Extraction occurs after the existing complete JSON duplicate-member, Unicode and resource validation; returning a basis still requires every original shape and semantic correspondence check. Decoded root member names locate the original mappings array; JSON decoder boundaries select original value slices. UTF-8 encoding those original slices preserves authored member order, internal whitespace, escapes and multibyte text without reserialization. Whitespace outside the selected value remains in the full original binding archive. Mapping order determines the pointer; endpoint orientation remains explicitly authored.

This addresses the exact-source requirement for a future registered compiler without inventing accepted provenance. The extraction identifier is not a registered vocabulary, signature or transport capability. The result remains constructible correspondence data; a consuming admitted operation must independently resolve its pointer/bytes against the original current binding archive and qualify ontology/core owners, complete dependencies, semantic interpretation, issuer/current cut and accepted report authority. No relationship is staged and the complete binding inventory gate remains closed. Existing1MiB source,32-depth,16384-node and4096-array limits remain; retained mapping slices total no more than the original binding bytes. This is not a whole-runtime heap, native transport budget or formal decoder proof.

Captured owner qualification `association-owner-interpretation/f316ca00-80f1-4da5-8b97-686e6c278733/receipt.json` passes36 observations/292 current-preimage pins, SHA256 `7e84130a8293cf25ebb2fe40b233d9d08bc5becd6bd755926da85020c51e8088`. It executes50 captured tests, checks both exact mapping fragments/pointers and the candidate extraction identifier, and retains fresh Weft owner build, UMF owner validation and four original-owner refusals. Added controls cover authored formatting, escaped root member/value spellings, reordered/root-first mappings, multibyte UTF-8, delimiters inside strings, escaped duplicate-member refusal and immutability. Python module boundaries pass281 imports. Toolchain/dependency exclusions remain explicit; this is not a hermetic build.

The native harness now pins that refreshed owner receipt. Fresh original-candidate catalog `truss-binding-catalog-stage/c6f72f92-9c1c-49bb-836c-2cba600fdeee/native.json` passes121 observations/702 current-preimage pins, SHA256 `82b3719d24e77d564587e9af3af56ee1f4b353384b0a24359246ce49a21f2c49`. Occupied original-candidate prestate `truss-binding-catalog-stage/aac9ca11-a9bc-4cff-8a76-217bc4ee2928/native.json` passes129 observations/702 pins, SHA256 `9662ff875ee2988d5bbc76b50d3e0ba84f868c7fb2e4c3c3e98c6b0500872566`. Original byte observation, six correspondence faults, complete-binding inventory/count refusal and exact rollback/cleanup remain intact. These installer-only native runs do not execute the Python extraction on a protected native transport or authenticate a normal caller; that composition still requires qualification. Earlier owner/native runs remain historical with their preimages after the deliberate source update.

US-056-AC1/AC2/AC10 gain component evidence only; acceptance remains26/132. Registered association interpretation/provenance, complete canonical key/incidence and protected mutation closure, authenticated original issuer/current-cut/report custody, final publication and other backend implementations remain required. Astra ultra independently verified the owner receipt's292 current/preimage pins,36 observations and50 captured test names/results with no blocking findings; review did not execute tests or native probes.

Astra ultra also verified both final native receipts:702 current/preimage pins each,121/129 unique matching observations, unchanged31 native SQL inputs, intended correspondence/privilege/complete-inventory refusals and completed cleanup. No blockers for this scoped landing; review was read-only.

## Pending binding provenance and report ordering — 2026-10-10

The native source observer and exact original mapping extraction expose an ordering obligation, not a reason to weaken `accepted_binding`. CONTRACT-001 roots that category in an immutable accepted report; current report preparation instead requires complete native inventory. Requiring an already accepted report before every binding-derived native definition, while requiring those definitions before producing that same report, creates a strict dependency cycle. The current implementation refuses present-binding report preparation and complete inventory; it does not implement this proposed protocol.

Select an explicit operation-local pending binding source state for the next layout/producer spike. A pending relationship is a real native definition with reserved native identity, endpoints and association property owner, but its source kind is an internal candidate `operation_binding`, never `accepted_binding` or `accepted_document`. Its provenance retains the actual writer/ordinal, unpublished revision, full original binding/input bytes and exact mapping pointer/fragment, with independent original association/target Record dependencies. It may be constructed only after registered vocabulary/owner interpretation and original authenticated operation admission. This state is not a new shared UMF semantic kind, ontology assertion or published catalog-view source category. Its native columns/checks, registered decoder and migration are unadopted layout work; the existing source union must not be silently reinterpreted.

The protected transaction sequence is: (1) archive original input/documents/binding and stage the exact pending physical association effects; (2) independently enumerate complete native definitions/endpoints/keys/property homes and all original dependencies at one generation; (3) produce and retain the complete immutable report describing those observed effects, original sources and registered interpretations; (4) resolve the actual report's acceptedInput.binding against the complete original archive, promote only matching pending source tuples to `accepted_binding`, and retain the same definition identities/endpoints/property homes; (5) freshly verify the complete final physical inventory, provenance closure and report correspondence at the resulting generation; (6) atomically publish the head and finalized operation. No ordinary catalog/read/mutation path may observe or execute a pending definition; neither publication nor transaction finalization may retain pending sources. Errors roll back the whole acceptance. A constructible preparation, returned mapping, report bytes or matching count cannot bypass these gates.

Report insertion and source promotion are real effects and may advance the operation generation. Final recheck must therefore acquire its own current cut after both; it cannot reuse the pre-report inventory cut. The immutable report describes semantic physical effects and exact original sources, not a claim that its own insertion or later source promotion did not occur. Final comparison must explicitly account for the sole permitted provenance promotion, verify every other definition/effect remains exact, and independently verify the report/input/binding bytes and registered profile. A hash/count-only comparison, normalized omission of unknown effects or fabricated zero inventory is forbidden. Any further catalog, authority or relevant data mutation invalidates the final cut until a complete fresh recheck; the host and native publication owner must enforce the same original operation/generation and required wait/drain protocol.

Implementation exits, in order: issue the exact pending native source tuple/layout through the owner-controlled schema/exporter and a closed language-neutral contract; implement registered original-source association interpretation and independently qualified native definition staging; implement a complete pending-aware physical inventory and report producer; implement immutable report correspondence and exact source promotion; qualify fresh final inventory/authority publication and ordinary-role closure. Every exit retains source/definition/cut evidence. This proposal selects the ordering, not owner registration, layout adoption or a functioning backend.

US-056-AC1/AC2/AC10 tests must cover the full positive transaction and exact native binding source/history projection, plus: stage accepted provenance before report; fabricated document provenance; omit/extra pending mapping or dependency; change key/role/attribute/home/endpoint under equal counts; substitute report/input/binding/profile; promote another writer/ordinal/revision; mutate after recheck; keep a pending source at head publication or commit; ordinary reads/writes of pending definitions; failure at each phase with complete rollback and source/history preservation. Original caller/issuer/current-cut and complete writer/privilege/cleanup/drain evidence remain required. Conditional solver results cannot close these native cases or promote the26/132 acceptance total.

## Conditional binding publication ordering proof — 2026-10-10

`tools/security/prove-binding-publication-order.py` retains14 original SMT-LIB formulas and independently parses/replays every formula with Z3 4.15.4. `binding-publication-order/fb3ebd52-120f-40e3-9d3c-7b47c1cf73e6/proof.json` passes8 UNSAT safety/incompatibility checks and6 SAT feasibility/weakened controls, with8 current source/preimage pins; SHA256 `619ddae6df8bf6faf7557c85bdfebadbde67774ce997d4786cf13e5627b24477`.

The incompatible strict order stage→inventory→report→stage is UNSAT; this is an excluded proposed ordering, not a claim that current code runs cyclically. The selected pending-source sequence has a SAT execution. Conditional publication excludes report/promotion/recheck order violations, reuse of the earlier report-generation cut, a later effect at publication and remaining pending binding sources. Full quantified native physical identity/value parity forbids extra, omitted or substituted effects; a weakened equal-identity inventory admits a changed value. Independent weakened generation, pending-source and ordering gates admit bad schedules. Original byte custody alone is compatible with absent authority/registration. The initial12-checkac7a9204 predecessor omitted the explicit pending-source law and used a weaker substitution premise; it remains historical with preimages, not current final qualification.

The model has fixed selected event families over unbounded integer order/generation and abstract full physical values. Original owner/issuer authentication, registered semantics, exact original/report-source correspondence, complete closure, monotone native generation correspondence and full physical inventory equality are explicit premises. It is not a native SQL refinement, concurrency/liveness theorem, formal JSON decoder proof or implemented report/promotion/finalizer. A native report insertion and provenance promotion may both advance generation; final publication must bind a fresh post-promotion cut. All unknown effects/profiles remain refusals. Native installation must independently verify the proposed internal source category/checks and exact permitted source promotion before any accepted-view admission.

This ordering is a backend compilation/acceptance obligation for both relational and graph mappings. The proposed internal `operation_binding` source tuple is a Truss layout candidate; it does not add a shared UMF semantic kind or impose Truss columns on Ashlar or other implementations. Their own pending effect/provenance mechanism must prove the same original-source, complete-effect, report, final-cut and publication requirements under their qualified physical controls. AC1/AC2/AC10 remain open; historical acceptance remains26/132.

### Exact head transition and post-head finalization obligation

The existing `runtime_observe_catalog_generation` observes the actual `schema_head` row update: it increments effect_generation and resets phase/readiness/sealed/application state. The proposed protected finalizer must retain this observer. The pre-head recheck only authorizes the exact original head transition; it does not authorize commit. Under the same original exclusive head/caller/operation custody, write exactly the selected old-head→new-revision transition, independently observe the actual generation increment and reset state, then run a distinct complete post-head verifier. That verifier checks the exact new head, immutable report/input/binding, fully promoted definition/source inventory, journal/feed/non-row effects, complete authority and zero pending sources, and establishes readiness/sealing/application evidence at the actual resulting generation. Commit/public disclosure requires that generation to remain current. A further relevant effect invalidates it; arbitrary late mutations receive no exemption.

For the formal selected single-head-row event, the head generation is the pre-head generation plus one. This correspondence is a declared native refinement obligation, not a universal assumption about a larger finalizer transaction: every additional observed journal/feed/catalog event must be completed and included before the post-head cut, with exact registered inventory/generation correspondence. The current `runtime_collect_new_core_catalog_inventory` rejects a head that has reached the candidate revision, so it cannot serve as this post-head verifier. The new finalization verifier and complete commit barrier must be implemented and qualified separately; the existing unconditional fail-closed barrier remains installed until that full replacement is ready. A phase flag or a report hash cannot substitute for it. Add native tests for the head-trigger reset, pre-head evidence reuse, an extra post-head effect, wrong old/new head, incomplete post-head journal/feed closure and failure after head update with full rollback.

## Reviewed final head-aware publication proof — 2026-10-10

Astra review identified two defects in the initial protocol qualification: the actual head observer increments generation and clears readiness, and the feasible SAT witness allowed an empty physical inventory. The final design requires a distinct post-head finalizer/verifier and preserves the unconditional current commit refusal until a complete replacement is qualified. The final model requires a present definition in its feasible execution, models the selected actual head event and post-head/commit generation cuts, and uses named guards so every weakened control erases exactly its intended guard while retaining the others.

Final `binding-publication-order/903fcd60-6635-4cda-8651-6879dac95dd2/proof.json` passes18 retained/replayed formulas:11 UNSAT and7 SAT, with10 current/preimage pins including the actual native catalog-generation observer and commit barrier. SHA256 `4183dd15fc92d980acedcab6d307684c01e5e0f5f41c01153af74dd59208a5e5`. Added laws reject a post-head check preceding the head event, reuse of pre-head readiness and an effect after post-head verification; the corresponding omitted commit-cut guard admits a later effect. The prior12/14-check receipts remain historical and cannot establish the corrected head-aware protocol. Existing registered/authority/source/full-parity/closure and native event-generation correspondence premises remain explicit. No native pending layout, report producer, promotion, post-head verifier, complete finalizer or backend acceptance is claimed;26/132 remains unchanged.

Astra ultra independently replayed all18 final formulas (11 UNSAT/7 SAT), verified10 current source/preimage pins and exact formula hashes, and confirmed the head-generation and populated/isolation findings are resolved. No remaining blocker for this qualified design/formal checkpoint; native refinement and implemented publication remain open.

## Native pending relationship-source tuple candidate — 2026-10-10

The fresh-layout adjunct `catalog-pending-binding-source-v0.1.proposal.sql` implements the selected internal `operation_binding` shape on generic `rel_def`, with no per-ontology tables/indexes. Five columns retain native writer xid8, operation ordinal bigint, binding revision int, C-collated original mapping pointer and exact mapping bytea. Native composite FK requires the referenced original operation row; the binding FK requires the original archive revision. The pending branch requires every field and association property owner, the same positive binding/creation revision, a nonnegative ordinal,1–4096 pointer bytes and1–1048576 mapping bytes. Accepted-document and accepted-binding branches preserve their prior predicates and require all pending columns NULL. The existing source-home legacy ordinal/FK interpretation is not replaced by this adjunct.

`tools/security/capture-pending-binding-layout.ts` uses the actual UMF PostgreSQL owner importer, retains the full native-source model, saves/reloads it and exports the SQL used by the native test. Native source, saved model and owner-export SHA256 are respectively `5242d6cc5c77ac0f88184e74fc7af5369254a4aa9f1c057292b048e641c23d76`, `667cb771d1a56c0b464527e88f26d590d59008b3e7a75d6ee5ded3d7f5157cff` and `183abbb3884210ca18c967351ea3352399468970fde9f5a447234ac8a4f9ee45`. The retained capture receipt pins five owner entry sources and Bun1.4.2; it is original-source/saved-export correspondence, not complete dependency/toolchain custody or portable semantic extraction. Preserve its raw native extension/unknown content. This is not adopted installation or populated conversion SQL.

`tools/security/truss-binding-catalog-stage.py --pending-layout` installs the exact owner-exported adjunct in isolated PostgreSQL16.15. Excluded installer tests insert a structurally complete pending row using actual operation/type IDs and the original fragment from the qualified source-extraction receipt; they independently read native column types/C collation, exact tuple bytes and the generation observer increment. Named23514 CHECK controls reject each missing field/property owner, NULL/unknown/premature source kind, mixed document/binding tuples, empty/oversized pointer/fragment, nonpositive revision and negative ordinal. Named23503 FK controls separately reject absent operation ordinal/writer and original archive. Each previously valid accepted-source branch independently rejects each single added pending field. A separate excluded installer document fixture makes the legacy since_rev/doc_ord FK valid at revision zero, isolating positive pending archive revision versus a different valid creation revision; the exact source-completeness CHECK rejects it. All injections and attempted rows roll back to complete document/key/relationship/endpoint/archive/operation snapshots; the archive immutability guard is ALWAYS before its missing-archive probe and after restoration.

The archive FK refuses plain truncate with0A000 before the immutability trigger; a separate cascading attempt reaches that trigger and receives its intended55000 with zero effects. Ordinary SET LOCAL ROLE cannot read/insert pending rows (42501); this is not authenticated login or complete callable/privilege closure. Complete binding inventory remains0A000 and the schema-qualified existing deferred commit barrier remains55000 `complete runtime finalizer is not installed`. That unconditional barrier is not a pending-specific finalizer proof. Original accepted-branch positive fixtures prove shape preservation only, not accepted report provenance.

Final occupied-prestate `truss-binding-catalog-stage/15e512a9-2eab-4cd7-9951-09772ce37125/native.json` passes214 observations/711 current-preimage pins, SHA256 `784a2506fb4c1847eec206fb6e380cfbcf08799f465660dfb6c3e44146c3186a`. Fresh pending layout `dfcb2f45-8e57-48f3-bc8e-2c3791c668a0/native.json` passes206/711, SHA256 `2f9db9808d3d9b4aa492d382943d430ed7a5c0f012d28989f1631ad76bb807b7`. Unchanged original layout `2b0fd119-80c6-44a0-a527-510b53d104f2/native.json` passes121/702, SHA256 `c582c9f06dcfba6bd8be0237cbbe958fb9a0312c245ab8104210cf197378d6e7`. Exact source ZIPs, observations and required cleanup are retained. Development failures7bd1f91a (new FK refuses truncate before trigger) and9bcdbfaa (unqualified constraint name resolves nowhere) are retained failures, not passes; ba237cd9/1ff1b251/95ef117c/f4382068 predecessors lack final native readback or isolated controls and remain historical with captured preimages.

FK/shape evidence proves referenced row existence and completeness, not that the operation is the authenticated current writer/cut, its kind/phase is admitted, the archive writer/input agrees, or the pointer/fragment represents registered semantics. Existing admitted helpers do not stage or interpret this pending source. The source observer's authored-core inventory cannot be reused unchanged once a binding-derived relationship is staged; the registered pending-aware inventory/source verifier must independently account for it without fabricating an authored relationship or weakening completeness. Whole pending artifact/operation aggregate resource budgets, full lifecycle/history/promotion, protected ordinary API, native key/incidence/attribute closure and post-head publication remain required. US-056-AC1/AC2/AC10 gain component evidence only;26/132 remains unchanged.

Astra ultra independently verified214/711,206/711 and121/702 matching observations/current-preimage pins, exact ZIPs, original accepted predicates, NULL-safe pending separation, isolated revision equality, full restoration and required cleanup. Both requested control refinements are resolved; no blocker for tuple/FK shape only. Review was read-only and did not execute native probes.


## Original ontology closure before pending staging — 2026-10-10

The private Truss0.1.0 binary association carrier supplies only an ontology digest/revision, leaving its original ontology outside the native archived input. Select a distinct private0.2.0 carrier embedding a closed ExactArtifact ontology (`identity`, canonical `bytesBase64`, `sha256`) alongside existing original source digests/revisions/mappings. Exact original core is already in AcceptanceInput documents. No legacy source is silently upgraded; archive-only recovery refuses0.1.0. This is Truss correspondence metadata, not new UMF core meaning, registered semantics or authority. The recovered ontology still needs genuine owner validation, original revision/model correspondence and full mapping coverage.

Private source tests cover exact original formatting, missing/extra artifact members, malformed/noncanonical encoding including nonzero pad bits, original substitution, corruption, identity/size bounds, legacy archive refusal and unchanged semantic mapping checks. Whole original binding remains1MiB, limiting embedded ontology capacity; a matching digest does not admit a resource or operation. Retained local Truss evidence records62 passing Python3.11.17 tests (50 legacy,12 new) and288-import boundary checks with exact changed-source ZIP readback/logs. These are entry-source checks, not installed-wheel/native custody. Owner qualification and native archive composition must be refreshed against the changed module before pending staging. US-056-AC2/AC10 gain no completed backend criterion;26/132 remains unchanged.


### Refreshed original-owner and native carrier evidence

`association-owner-interpretation/8ed0ba2a-6fb7-407a-a6db-c9fa4e487551/receipt.json` passes38 observations/301 current-source pins, SHA256 `dc3100cde30534c65e8d16687e3c3f97429dacca1ff8f0bf5cfa89b5d1c2be36`. It executes captured source with a fresh locked offline Weft build, the original UMF owner bundle and both private test classes62tests; recovered ontology bytes equal the unchanged original owner input exactly. Its original core/ontology digests, explicit0.2 binding and exact mapping fragments are retained. Artifact identity remains a label; whole owner registry dependencies/toolchain are not archived, so this is not hermetic or authenticated owner admission.

Fresh isolated PostgreSQL16.15 pending-layout carrier run `truss-binding-catalog-stage/710573f9-9a1c-46da-8c43-7b383238ec51/native.json` passes206 observations/711 pins, SHA256 `f404271f85480eb5fd4f183f4b3b0b8ac365dc52629e8ffc75d38867d9456647`. Occupied-prestate `d29befac-1e58-4132-893d-729ce1ab2fb3/native.json` passes214/711, SHA256 `67422da3fd07a51095b1945948b8ddb53f328e7330ea0cf4a9594e22a86b558e`. Both retain exact source preimages/native readback/control restoration and completed required cleanup. Native SQL is unchanged: it preserves original full carrier bytes and tuple/FK shape but does not decode/register ontology semantics. Complete present-binding inventory remains0A000 and the unconditional commit barrier remains55000. Previous receipts retain their original captured qualification and are not current-source evidence for this changed Python module/harness. Pending registered staging, semantic native key/incidence/property closure, complete reporting/promotion and post-head publication remain next; no acceptance promotion.


## Native exact original mapping extraction — 2026-10-10

The ontology-dependency carrier alone does not prove a native pending row retained the original mapping selected by its pointer. The private `catalog-binding-mapping.sql` component now supplies an exact UTF-8 byte slicer and a separate operation-linked collector. The pure extractor accepts bounded unique-member JSON objects, canonical `/mappings/n` pointers with index0–4095, and a selected object value; it returns the original byte slice without JSON/JSONB reserialization. Escaped root member names are decoded for lookup. Multibyte values, escaped quotes/delimiters, whitespace, member order and extreme uninterpreted numeric spelling survive unchanged. It validates original syntax and duplicate member names including nested/escaped aliases. It does not validate the binding vocabulary, every mapping object, ontology semantics, keys, authority or an accepted report.

An explicit1MiB/null admission check precedes one whole-input lexical scan and PostgreSQL JSON parsing. At most32 nested containers are permitted, counting the root object as one and the mappings array as another; strings/escaped braces do not count. This native lexical-container bound is separately qualified, not a claim of identical Python node/depth accounting. Byte offsets use bytea/get_byte, preserving exact UTF-8 source bytes. Allocation/work/deadline and operation aggregate accounting remain separate. The private value-end helper is meaningful for already validated JSON boundaries; the full extractor establishes syntax/uniqueness independently before returning a fragment.

`runtime_collect_original_association_mapping` first calls the unchanged original binding observer, retaining actual operation/archive/input/document/core inventory checks. Both original owner-qualified mapping fragments match native outputs before pending effects. A real excluded installer pending-row insertion makes this collector refuse55000 `unique original declaration required`; it cannot be reused after pending effects, because the current collector expects authored-core relationships. Pending-aware registered interpretation/inventory remains required. Every new routine is INVOKER, has a fixed search path and is revoked from PUBLIC; ordinary helper/collector denial is qualified through SET LOCAL ROLE only, not an authenticated installed callable closure.

Final PostgreSQL16.15 fresh pending-layout `truss-binding-catalog-stage/408708d1-92ee-43f1-bcf0-c2c83c3b6275/native.json` passes254 observations/712 source pins, SHA256 `ccde4637af80524535d3ab88680cf8e5c4e8fa6196c2bf2bdb04e983436345ec`. Occupied-prestate `78218f40-ab78-4329-a729-c7fe7d6434d7/native.json` passes262/712, SHA256 `6954187077546876184e310c09cc98d7cfd5c98c717afdaf519a39733ab16540`. Both retain original source ZIPs, exact results, refusal/zero-effect/restoration controls and completed required cleanup. Positive boundaries include1MiB, index4095 of4096 entries and exact whole depth32 before/after the selected mapping and in a later mapping. Negative controls cover duplicate names, malformed/missing/wrong arrays, absent/non-object selections, canonical pointer/index violations,1MiB+1 and whole depth33. Matching syntax/source checks do not prove formal native refinement of the scanner or native graph policy behavior.

Astra found that the initial selected-prefix scanner left deep suffixes unbounded. The correction scans the whole root before parsing or selecting; all exact boundary/suffix controls above execute. Earlier eafc7f59 (239),f91f9d0d (246) and90c4a3d6 (252) retain their captured passes only: they predate the final whole-input correction or exact suffix positives and are not current qualification. No installed profile, registered pending producer, report/promotion/publication or acceptance criterion is promoted. US-056-AC1/AC2/AC10 gain source-component evidence only;26/132 remains unchanged. Next implement native dependency correspondence and the registered pending batch producer with original authority and a pending-aware inventory, then compose complete reporting/promotion and post-head verification.

## Original-source private association staging candidate — 2026-10-11

The private PostgreSQL16.15 candidate stages two original binary associations as generic pending rel_def/rel_endpoint metadata, deriving Record owners, ordered fields/keys, role orientation, all storage values and exact mapping fragments from the archived original input. It retains association properties without fabricating authored lineage. Whole-source validation runs once before the ordered exact-byte batch extraction; 4096 mappings pass and 4097 or a later non-object refuse atomically. Original ontology parsing keeps unknown huge numeric content as JSON/original bytes. Typed role/key guards and complete entity/association reference inventories reject aliases, duplicates and malformed unused dependencies.

Final merged-main native receipts under `truss-binding-catalog-stage/`: `0c0f6dba-26cc-4117-8132-9afae1196a41/native.json`: 316 passing observations/713 captured source pins, SHA256 `cda618d1108c041604f9839d08a6d6028b13b229f6c32bf97b1ea73018fc238f`; `7b354d91-ad12-417c-97e6-01ba815e3f40/native.json`: 324 passing observations/713 captured source pins, SHA256 `ab7ef2da6640a685baa0ee18f6e5f42b50c558ec46db548c358624baf35b6ac6`. Fresh and occupied runs retain source ZIPs, exact native readback, eight-component restoration snapshots including lineage, ordinary-role denial and required cleanup. Paired source controls restore the exact operation guard before probing and are excluded installer mutations, not newly owner-issued meanings. Development failures365880f5 (pending-trigger ALTER refusal) and04eec4d9 (native escaped-NUL parser mismatch) remain retained failures; earlier passing receipts are captured predecessor evidence.

This is an unregistered installer candidate, not an adopted layout or protected producer. Native field arrays are limited to256; ontology escaped NUL receives explicit0A000 unsupported-parser refusal while original bytes remain intact. Complete binding inventory still refuses0A000; repeated staging refuses55000; the unchanged unconditional commit barrier refuses55000. Accepted association lineage/history, registered semantic authority, authenticated callable closure, data key/incidence/attribute enforcement, shared aggregate resource accounting, complete reports/promotion and post-head finalization remain open. No whole private0.2/native equivalence or native refinement proof is claimed. US-056-AC1/AC2/AC10 receive component evidence only; acceptance remains26/132.

## Post-stage original source custody candidate — 2026-10-11

`runtime_collect_pending_association_source_candidate` observes pending source custody after actual staging without invoking the authored-only relationship inventory. It requires the current admitted operation, held head exclusion, an existing unpublished revision, exact original input/archive writer/vocabulary/artifact/digest correspondence, original document carrier correspondence and native document integrity. One whole-source mapping batch establishes a complete one-to-one pointer/fragment cohort; every matching pending row retains the current writer/ordinal/revision and exact bytes. Returned mapping digests and the observed generation are component observations, not durable readiness or finalization certificates. Missing/duplicate pointers, byte substitution, an independently valid extra pending row, changed original document metadata and another revision refuse with zero observer effects; ordinary invocation is denied. Eight-component restoration includes lineage.

Final PostgreSQL16.15 receipts under `truss-binding-catalog-stage/`: `428d4fae-c838-4ebd-904b-d12448d47564/native.json` passes338 observations/713 source pins, SHA256 `8fb832c6258f4be67eba63cb5a8e313d35dab56a6b90b04e0f91be587b9d9e45`; `fb8dd6bc-3dab-4ec4-9439-5ec9d4911c04/native.json` passes346 observations/713 source pins, SHA256 `cd136ccd8f79f35ceca8809cd85c1fdd2ba813ddbe5637f82d331a71b798141d`. Source ZIPs, native executions and required cleanup are retained. Predecessors7baac25f/95bfe724 (334/342 observations) lack the independent extra-row control. Predecessor3d7bab6d (331 observations) preceded the original document carrier recheck and is historical only. The observer does not validate relationship storage/endpoints/property/key semantics, original operation issuer/cut, accepted lineage, full core/effect inventory, native data constraints or publication. Full binding inventory and commit barriers remain closed. US-056-AC1/AC2/AC10 receive custody component evidence;26/132 acceptance remains unchanged. Next compose registered source/semantic interpretation and pending-aware complete effect verification; this observer must never substitute for those gates.

## Original pending metadata effect verification candidate — 2026-10-11

The native source resolver now derives original association metadata without insertion; the allocator consumes that result and retains original source provenance. The private effect collector composes the independent exact source cohort with the original Record/Field/Key and authored-core correspondence checks, then compares each full native relationship row against the source-derived row, excluding only the allocated ID and separately verified pending source members. Accepted-source columns, retirement, namespace, owner, name and all storage fields must match; each relation has exactly one correctly oriented endpoint and no fabricated lineage. Existing pre-stage core inventory remains pending-refusing; its new internal core-only mode is not a registered complete effect inventory. Ordinary effect invocation is denied. Full registered inventory still refuses0A000 and finalization55000.

Final retained PostgreSQL16.15 evidence: `truss-binding-catalog-stage/460762fd-b4d0-462e-9be1-545ebc09a813/native.json`: 371 passing observations/717 source pins, SHA256 `69dc7d64afe943b2e818e7047a2f9dd9c04ae91a684c8e7466f3fede62b43308`; `truss-binding-catalog-stage/18458931-eb83-48d4-a847-c1502f96056a/native.json`: 379 passing observations/717 source pins, SHA256 `6c73d00a899ffc8c66376b4091c138b94063ac8b72bf4d76df8ab80c53259d3b`; `truss-owner-catalog-stage/748beedb-0438-4d55-a1ab-deb7c2873ebe/native.json`: 34 passing observations/702 source pins, SHA256 `324a7fc2f22fb93ccc9c561d584219f0164594838ff7b81bbbd20f63a3a5df87`. The absent-binding regression has5 Records/9 Fields/5 Keys and0 relationships/endpoints; it does not supply positive authored-relationship coverage. Candidate controls independently mutate storage, association owner/name, orientation, endpoint absence, an extra valid endpoint, a valid fabricated lineage row and original core field metadata. The latter two structural injections preserve source-custody success while effect verification refuses. Ten-component restoration includes actual types/properties and lineage. Original late mapping/type/inventory/custody controls remain.

The combined verified inventory is assembled in deterministic order and source-inspected code checks16384 rows/1MiB before emitting it. Exact combined row/byte threshold execution is still required; the current cohort does not prove those boundaries. CPU/deadline/allocation/shared operation budgets remain open. Both harnesses use a single-handle pgserver subclass with private mutex/socket directories and unchanged installed startup/cleanup methods. Three captured pgserver implementation files are observed runtime-source premises, not a hermetic frozen-module/toolchain proof. Failed predecessor091fa928 completed362 observations but failed current-source pins after concurrent edits; cleanup was interrupted waiting on the shared pgserver mutex, then its exclusively owned postmaster, temporary/socket directories and execution copy were cleaned separately. Failure and exact preimages remain failures, not promoted evidence.

Astra ultra independently audited final observations/current pins/exact ZIPs/cleanup and resolved extra-endpoint, fabricated-lineage and property-restoration coverage gaps. This is private new metadata-effect correspondence, not registered ontology/policy authority, admitted lineage/history, native key/incidence/attribute data enforcement, complete report/promotion/post-head verification or installed ordinary closure. Positive authored-relationship and composite ordered-key controls, exact combined boundaries and full backend execution remain open. US-056-AC1/AC2/AC10 receive component evidence only; acceptance remains26/132.

## Authored relationship and pending association coexistence — 2026-10-11

The original captured UMF preparation path validates an explicit installer source fixture adding the authored `WorksWith` relationship (Staff→Project). Only the binding core digest is updated; original mapping fragments remain unchanged. Native staging preserves the authored definition, endpoint and exact lineage at ID 1, allocates pending associations from actual prestate at IDs 2/3, and includes all three relationships in the private combined metadata inventory. An independently altered authored definition receives 55000 and ten-component restoration retains types/properties/lineage. Later shape-only fixtures now allocate an unused native ID rather than assuming 1. This is actual UMF validation/native staging of a synthetic authored coexistence fixture; Weft is not rerun and no newly owner-issued ontology handoff or authority is asserted.

Retained PostgreSQL 16.15 evidence under `truss-binding-catalog-stage/`: `0dabc8f0-1ac1-49f2-82b5-0ad39b2fef23/native.json`: 375 passing observations/717 captured source pins, SHA256 `7b041c8bedc23246d42b6cf1590f16601b15f3d1e0436f384ec24767c65fd2f1`; `79ad184b-24b6-4128-973f-68cf599363bd/native.json`: 383 passing observations/717 captured source pins, SHA256 `46a359e8ec179d0f25c87d08aace4a3e03625eb5249a8d0bc47a246f0aee1cef`; `e8dc8cbd-321e-4c20-b5ff-1e5928942b27/native.json`: 371 passing observations/717 captured source pins, SHA256 `0cd4fd9b9171a5108aa523e88427dbe09bc893ad324077f72912c33950186fd2`. The first two cover fresh and occupied authored coexistence; the third is the original fresh regression. All required cleanup completed. Astra ultra independently audits observations, current source pins and exact preimage ZIPs. Concurrent Truss main commit d80b50b3 changes Python issuance outside these captured source premises; these receipts do not qualify that new path.

Failed predecessor 1c989862 used stale candidate IDs; f5163a91 collided with authored ID 1 in the later raw shape fixture. Both remain failed evidence. Parallel occupied run 3ea8a698 failed native startup because macOS shared-memory IDs were exhausted; the sequential occupied retry passed. No unrelated database processes were altered. The fixture adds positive authored relationship coverage, not composite ordered-key or exact combined inventory threshold execution. Registered policy/ontology authority, accepted association lineage/history, protected callable closure, native data constraints, complete reports/promotion/post-head finalization and broader backend suites remain open. US-056-AC1/AC2/AC10 receive component evidence only; acceptance remains 26/132.

## Ordered composite endpoint correspondence — 2026-10-11

The native harness now supplies an explicit composite-key source fixture: Staff.pk is [staffId, staffTenant], Assignment.pk is [assignmentStaff, assignmentStaffTenant, assignmentProject], and the classified ontology fields, Staff endpoint and mapping have matching two-component sequences. Both new fields remain required single string values. Actual captured UMF preparation validates the modified core before native staging; the ontology and mapping are synthetic installer inputs, not a newly Weft-issued handoff or registered owner meaning. Exact serialized mapping fragments are retained and checked against native readback.

Reversing only associationFields refuses 55000 original endpoint correspondence; reversing only targetFields refuses 55000 original ordered target-key correspondence. Each control then erases precisely one native resolver comparison to bidirectional containment and succeeds through actual staging with both expected allocated IDs and exact native source fragments. Savepoint rollback restores all ten state components and the exact resolver function definition; the identical reversed input refuses again under restored code. These are concrete native order-loss counterexamples for this two-component cohort, not a general logical/compiler/SQL refinement proof.

Retained PostgreSQL 16.15 final evidence under `truss-binding-catalog-stage/`: `fab4bfbb-dbd3-45bc-82bb-f04c1b196de4/native.json`: 399 passing observations/717 source pins, SHA256 `b5e0738954e7633ba2baad0c3d63578b49cd33c6893e60aea0e022d2e2f59cbf`; `c6c608b8-8804-4ea8-a874-b79c9e135ef9/native.json`: 407 passing observations/717 source pins, SHA256 `c212ca3f07e32f8604d3713e5ec0397d0354edfa37faefbae853dbf87d014acf`; `fb84da8e-bf04-4d71-837c-e0c4232a51c4/native.json`: 371 passing observations/717 source pins, SHA256 `a61353d511a5e0a5ed1f04b2d28e0e112682d507b138c89ef78eff56f77b005a`; `c4f29e34-338a-4a73-a286-d930cce8390b/native.json`: 395 passing observations/717 source pins, SHA256 `8398bfa8697a4cfbc1b16858f42080a0e1507fc0726eeb8b7d452c2ddc4778dc`. Respectively: fresh authored+composite, occupied authored+composite, original single-field regression, and composite without authored relationships. All required cleanup completed. Astra ultra reviews the source and independently audits final observations/current pins/exact ZIPs. Earlier 69eb4ff4 passed 385 before adding mutants and is predecessor evidence. Failed 96a44502 timed out during initial layout installation before semantic controls; failed 391e9e22 encountered missing parentheses in the excluded JSON containment mutant. Both are retained failures, and production SQL was unchanged.

This closes the positive composite ordered-key and separate reversal coverage gap identified by Astra. Native key encoding, per-field incidence constraints, shared resource budgets/exact combined inventory thresholds, authenticated subject/owner admission, registered complete inventory and accepted association lineage/history, protected callable closure, data enforcement and complete report/promotion/post-head finalization remain required. US-056-AC1/AC2/AC10 gain component evidence only; overall acceptance remains 26/132. The native candidate remains unregistered and the complete commit barrier stays closed.

## Value-bearing native metadata image — 2026-10-11

The private PostgreSQL `runtime_collect_pending_association_value_candidate` composes the original source/semantic effect verifier with a full physical value for every verified new type, property, key, relationship and endpoint identity. Relationship values include the entire definition and authored lineage row, with null lineage for pending associations. Full native rows retain pending original fragments and provenance; this is a five-family new metadata image, not a complete physical database or accepted report. Exact image identity bijection and an unchanged original operation generation are required before return. The output is explicitly ordered under C collation. Function-local `bytea_output=hex` removes the caller-setting dependency and automatically restores the caller configuration; it is not a general canonical cross-version report encoder. Original document/input/binding byte custody remains separately required.

Independent direct native readback reconstructs all value rows, including lineage. Positive readonly generation, native row order, caller escape-output invariance and caller-setting restoration pass. The eight existing storage/owner/name/orientation/missing-endpoint/extra-endpoint/fabricated-lineage/core-field corruptions also refuse through the value collector with zero effects. An excluded installer effect-observer mutation changes exactly one emission site to increment the current operation generation; the value collector reaches its specific 55000 generation-changed refusal, full ten-component state and exact function restoration pass, and the restored positive image matches again. This isolates the generation branch and does not establish concurrent writer or complete observer closure.

Final retained PostgreSQL 16.15 evidence under UMF `truss-binding-catalog-stage/`: `e3f53aa5-823f-4284-9d6f-1736481d4068/native.json`: 430 passing observations/717 source pins, SHA256 `266899a98b16866bf114ce3d91f4840ce7190329b33671d60fa03163c0a1bce7`; `b702b3f2-b8ad-4883-bb51-4bdecdb29e63/native.json`: 438 passing observations/717 source pins, SHA256 `c77ffdd34fb04a25281820cdc6c36cd52323499a322deb5b353046013565b8a6`; `9e6039d1-2c9c-4460-91cc-de46343fbfc4/native.json`: 402 passing observations/717 source pins, SHA256 `a912f09dd35ae9f5c7297887250caa4f6f928d3f43e31a614b66434b63cadb84`; `e4ad6de0-006b-42ab-9fc8-a802f7f89963/native.json`: 426 passing observations/717 source pins, SHA256 `cae2d5b7ee83d1d1f955e72ab88f2af548d92d2be04d7ce7bfbd04e2339df306`. Respectively: fresh authored+composite, occupied authored+composite, original single-field/no-authored regression, and composite-only/no-authored regression. Required cleanup completes in all four. Astra ultra reviews source and independently audits observations/current pins/exact preimage ZIPs. Predecessor e9506a23/3a34c08a (420/428) predate explicit order/GUC correction; de80e268 (424) predates the generation-change control. They retain captured passing evidence only, not final-current-source qualification.

Code checks 16384 rows/1MiB of serialized image before return. These bound returned image size after aggregation/serialization, not heap/CPU/deadline; exact threshold execution and enclosing shared resource accounting remain open. This implements a value-bearing metadata observation prerequisite for future report correspondence, not registered ontology/policy authority, authenticated owner/issuer/current-cut, accepted lineage promotion/history, protected callable closure, native business-key/incidence/attribute data enforcement, complete report persistence, source promotion or post-head finalization. Registered complete inventory remains 0A000 and the unchanged commit barrier 55000. US-056-AC1/AC2/AC10 receive component evidence only; acceptance remains 26/132.


## Original-source report basis candidate — 2026-10-11

The private PostgreSQL 16.15 report-basis composer retains exact original operation input and binding bytes, full document rows and the verified five-family native metadata image, alongside actual writer/ordinal/generation/revision coordinates. The explicit profile is `truss-pending-association-report-basis-candidate/0.1.0`; `acceptedReportQualified` is false. A second complete value/source observation compares the full operation, binding, documents, image and generation before return. The private rechecker requires exact byte equality with a freshly collected basis. Both invoker routines have fixed search paths and PUBLIC execution revoked.

Retained final evidence under `truss-binding-catalog-stage/`: fresh authored+composite `414ab7ba-fe6f-4c81-b136-2a1314357ca2/native.json`:478 observations/717 captured source pins, SHA256 `9397a4c956aad0f909b53166ead60455707bfbf214eadd06ad96ae8dab804335`; occupied counterpart `c1c09818-788b-46fd-b4b2-433fb7a78dea/native.json`:486/717, SHA256 `3babec09e262143b40df83fda5c1003ad69fcc9b993c62cd8af7ddbf787e14f8`; original single-field regression `a3ec9ea0-b48d-4e77-9969-e8aed6671963/native.json`:450/717, SHA256 `93887690800e75581e7f6112b6bed98fd2a62a5466f75a7c8d4df40a0245ec7a`; composite-only regression `1119762c-d289-40f6-9792-46c06d5a51f5/native.json`:474/717, SHA256 `401fea9424cedb4da22d13e007c82551ce9840ba8969b1d5c7aa0210380c5277`. Exact packets/profile/digests are retained in each `report-basis.json`; exact source ZIPs, type-sensitive observations, source preimage matches and required cleanup pass. These execute the captured sources; concurrent Truss main Python reserved-control/retirement changes 8cbcc8c4/7a21a1b2 are not newly qualified by these receipts.

Controls cover fresh correspondence, byte substitution, empty/null arguments, generation changes, ordinary invocation denial, and exact restoration. An isolated internal value-collector mutation advances generation after its own final check; the composer reaches its specific generation refusal. A coherent original input/binding change preserves mapping fragments, native values and generation inside collection; the full-operation comparison refuses. A separate ABA fixture produces a valid new basis at the same coordinates while the old bytes refuse; rollback restores the original positive. These are excluded installer mutations, not authenticated owner issuance, real concurrency or complete observer closure. Astra ultra independently audits source, exact packets, observations, pins/ZIPs and cleanup; its retained review is in the occupied final directory.

The 8MiB output cap is checked after serialization; emitted exact output thresholds, allocation/CPU/deadline and shared operation budgets remain unqualified. Rechecker arguments exactly8MiB reach correspondence refusal55000, while8MiB+1 receives bounded-argument22023; these execute argument preflight only. Predecessors eceac6ea/58bbd9ab (463/471) lack final exact packet retention and generation/argument controls. Failed7dc07272 is retained: native void returns an empty string through pg8000, and the initial host expectation was corrected. Neither predecessor nor failure substitutes for final evidence.

US-056-AC1/AC2/AC10 gain component evidence only; acceptance remains26/132. The candidate is unregistered and the layout unadopted. Complete accepted-report encoding/persistence, registered ontology/policy authority, authenticated owner/current cut, native data key/incidence/attribute enforcement, accepted lineage/history, source promotion, protected callable closure and post-head finalization remain required. Complete binding inventory remains0A000; the unconditional commit barrier remains55000. No formal SQL refinement or whole-backend security completion is claimed.


## Selected report-basis formal correspondence — 2026-10-11

`tools/security/prove-report-basis-correspondence.py` analyzes exact selected input/binding/document carriers, complete operation rows, writer/ordinal/revision/generation coordinates, identity sets and full native values over unbounded uninterpreted carriers and metadata arrays. Final `report-basis-correspondence/195e439a-d2eb-4374-a123-8868fe55559f/proof.json` retains18 checks, independently parsed/replayed in fresh Z3 contexts, and7 source preimages; SHA256 `0afb9117e16ebccb40aeaf37932e639e30524652e1020dd1bb414c177437834c`. Astra ultra independently replays all18 original formulas (5UNSAT/13SAT), verifies their hashes and all7 current/preimage pins, and resolves its model adequacy findings; its review is retained with the final proof. Exact selected equality excludes source/value/coordinate drift conditionally. SAT controls show generation-only equality can hide coherent source substitution, identity equality can hide full-value substitution, and weakened source/full-operation comparisons admit their corresponding drift. The full-operation guard explicitly includes input/generation/writer/ordinal equality plus remaining opaque members, so input and generation omission controls also remove the redundant full-operation guard. Value equality is quantified only over selected identities; every value-drift witness must be selected. The positive execution has nonempty selected metadata and valid operation coordinates. Exact encoded equality excludes drift only under an explicit codec-correspondence premise for the packet projection only; full-operation equality is a separate composer check and is not encoded in the packet. A SAT control retains exact abstract packet equality while remaining operation members differ. Without codec correspondence, an abstract encoding collision remains satisfiable. This does not prove the PostgreSQL JSON codec or SQL refinement.

Endpoint comparison alone admits an intervening changed-and-restored source. A strict generation increment for every relevant change plus a monotone tail makes an equal-generation changed-event witness UNSAT; removing monotone closure admits a hidden reset. Required implementation obligations are therefore complete event observation, protected generation writes, immutable original byte custody, and a held exclusion that covers the selected state. The existing private ALWAYS guards/observers and native mutation controls are component evidence; full installed observer/privilege closure and concurrent execution remain open. A report-basis byte comparison must never be accepted as owner authentication, registered semantic authority, a readiness token or a substitute for post-head verification.

Predecessors bfd28549 (15 checks) and38eb64f0 (17 checks) retain captured formulas only. Astra identified that their value witness could be outside selected metadata and that their codec premise overclaimed full-operation coverage. The final model fixes both and uses selected-membership parity, explicit operation-field redundancy and exact packet-projection scope; predecessors are not qualified selected-basis proofs. The final analysis is conditional logic over the listed carriers, not arbitrary database execution, complete physical inventory, resources, persistence/promotion or publication. US-056-AC1/AC2/AC10 receive formal prerequisite evidence only; acceptance stays26/132. Before opening report publication, require a codec correspondence argument with collision/loss controls, complete protected observer closure, original registered authority and the distinct post-head/final-commit checks. The next implementation remains full original report composition and retained report correspondence; existing inventory/commit refusal gates stay closed until their complete requirements pass.


## Original host/native pending report-basis integration — 2026-10-11

The private `catalog-pending-report-basis.ts` helper connects original UMF preparation to the pending native report-basis candidate. Before collection/use it requires the recognized preparation and exact native admitted input bytes. It retains the native hex string unchanged in a frozen handle, with original connection/preparation/revision/bytes in a private WeakMap. Native exact current-basis correspondence is rechecked before returning the handle and again on use. The helper does not parse/reserialize native documents or values, register a profile, encode an accepted report or grant readiness. The caller-owned trusted driver/transaction remains a premise; connection object identity is not authenticated database actor identity.

The existing captured Bun installer bridge now stays alive after original core staging; after actual Python/native pending staging it executes collection and recheck on the same connection, original preparation and actual revision. Native readback equals the returned exact host bytes. Copied handles, changed connection objects, unrecognized preparation copies and a distinct recognized preparation with identical original bytes refuse. Primitive revision admission precedes coercion/SQL; numeric, boxed-string and throwing coercion-hook inputs each refuse with zero SQL calls. The same host handle rejects a real native generation change with55000, then passes after savepoint rollback; later independent full-state/generation/image observations confirm restoration. Nine hostile driver-result shape controls separately reject missing/duplicate/null rows, extra columns, uppercase/odd/nonhex/empty hex and a hex result exceeding16MiB. Each starts with the actual native original-input check; substituted driver results test shape admission only, not a malicious-driver authority boundary. All native stale-source/generation/value/order/corruption controls still execute.

Final PostgreSQL16.15 receipts under `truss-binding-catalog-stage/`: fresh authored+composite `fba89f21-7726-4437-a670-4b639df1e526/native.json`:485 observations/718 source pins, SHA256 `de5a55c598a3d2bee22a97b0729661bc3a8ac104178d7db8464f2308d01d190a`; occupied `4d16170c-76e8-41ac-994e-ccc46f447efd/native.json`:493/718, SHA256 `f48004882ac8d1f61d40adbc28520d05da86031dfa06052166cf7a426bb50c57`; original single-field `a52d6673-2855-40f7-a3f6-69f12818e6da/native.json`:457/718, SHA256 `b9e342a06fcb5c5b586b039aa7b5aa00465074d67a32629a15a5fdf7f363e463`; composite-only `eeafdfeb-71ee-4941-9d74-8c348ab21930/native.json`:481/718, SHA256 `fb91197359cda76ce6642a16878f47d5acf38b229be251fa77c9f1ee6dca3c05`. Exact packet files, native query outcomes, exact ZIPs/current source pins and required cleanup pass. Predecessor7b2a40bd (482/718) predates the malformed-result controls and simple hex scan and remains captured predecessor evidence. The intermediate483/491/455/479 receipts7b6036a0/5b2fdd64/84abe8ff/f92758c2 predate the primitive revision fix and final host stale/recognized-preparation controls. Astra found that coercion could admit a mutable revision object; final code requires a primitive string before regex/BigInt and resolves that finding. Intermediate typecheck5b2 also qualifies its captured helper preimage only. The occupied directory retains strict TypeScript `typecheck.json` and Astra ultra review. The initial typecheck omitted explicit Node/Bun ambient configuration and failed on unresolved names; the declared isolated strict check passes final corrected helper source. Ambient dependencies/compiler are observed local premises, not a hermetic toolchain.

The fixture exercises packets under the bridge's existing1MiB response line limit; it does not qualify transporting an8MiB packet or aggregate resource accounting. Native SQL, layout adoption and refusal gates are unchanged. Full original report composition must still combine registered owner/semantic/profile/execution evidence, complete source/value correspondence and report-field producers before persistence and provenance promotion; full installed observer/privilege closure, business-key/incidence/attribute data enforcement and distinct post-head/commit verification remain required. US-056-AC1/AC2/AC10 gain integration prerequisite evidence only; acceptance remains26/132. The goal remains full backend acceptance, not private report-basis completion.


## Full-operation report-basis custody checkpoint — 2026-10-11

The private PostgreSQL16.15 candidate profile `truss-pending-association-report-basis-candidate/0.2.0` now retains `originalOperation:to_jsonb(op)`, the entire captured operation row, after the existing full-row/source/value/generation coherent-cut comparisons. Original input/binding bytes and the five-family metadata image remain separately retained. Local bytea hex formatting covers all operation byte fields. This closes the prior packet omission of remaining operation context, definition, prestate and effect-obligation members; it does not turn a mutable snapshot into a durable readiness token. The Bun helper preserves native packet bytes without numeric decoding.

Final native receipts under `truss-binding-catalog-stage/`: fresh authored+composite `5c4e608a-2bdd-4a71-936f-a6d61aa06d74/native.json` passes500 observations; occupied `d7a98ee2-8294-4500-ae6e-b6bbc8861794/native.json` passes508; original single-field `6746e79d-f8d9-4bdf-b650-1d39f567262e/native.json` passes472; composite-only `52d62ea6-72aa-4b4a-8bab-fc5bf4000412/native.json` passes496. Each retains718 matching current source pins/exact ZIP preimages, type-sensitive observations, exact packet digests and completed cleanup. An excluded installer mutation changes only effect-obligation bytes, producing a valid new basis and55000 refusal of the old basis; rollback restores the complete state/guard and original positive. Actual host/native generation9007199254740993 is retained exactly across opaque bytes, direct native collection and rollback. The earlier497-observation d8fcef3f receipt predates this host large-generation control and remains a predecessor.

Formal receipt `report-basis-correspondence/e08c5c93-adbd-441c-8419-18bb8decf3b1/proof.json` retains19 checks (6UNSAT/13SAT),7 source preimages and SHA256 `f1ce1d0865c36a22ef26393086ce8d53cb0f9c4fe68f08da51e79a78e6395ad3`. Full-operation encoded correspondence excludes remaining-operation drift under the explicit codec premise; a separate operation-erased SAT control admits it. Astra ultra independently replays every formula in a fresh Z3 context and audits all four native receipts, pins, packets, query sequences and cleanup. The combined review is retained in the occupied d7a98ee2 directory, SHA256 `f6cd30cdc2a5eeb830c55464e7478840ea9af2f9b9756bd674a771f5c70f8e07`.

US-056-AC1/AC2/AC10 gain prerequisite evidence only; acceptance remains26/132. Codec injectivity is an explicit model premise, not proven PostgreSQL JSON refinement. Installed observer/privilege closure, authenticated original authority, registered semantic admission, native data enforcement, complete accepted-report composition/persistence, source promotion and distinct post-head/final-commit checks remain open. Endpoint equality does not exclude intermediate ABA without the stated monotone observer/immutable-custody premises. The1MiB host response ceiling and post-serialization8MiB native cap do not establish full output/resource bounds. The layout remains unadopted and candidate unregistered; acceptedReportQualified staysfalse, complete inventory refusal0A000 and commit refusal55000 remain closed. This checkpoint lands directly on main under the user's standing authorization.


## Complete report producer closure tests — 2026-10-11

Source-pinned static receiptreport-field-coverage/d66b0c9d-6283-4a2b-b55d-5695ad120458 accounts for all17 required report fields. It proves literal source/schema correspondence only, not runtime or semantic closure. InterfaceVersion already has pinned wire-literal validation. Four semantic producers remain absent; the ten existing producer comparisons still do not admit present binding or transform execution. The following acceptance-linked cases are required before complete report publication; they are planned, not passing evidence.

| Case | AC linkage | Required positive and refusal evidence |
| --- | --- | --- |
| REPORT-UMF-OWNER | US-056-AC1/AC10 | Original interpretation owner issues exact version/profile/subset evidence; copied, substituted, unavailable, unrelated generic storage-support and target-version-for-source evidence refuse. Multi-document repeated versions deduplicate under a declared deterministic order; differing versions remain distinct. Unknown extensions survive without becoming supported rules. |
| REPORT-REBIND-CLOSURE | US-056-AC1/AC10 | Every persisted native rebind and original transform receipt appears exactly once at the selected revision/cut. Omission, duplicate, foreign revision, source/target definition drift, substituted payload and unjustified empty inventory refuse without publication. A zero-effect positive requires an independently complete native scan. |
| REPORT-ASSERTION-CLOSURE | US-056-AC1/AC2/AC10 | Complete source assertion inventory corresponds to original owner interpretation and actual enforcement outcomes; unknown retained assertions explicitly classify unavailable/unenforced. Partial identity subset, omitted source assertion, invented supported assertion, misclassified layer/outcome and fabricated complete scope refuse. Flat-table and graph bindings execute equivalent logical controls with backend-specific physical evidence. |
| REPORT-PENDING-INDEX-CLOSURE | US-056-AC1/AC10 | Complete original acceptance-time job identities match native declarations, including independently proved empty case. Omitted/duplicate/foreign/substituted job and readiness sampled after acceptance refuse; later readiness preserves original report bytes. |
| REPORT-FULL-COMPOSITION | US-056-AC1/AC2/AC10 | All17 fields derive from qualified original producers under the same input/execution/source/value cut. Stale any-field producer, mixed generation/source/actor/epoch, present binding without registered effect inventory, unexecuted transform and any unavailable producer refuse before persistence. Post-head verification and final commit remain separate required positives/refusals. |

Retain native query outcomes, exact report/producer bytes and source pins, installer/profile/actor premises, before/after state, cleanup and AC disposition for each backend. Host mocks and static audits may test carrier refusal but cannot satisfy native inventory or owner-authority positives. Acceptance remains26/132; no planned case is promoted by this audit.


## Original document-to-subset membership candidate — 2026-10-11

Truss's private `catalog-umf-membership-candidate.ts` now checks every declared subset selection against its recognized original UMF preparation before grouping report entries. Each selection must match the ordered document ID, exact source digest/version, interpretation profile and already owner-verified transition selector. Direct0.8 sources have no transition selector; source0.7 remains the reported source version with its original transition SHA. No target-version substitution or silent omission is admitted. Grouping uses the complete `(version, interpretationProfile, supportedSubset)` value, including artifact identity/bytes/digest, in first original occurrence order. All document memberships remain separately retained even when report entries deduplicate. Distinct subset selections for documents sharing one version stay distinct; no version-only support inference occurs.

Owned data descriptors and dense array slots are captured without invoking selection getters or custom iterators. Subset artifacts retain exact canonical base64 bytes and verified SHA, including a valid empty artifact; empty bytes do not establish an empty semantic subset. The1MiB per decoded artifact and4MiB cumulative decoded occurrence limits include repeated selections. These are decoded-byte limits, not total identity/grouping/transition-serialization allocation, CPU or deadline bounds. Private WeakMap issuance ties the frozen candidate to the exact preparation. `verifyWithUmfMembershipCandidate` compares the entire report umf array alongside the existing ten producer fields, refuses copied candidate custody before parsing/native reads, and explicitly returns supportSemanticsQualifiedfalse with declared-membership-only scope.

Final host receipt `truss-umf-membership/1dcbfa25-545d-4bd2-bb2f-828dc90b1a05/host.json` retains36 passing checks,690 source pins/exact ZIP preimages, pinned original record/declaration/field bundle execution and a passing strict standalone TypeScript check. Controls cover mixed original versions, complete repeated-version membership, distinct subset and identity-only grouping, omission/reordering, source/profile/transition mismatch, copied preparation/candidate, descriptor/sparse-array refusal, byte substitution, empty artifact/digest and exact/over decoded resource limits. Full field comparison includes positive11-field correspondence and missing/duplicated/reordered/substituted umf refusals. The native report rows and selected subset bytes are synthetic; there is no fresh native execution or registered subset-interpretation proof. Astra ultra reviews this component and its scoped evidence.

This is the correspondence construction prerequisite for REPORT-UMF-OWNER, not its semantic-support positive. It executes original UMF preparation but cannot determine whether arbitrary selected bytes describe implemented support, whether required terms are supported or whether an opaque term is retained-only. Original registered support procedure, feature/required-term inventory, source-target preservation/support/loss qualification and independently admitted subset evidence remain mandatory before report publication. The new helper is private and not exported as accepted-report authority. All four report semantic producers remain unqualified; acceptance remains26/132. Full assertion/rebind/index inventories, installed/native authority and existing inventory/commit refusal gates are unchanged.

The final36-check receipt also rejects a candidate from a distinct genuinely recognized preparation of the same original bytes with the specific custody refusal and zero native calls. The33-check987530a2 receipt remains a captured predecessor without that control. The wire comparison covers the grouped umf projection; per-document assignments remain in the separately retained candidate and cannot be reconstructed from report.umf alone. No complete support membership or semantic authority is inferred from that wire array.


## Native joined report candidate correspondence — 2026-10-11

Truss's private `verifyWithExecutionProfileAndUmfMembershipCandidates` composes registered report-byte correspondence, the existing ten source/native producer fields, original execution candidate and declared UMF membership under one recognized preparation/report basis. Both candidate custody checks run before wire decoding, profile resolution or native I/O. The exact retained report bytes supply both field comparisons, followed by the original native epoch/execution recheck. The explicit result scope is thirteen_original_report_candidate_fields_only with supportSemanticsQualifiedfalse. This joins component evidence; it does not grant complete report interpretation, support or installed authority.

The final PostgreSQL17.9 run `truss-umf-membership-native/55d3e583-bb2b-4dfd-81bc-ca406106f550/native.json` passes195 distinct assertions, retains764 current selected source pins/exact ZIP preimages and completed exact-created-container cleanup; receipt SHA256d3478f3ef68d1fd90390755ab7ba6f72f1bf1364839cb3f3ff68031da53d479c. The isolated container binds127.0.0.1:15437; existing OrbStack containers/15434 remain outside this run. Native cohort output retains the exact47902-byte joined wire and SHA, thirteen-field membership vector, original document/subset mapping and actual cut830/0/11. Its original UMF0.7 source contains actual Record/Field/Key/relationship declarations and is prepared by the pinned original owner; source version remains0.7 with the original verified transition selector. Actual native metadata staging, document/count observations, context4/issued epoch capture and origin mapping execute. Selected subset/profile fixtures and installation authority remain explicitly unqualified.

Joined controls reject copied execution/membership, a distinct genuinely recognized preparation's membership, subset identity substitution, changed originalExecution and registered reportProfile, and stale native generation. A savepoint-local no-op prop_def UPDATE is injected through the original connection only after the initial native observation check succeeds. The test records reaching the final epoch collector, requires its55000 refusal, rolls back and restores exact original positive wire correspondence. This exercises the final recheck separately from the initial-cut refusal; it is an excluded installer interleaving, not a real concurrent writer or observer-closure proof. Existing native cohort/capsule, guard, rollback and unconditional failed-commit controls also execute. Strict selected-source TypeScript checking passes in retained typecheck.json; local Bun/compiler/ambient/Ajv/Python/image inputs remain observed environment premises, not hermetic execution closure.

Predecessor0fdee788 passed190 assertions with186 distinct legacy labels and lacks joined execution/profile substitutions;216cc72a and7f204370 pass192 but lack the final interleaving control, with the former predating protected runner readiness/execution cleanup. They remain captured historical receipts, not final current-source qualification. The final runner captures source/setup before creating its own container and covers readiness/execution cleanup using only its exact created ID. Astra ultra independently reviews the source and final retained evidence; no reviewer native rerun is claimed.

REPORT-FULL-COMPOSITION/REPORT-UMF-OWNER receive prerequisite evidence only; US-056-AC1/AC2/AC10 remain open and acceptance stays26/132. The report's grouped umf array cannot reconstruct per-document assignments; the mapping remains separately retained. Registered semantic support/required-feature interpretation, original installed issuer/capture authority, complete rebind/assertion/pending-index producers, registered present-binding/transform effects, complete persistence, protected observer/callable closure, post-head verification and final commit remain required. No public acceptance or report readiness is enabled, and the inventory/commit refusal gates remain closed.


## Original source value occurrence index — 2026-10-11

REPORT-ASSERTION-CLOSURE now has a private structural prerequisite in Truss's `acceptance-json.ts`: `indexSourceJsonOccurrences` records every JSON value in preorder with its decoded RFC6901 pointer, kind and half-open original UTF-8 byte span. Containers retain their full lexical spans; numeric values retain exact lexemes including unsafe integers, negative zero and arbitrary exponents. Original member spelling remains in the retained container bytes; member names are not separate value occurrences. The frozen issued handle grants copied value bytes through WeakMap custody; copied handles refuse. Only intrinsic Uint8Array carriers are admitted, without invoking caller length, species or tag callbacks. Shared-memory copying does not claim an atomic snapshot against concurrent mutation.

The existing byte/depth/node/member/work limits remain conjunctive; indexing additionally charges twice each materialized pointer's UTF-16 length against the work ceiling, so preflight admission alone does not promise index admission. The structural invariant is that each grammar value entry records exactly one position, and each container close finalizes its matching open position. This is a design argument tested on selected inputs, not a mechanically checked parser refinement proof or semantic completeness proof.

Truss retains exact source preimages and final host/browser receipts under `docs/helix/04-build/evidence/source-occurrence-index/`. Coverage includes original lexical spans, Unicode/escaped keys, source and returned-copy mutation, copied handles, malformed grammar/Unicode/duplicate names, numeric-wire separation, container/byte/depth/pointer-work limits, species callback aliasing and non-byte carrier narrowing. Strict selected-source typing passes. Actual Chromium153 executes the browser build with no Bun/process/Buffer globals and zero external requests. Local tool installations remain environment premises; the receipt does not establish hermetic execution or native backend enforcement.

US-056-AC1/AC2/AC10 receive prerequisite evidence only. A complete structural value index does not classify assertion/nonassertive/absence/unavailable meaning, authenticate an owner/profile, establish a complete semantic assertion inventory or enforce a policy. Those classifications must be supplied by original registered semantic owners over this occurrence basis; unknown meaning remains explicit. Acceptance remains26/132. Earlier native receipts remain evidence for their captured source preimages, not current-source replay after this scanner change.


Final checkpoint: Truss main commit `0b31d248` retains31 passing tests/113 assertions, Chromium153.0.8010.12 observations, strict selected-source typing, four exact source preimages and Astra ultra's scoped source review. Both review blockers (species-based aliasing and non-byte typed-array narrowing) are resolved and independently rechecked. Evidence: [Truss source-index receipts](https://github.com/DocumentDrivenDX/truss/tree/0b31d248/docs/helix/04-build/evidence/source-occurrence-index). The reviewer did not rerun the final browser suite or native backend tests. Root's fresh host/browser checks passed after the fixes. Concurrent Truss native row-image attribution main52dedb60 was preserved before the direct non-force push; it is outside this receipt's qualification.


## Original occurrence-to-assertion reconciliation — 2026-10-11

The private Truss `collectCatalogOriginalOccurrenceInventory` now executes the existing original UMF assertion owner collectors and indexes every value from each retained original document artifact. Every inspected core assertion must join an actual original pointer under the same document and exact artifact custody. Full lexical value spans, original source version and SHA remain visible. Existing core assertions retain their qualified module owner/evidence and enforcement none; all unmatched values receive unavailable interpretation rather than guessed metadata or absence. Root/document occurrence owners identify carrier custody only; they do not classify ontology meaning. Core absence observations stay separate and do not create authored values. Complete structural coverage is explicit, while complete and interpretationQualified remain false.

The actual pinned Record/declaration/Field producers execute in55 passing tests/318 assertions across four suites, with strict selected-source typing. Evidence under Truss `docs/helix/04-build/evidence/original-occurrence-inventory/` captures698 exact selected source/schema/fixture/declaration/producer preimages and before/after hashes. An independently traversed authored model checks every pointer; seven explicitly authored pointer/rule pairs check exact assertion membership. Copied/crossed genuine preparation/collection/inventory handles refuse; returned-byte mutation cannot affect custody. Mixed original0.7 and0.8 sources preserve original lexical1.2300e+2 and document-qualified repeated pointers despite the0.7 reversible target0.8. The admitted original UMF parser refuses unsafe integer9007199254740993 before issuance; standalone scanner preservation of that token does not broaden this semantic profile. These tests do not execute a native backend or qualify aggregate document-times-entry join work/heap accounting. Compiler/Ajv/local dependency installations remain nonhermetic premises.

REPORT-ASSERTION-CLOSURE and US-056-AC1/AC2/AC10 gain an original-source coverage and identity-join prerequisite. Registered complete assertion-family interpretation must still classify every remaining occurrence, including opaque content; unavailable rows prevent semantic completeness. Independently admitted engine/database enforcement, seventeen-field report admission, installer authority, complete persistence and commit barriers remain required. Acceptance remains26/132; no public capability or final gate is enabled.


Astra ultra's final retained audit verifies all698 current source/preimage hashes and ZIP inventory,55 distinct tests/318 assertions and strict typecheck0. Receipt SHA2563ac539d1acca993b1b998b88027ceff3c12c5282dc11d2df4c26391f781969d7; ZIP8763b59e10429b888c2c13a0b076c957627d94862878f96aa589cca8057fa6b7. Requested exact membership/crossed custody/schema-input controls are resolved. Reviewer did not rerun tests or native execution. Final review is retained with the Truss receipts; the direct-main checkpoint preserves concurrent Python main6b189b2d, outside this qualification.


## Formal occurrence and rule-family closure — 2026-10-11

Assertion-report completeness requires two distinct inventories. The first covers every original document value by exact original document/source-byte/pointer identity. The second covers every semantic rule identity interpreted at each value; one position may carry multiple rules. A position classified assertion establishes neither complete rule membership nor enforcement. The registered inventory owner must supply exact versioned rule membership for every resolved position, including explicit nonassertive metadata and absence of declarations at an authored carrier. Absence classification does not mean the original value is absent. Unavailable interpretation prevents completeness, and original owner/registration admission remains separate from logical truth and native enforcement.

`tools/security/prove-original-occurrence-closure.py` retains24 quantified logical queries with fresh-context replay:8 UNSAT laws and16 SAT positives/counterexamples. Exact coverage, resolved truthful interpretation and exact report selection exclude omitted/invented assertion-bearing positions. Additional coherent position-to-rule bridges and exact per-rule interpretation/selection exclude omitted/invented rule identities. A populated two-rule positive proves consistency; a position-complete counterexample omits one of two rules. Missing source coverage, false metadata classification, unavailable interpretation, omitted report selection and pointer/document/source-coordinate erasures each have populated countermodels. Equal-size complete source and covered supports can exchange their sole occurrence, showing why counts are insufficient.

Final current-source receipt `original-occurrence-closure/86655c50-8e60-40b3-8507-1deb54585d0a/proof.json`, SHA2564d584733581d74f661d81bfb5d01bc385e1d19d7681bab4fbb8acf7d2b97dca7, captures seven source preimages. Z34.15.4 checks and independently parses all saved SMT queries. Exact lexer correspondence, truthful registered semantic-owner interpretation, tuple injectivity over original byte carriers, report selection and tool installation remain explicit premises. No SHA collision-freedom, parser/owner refinement, actual semantic completeness, native enforcement/authentication or report admission follows. Earlier2f807755 lacks the exact-support and family model;7e892936 lacks coherent family/position bridges;ef1d3f64 has the corrected model but predates the final implementation row-state pins. They remain historical snapshots, not final current-source qualification.

The Truss bridge now explicitly exposes per-value interpretationState partial/unavailable and assertionMembershipCompletefalse, including positions with existing core assertions. This prevents treating an inspected subset at a classified position as a complete rule inventory. Fresh host receipt `original-occurrence-inventory/1ee4340c-75cc-4410-b564-21451d68372a/receipt.json` retains55 passing tests/334 assertions, strict selected-source typing and698 exact source/schema/fixture/declaration/producer pins. The runner creates unique receipt directories; the earlier318-assertion source snapshot remains intact. Aggregate resource accounting and actual backend execution are outside these host checks.

REPORT-ASSERTION-CLOSURE/US-056-AC1/AC2/AC10 gain formal design and explicit runtime scope evidence only. The next semantic owner must admit and enumerate complete rule-family identities under original source/profile custody before complete reports can be composed. Registered support/native authority, complete rebind/pending-index inventories, protected data enforcement, persistence/promotion and post-head/commit gates remain open. Acceptance stays26/132; no public admission or refusal gate changes.


Astra final combined review independently replays all24 formulas (8 UNSAT/16 SAT) and verifies final seven formal pins plus698 host pins/exact archives. Host receipt SHA25695ce434758f02bcf59790af03fe318dad5ac906526297aeca9e5c2006b15ef6c; host ZIP03bd56bb59d29da083ce224e2c120e8ae430f12cb55eb6e339765a90f67a54a8. Reviews are retained beside both final receipts. Reviewer does not claim host/native test reruns. concurrent Python packaging c1810d83 is preserved outside this qualification.


## Original-byte custody hardening — 2026-10-11

Truss now uses one bounded intrinsic byte-copy helper before JSON inspection, report/input handoffs, canonical encoding and asserted-origin/context preparation. Caller properties, iterators and typed-array species cannot substitute validated bytes or retained archive/native-codec bytes. Wire/profile routes require actual ordinary ArrayBuffer storage; genuine cross-realm arrays and exact byte windows remain supported. Structural shared-storage copying is not an atomic concurrent snapshot. Trusted pristine runtime intrinsics remain a premise.

Truss evidence `docs/helix/04-build/evidence/original-byte-custody/bbd42936-2f55-4f30-a491-b5444b540357/receipt.json` retains 775 exact source/schema/fixture/producer preimages, before/after hashes and ZIP. All 101 host tests/560 assertions and strict selected-source typing pass. Chromium 153.0.8010.12 passes 22 portable custody/scanner/codec/origin-context checks with no external requests or host globals. PostgreSQL 17.9 passes four temporary native canonical-codec oracle cases, including zero caller callbacks; the exact owned fixture container is removed. Native collector role/authority, complete semantic interpretation, accepted report production and backend security admission are outside this checkpoint. Earlier source-pinned receipts remain historical when their captured sources differ.

This closes a byte-correspondence prerequisite for REPORT-ASSERTION-CLOSURE and US-056-AC1/AC2/AC10; it does not establish semantic rule-family completeness or enforcement. Acceptance remains 26/132. Complete registered rule-family inventories, native authority and protected-data enforcement, persistence/promotion and final commit gates remain open.


Astra's final evidence audit found the prior bbd42936 receipt omitted the directly read `acceptance-outer-json-expected.proposal.json` corpus. That receipt remains a historical incomplete input capture. The corrected runner actually reran all checks into fresh Truss receipt `original-byte-custody/9033893c-1015-4800-aa4e-c913bd03a540/receipt.json`, capturing 777 inputs (including the omitted corpus and concurrent main's additional schema). All 101 tests/560 assertions, strict typing, 22 Chromium checks and four PostgreSQL codec cases pass again; exact fixture cleanup succeeds. No acceptance promotion follows.


## Original declaration meaning correspondence — 2026-10-11

The Truss core inventory now checks every original Key/Relationship declaration against the full pinned owner's retained declaration meaning before issuing its source identity. Equal counts and authored IDs are insufficient: ordered key fields, endpoints, primary/direction/lifecycle/multiplicity, optional-member presence and all opaque qualifiers must correspond. Object-key presentation order is immaterial; array order is preserved. The owner collection and original preparation must still have genuine private issuance custody.

A separate private declarationMeanings projection retains the exact issued assertion entry, declaration producer ProfilePin, full frozen original meaning, known/partial owner state and whole-owner uninterpreted paths. These are correspondence observations, with interpretationQualified false; unknown qualifiers are not declared supported and known owner state is not complete assertion-family interpretation. Accepted report schemas and the source identity profile are unchanged. Nondeclaration Field projections, distinct complete rule-family identity and original owner/issuer qualification remain required. This is one concrete refinement of the truthful-interpretation premise in the existing conditional logical closure model, not a proof of the owner/compiler or native SQL implementation.

Final Truss host receipt `original-occurrence-inventory/6d1aa141-2f0f-4646-8474-e7c02a68473d/receipt.json` retains 702 exact selected inputs and archive preimages: 72 tests/504 assertions across five suites, including report preparation, and strict selected-source typing pass. Controlled fixture owners traverse the real loader and collection path: eleven same-ID/count content or false-missing substitutions refuse; object-key reordering passes and exact retained partial meanings remain visible. Fixture-owned manifests do not prove trusted issuer authority. Earlier fc3cbe03 and 77d5677f receipts retain intermediate source/test scopes; 33522bfd omitted the added report-preparation fixture and is an incomplete input capture. The final runner captures that fixture and actually reruns all checks. This host run contains no fresh browser or native execution. REPORT-ASSERTION-CLOSURE/US-056-AC1/AC2/AC10 gain declaration correspondence evidence only; acceptance remains 26/132 and complete backend/report/publication gates remain open.

Original observation pointers now must match their requested module/element/operation. A missing result may classify absence only when the original final member is absent; an authored declaration or absent parent refuses. The earlier 89d7bbf1 receipt predates these omission controls. This binds source position and presence, while independent known Field meaning projections remain open.


## Original nullability semantics and conditional proof — 2026-10-11

Truss now checks original 0.7 nullability owner context and meaning before filtering owner states. The exact requested identity/source/path, inspect-core-nullability operation, version 5.0.0 and loaded Field profile must correspond. Known required/absent-allowed/unspecified, future unknown values, missing Field members and inapplicable Record members remain distinct. A known authored rule cannot be suppressed as missing, unknown or inapplicable; an absent member cannot invent a known rule. Future meaning tokens must retain their exact value. A private fieldMeanings projection retains the exact frozen owner meaning, owner ProfilePin and issued source assertion; interpretationQualified remains false. Other Field families and independent occurrence-versus-rule-family identity remain required.

Final Truss `original-occurrence-inventory/89401c89-121f-42a8-a9e4-623e68851b08/receipt.json` captures 703 selected inputs: 76 tests/578 assertions and strict selected-source typing pass. Tests execute actual pinned original producers, reversible 0.7→0.8 transition and Record checker. Required omission fails; absent-allowed omission succeeds completely; unspecified and missing availability stay incomplete with RECORD_AVAILABILITY_UNKNOWN. Twelve controlled loaded fixture-owner substitutions refuse, including altered state/value/operation/version/identity/path, future-value replacement and invented known meaning. Fixture manifests establish diagnostic custody only. Earlier 97e5d2d1/46a9ea5c host snapshots precede final controls; 0eb03345 retains the initially failed test typing log. This checkpoint has no native/browser execution.

`tools/security/prove-nullability-owner-correspondence.py` retains 15 fresh-context Z3 4.15.4 queries (6 UNSAT, 9 SAT) in `nullability-owner-correspondence/8b1c2ce4-ba67-43d6-afc7-432ad3a11051/proof.json`, with ten exact source/producer/test preimages. Under the finite original nullability and exact context/meaning guard, false omission, known-value substitution, future/absent known invention and context substitution are excluded; presence-only Record validity/completeness agrees. Populated positives cover each state. Countermodels show that post-filter checks can suppress required rules, value-only checks can mix contexts, known unspecified meaning does not imply complete availability, and correspondence does not imply authenticated issuer or installed enforcement. Source admission, context tuple injectivity, expected owner meaning and the abstract omission equations are explicit premises. This is not JavaScript/owner/compiler/SQL refinement, complete value/facet/default/key/relationship semantics, or a backend enforcement theorem. Earlier 1e03a065/cf1f54c7 proof snapshots remain historical.

REPORT-ASSERTION-CLOSURE and US-056-AC1/AC2/AC10 gain source-level nullability correspondence and conditional logical evidence. Original absence remains distinct from SQL NULL; backend binding and protected write/read-path enforcement still require independent implementation and evidence. Acceptance remains 26/132; complete semantic owner/family inventories, report authority/persistence and final publication/commit gates remain open.


## Original Field shape and facet projection correspondence — 2026-10-11

The Truss pre-filter guard now covers all four selected original 0.7 Field owner operations: kind 6.0.0, nullability 5.0.0, cardinality 4.0.0 and facets 3.0.0. Exact original context, requested identity, operation/version/path and expected state/value must correspond before any known/partial entry or missing classification is emitted. Kind field/record/group, unspecified and unknown remain distinct. Cardinality one/array/map/unspecified, missing/inapplicable/unknown remain distinct; itemType member presence, qualified reference and all opaque qualifiers must match. Object-key order is immaterial; array order remains significant.

Facet comparison preserves the entire original payload, separately checks the interpreted length/integer-width/precision/scale groups, and compares unknown-path evidence with the independently retained original document validator's UNKNOWN_FACET/UNKNOWN_FACET_UNIT warnings. For this pinned original 0.7 profile, the document validator appends the same facet validator's diagnostics in order. An owner cannot erase unknown paths, relabel partial as known, invent an interpreted group, suppress an authored facet carrier or change its value. Empty authored facets retain an empty interpreted map; a generic core.facets carrier entry does not establish a complete inventory of semantic duties. fieldMeanings now retains all four exact known/partial projections and their owner ProfilePin/issued entry with interpretationQualified false.

Final Truss host receipt `original-occurrence-inventory/a5c3813e-26c4-4365-98fa-437ff5e4981b/receipt.json` retains 704 exact selected inputs: 83 tests/734 assertions across seven suites and strict selected-source typing pass. Actual pinned producers and reversible 0.7→0.8 Record checks cover one/array/map shape, referenced item type, Unicode-scalar string length, binary byte length, signed integer width and decimal precision/scale without rounding. Missing/unspecified cardinality remains incomplete. Twenty shape and eighteen facet substitutions through controlled loaded fixture owners refuse; object-key reorder positives preserve full meaning. Unknown role/container/unit/qualifier content remains visible without semantic support or issuer claims. Earlier e09e403b is the pre-final additional-controls snapshot. This is host evidence, with no fresh browser or native backend enforcement execution.

`tools/security/prove-field-projection-correspondence.py` saves 18 fresh-context Z3 4.15.4 queries (8 UNSAT, 10 SAT) and ten exact source/test/producer preimages in `field-projection-correspondence/32d0a06d-e2f5-4121-b227-6bf2ecedb64a/proof.json`. Under exact state/context/cardinality/item-presence/item-value/raw/interpreted/unknown-path guards, omission and substitution are excluded. Populated guard-removal countermodels show loss of an admitted array item reference or qualifier, raw opaque members, interpreted bounds or partial evidence, and state-filter-only omission. A model also shows correspondence without authenticated owner or installed enforcement. JSON semantic carrier fidelity, original source/context admission and expected producer interpretation/validation-path projections are premises; this is not a concrete JSON comparator, owner/compiler/JavaScript/SQL refinement or complete family inventory proof. c71e058f is an earlier test snapshot; 3ecf8b83 lacked the corrected known-array population constraint on the item-value substitution countermodel. Prior nullability/occurrence source-pinned proofs remain historical when their captured sources differ; their abstract conditional laws do not qualify this implementation by themselves.

REPORT-ASSERTION-CLOSURE and US-056-AC1/AC2/AC10 gain selected Field interpretation correspondence prerequisites. Registered distinct rule-family interpretation (including scalar type, membership and extension semantics), issuer/native authority, complete accepted-report persistence/publication and protected data enforcement remain open. Acceptance remains 26/132.


## Original facet rule-family identity candidate — 2026-10-11

Truss now derives private candidate duties from the already-compared original 0.7 Field facet projection. Length and integer-width each supply one duty; decimal precision and fixed-scale/no-rounding supply two distinct duties at the same original pointer with the same joint precision/scale parameters. Identity includes candidate profile, actual semantic-owner profile, exact original occurrence and family. Empty or unknown-unit interpretation invents no duty. Original opaque qualifiers/unknown paths remain attached. In-process issuance refuses cloned/cross-preparation candidates. Coverage, interpretation qualification and enforcement remain false/none; this is not a registered report or backend admission profile.

Final host `original-occurrence-inventory/9e3c6886-8650-4fe1-8b33-72dfbe69f119/receipt.json` retains 705 selected inputs, 85 tests/788 assertions and strict selected-source typing exit0. Actual pinned Record behavior distinguishes precision5/scale2: 999.99 passes, 1000.00 fails precision, and 12.345 fails fixed scale. Candidate tests distinguish the two identities despite equal parameters, preserve opaque content, refuse cloned/crossed custody and keep deterministic repeated identities. 7c8ad4f9 retains the initial readonly test-expectation typing failure; 042ea0b4 predates the extra decimal boundary. Concurrent Python main56ac0b9e is preserved. No browser/native execution or acceptance promotion occurred.

`tools/security/prove-facet-rule-family-identity.py` retains 11 fresh-context Z3 4.15.4 queries (4 UNSAT, 7 SAT) and 11 exact preimages in `facet-rule-family-identity/0e31ad9f-258f-4a63-916c-d882410f8cb4/proof.json`. The faithful tuple constructor excludes collisions when family, candidate profile, semantic owner or original occurrence differ. Explicit erased-key countermodels show collisions when those coordinates are absent; parameter-only identity also collapses the two decimal duties. A populated two-duty witness is consistent, while valid identity permits absent authority/enforcement. Faithful tuple/original occurrence representation and the owner/mapping semantics are premises. This is not a JSON serialization, SHA, JavaScript/owner/compiler/SQL refinement, complete family inventory, authenticated issuer or native enforcement theorem. 04042204 precedes explicit erased-key controls; d4f84320 precedes final test preimages. An initial SMT declaration-name collision failed replay before a complete proof receipt; corrected fresh runs replay every formula.

REPORT-ASSERTION-CLOSURE and US-056-AC1/AC2/AC10 gain a concrete partial multi-family inventory prerequisite. Complete registered family interpretation (scalar type, membership, extensions and remaining declarations), report authority/persistence/publication, final commit gates and protected data enforcement remain open. Acceptance remains 26/132; the full goal is active.


## Original scalar family inspection evidence — 2026-10-11

Internal `src/model/scalar-type.ts` and `spec/core/scalar-type-inspection.schema.json` implement original 0.7 value-family label inspection version0.1.0. The nine independently asserted labels are boolean/integer/decimal/float/string/binary/date/time/timestamp. Explicit Field labels classify as known, future labels retain exact unknown content, missing Field labels stay missing, and non-Field/unspecified roles stay inapplicable with any source-admitted authored label retained separately. The source schema rejects scalar labels on explicit groups and array/map Fields. Separately qualified item Field scalar meaning never becomes the container's scalar meaning. This operation copies the validated original source/identity, retains opaque content and exact pointer, and reports provenance unverified. It has no public barrel export, registered report owner, native-domain mapping or enforcement installation yet.

Final `scalar-owner-inspection/7791d432-4456-4e25-b64b-9a22626dfeb1/receipt.json` retains 514 current source/config/package preimages, bundle and log hashes: one host corpus test/49 assertions, strict selected typing exit0, Chromium153.0.8010.12 with48 unique passing cases. Controls include all nine independently authored families, future/absent/unspecified-role distinctions, module-qualified duplicate element names, source/result copy isolation, container/item independence, invalid source/identity/version and getter refusal without invoking the callback. Independent closed-result schema controls refuse future-known, recognized-unknown, missing-with-label, invented provenance/version and extra enforcement fields. Schema validity alone does not prove source/path/meaning correspondence; the producer computes that relationship. 9b558ce0 precedes closed-result controls; 56452a8d precedes independent family/config capture. Initial group/array scalar positives failed against existing source constraints; final cases deliberately verify refusal and qualified item inspection instead.

`tools/security/prove-scalar-family-correspondence.py` retains15 fresh-context Z3 4.15.4 queries (7 UNSAT/8 SAT) and516 source/host-receipt preimages in `scalar-family-correspondence/5bf719bb-32e3-4792-8ba1-a36a9f5167ba/proof.json`. Given original source admission and exact state/context/finite label-class guard, known duty suppression, future-known invention, absence invention, non-Field duty inference and crossed context are excluded. Populated positives cover known/future/missing/non-Field; controls isolate label-only role filtering while preserving value/context, known-label substitution when only its equality guard is erased, and crossed identity when only context is erased. dee14792 is historical before those isolated controls. Container conflict exclusion follows its explicit source-admission premise. The future class does not distinguish arbitrary future payloads; actual payload fidelity is assumed and host/browser-tested, not proved by this finite model. Classification equations and exact carrier/admission are premises, not concrete JavaScript/schema/compiler/SQL refinement, native domains or authenticated authority. Correct classification still permits absent authority and enforcement.

REPORT-ASSERTION-CLOSURE and US-056-AC1/AC2/AC10 gain the missing scalar owner prerequisite. Next integrate a freshly pinned owner bundle into Truss with exact original source/context/value comparison; do not falsely describe this new function as available in historical c45 producer bundles. Complete scalar/native domain interpretation, member/reference/extension family inventories, report authority/persistence/final gates and protected data execution remain open. Acceptance remains26/132; full goal active.


## Truss scalar owner/report integration evidence — 2026-10-11

Truss loads a separate scalar-types owner from exact UMF94d0a99e4d1e9eb39278f38d6cd6bcba51e46db8. Historical c45 Record/declaration/Field preparation remains independently pinned. Optional scalar observations have their own actual bundle/revision ProfilePin; original0.8 produces explicit unsupported-version unavailable observations. The core source-identity profile is0.4.0 and declares the added scalar operation/owner. Before any classification filtering, every observed original0.7 scalar result must match its full source, exact requested identity/pointer, operation/version, expected state/value and unverified provenance, with no extra members. Known Field labels supply core.scalarType entries and retained owner meanings; missing is absence, unknown/inapplicable stays deferred. Original-byte inventory joins only actual entries to exact lexical spans. All membership/completeness/enforcement qualifications remain false/none.

The private composed report now forwards an optional scalar owner, and ordered coverage verifies the independent scalar profile and exact original evidence at each expected call. Coverage counts the configured producer calls; an available result is not complete semantic-duty coverage. Original0.8 with this scalar owner is incomplete/unavailable. A synthetic-native-row host test verifies composed scalar observations/entries and four additional element calls; it is not a PostgreSQL installation/count/admission proof.

Final Truss host `original-occurrence-inventory/2823413d-34e7-4b87-a79a-347561732e5f/receipt.json` retains712 current selected inputs, actual scalar producer bundle/entry/manifest and builder, repository package/lock bytes, and explicit absence of tsconfig.json/bunfig.toml. Eight suites pass90 tests/981 assertions with strict typing exit0. Nine independently authored family labels preserve exact original scalar byte slices, opaque content, source artifact reference and actual independent owner pin. Twenty controlled loaded substitutions refuse before filtering, including future/absent/inapplicable replacement, altered identity/path/source/operation/version/provenance and extra enforcement fields. Reordered meaning keys remain valid. Loaded fixture manifests establish custody only, not authenticated issuer authority. Earlier c3086c72 predates unsupported0.8/report-composition controls; 06ad77f8 retains the readonly test-typing failure; a80a67a4 predates composed report forwarding. The initial runner attempted to read absent configuration files; final evidence records and rechecks absence instead. Concurrent Truss main8576be6b Python inspection changes are preserved. This host checkpoint supplies no native/browser qualification or acceptance promotion; the later native scalar composition checkpoint below records separate actual PostgreSQL evidence. Prior UMF Chromium evidence qualifies the actual owner operation separately.

`tools/security/prove-scalar-owner-result-correspondence.py` retains23 fresh-context Z3 4.15.4 checks (11 UNSAT/12 SAT) and714 exact source/host-receipt preimages in `scalar-owner-result-correspondence/bb4f53a9-17e7-4b4b-8752-2b4d775e4e0f/proof.json`. The guarded result preserves finite known-family class, full future/authored-future text, exact context, original-source carrier and closed result shape. Isolated guard-erasure controls retain the other guards and show future payload replacement, opaque source loss, crossed context, non-Field duty invention, known-label substitution and extra result fields. Known families use distinct finite classes; the separate faithful text carrier applies only to future labels, avoiding an unrealizable known-class change with equal faithful text. Original source admission/classifier equations and faithful text/source carrier representations remain premises. This is not concrete JavaScript/JSON comparator/schema/compiler/native refinement or an issuer/enforcement theorem. f35b330a preceded the distinct evidence namespace; b5c05df6 preceded the raw-carrier correction; d029e9ec preceded final composed-report source capture. Prior finite scalar laws remain conditional historical evidence, not proof of this concrete integration.

REPORT-ASSERTION-CLOSURE and US-056-AC1/AC2/AC10 gain scalar original-source/report prerequisites. Complete member/reference/extension and remaining declaration family inventories, native scalar domains, authenticated source/callable/cut authority, accepted persistence/publication/final commit gates and protected data enforcement remain open. Acceptance remains26/132; full goal active. Next resolve original record-member/reference semantic owner inventory without interpreting arbitrary extension/native meanings as generic constraints.


## Actual native scalar report composition — 2026-10-11

Final Truss `scalar-native-cohort/cdb1c711-7889-400b-ba83-f8a8a090176b/receipt.json` captures793 exact source preimages and actual PostgreSQL17.9 private cohort/report execution. All199 native observations pass, including four additional scalar checks: both original string-family duties, the independent scalar owner revision/bundle, all four ordered element observations (29 configured owner calls), and original source artifact custody with enforcement none/interpretation unqualified. Existing atomic staging/refusal, original cut, observer and stale/interleaved source/report checks replay with the optional scalar owner forwarded through all five report composition sites. The fixture image/port/database/container are retained, and the exact fresh named/labeled container is removed with cleanup exit0. This proves selected native report/observer composition, not installed scalar data enforcement, complete policy-family inventory, issuer authentication or accepted final publication/commit authority.

The native runner requires all four executed producer directories to equal the host-captured bundle paths/hashes, retains their exact three bundle artifacts, checks all four scalar observations and the actual scalar ProfilePin, and verifies host source/configuration absence before and after execution. Creation uses a cidfile, unique name and owner label. Bounded cleanup recovers that exact name/label even when creation returns no usable result; it removes only the recovered owned ID and retains failure/uncertain cleanup evidence. Earlier1a88354c/69fa04ae lacked final executable-bundle/cleanup-recovery hardening; fe6ff2cb predates case-insensitive OrbStack absence diagnostics.

`scalar-native-cleanup-control/02a6c6cf-d232-48a2-b759-da7886f71811/receipt.json` captures795 inputs and an actual Docker creation under a controlled CLI shim that loses the success result and returns nonzero before the runner assigns its container ID. The runner correctly fails, recovers/removes the exact owned fixture with exit0, and an independent real CLI inspect returns no-such-object. The retained shim/creation/log/failure bytes distinguish this control from a native security success or proof of all daemon timeout races. The initial4f566ee7 control had successful cleanup but incorrectly treated OrbStack's lowercase absence diagnostic as uncertainty; the final control records inspection output and checks that diagnostic case-insensitively. No unrelated containers are addressed.

REPORT-ASSERTION-CLOSURE and US-056-AC1/AC2/AC10 gain actual PostgreSQL scalar metadata/report correspondence evidence. Host90/981/strict0 and conditional23-query11UNSAT/12SAT evidence remain separately scoped. Acceptance remains26/132; native scalar domains/data enforcement, authenticated original owner/cut authority, complete registered semantic families, accepted persistence/publication/finalizer and wider Ashlar/backend cases remain open.

Concurrent Truss main5e9eb10d (Python physical post-state verification and its separate SQL component) is also preserved. All712 host,793 native and795 cleanup-control preimages still match after that fast-forward; the new unused Python SQL component is outside this executed cohort's captured inputs. No rerun or qualification of that separate component is inferred.


## Original Record membership owner — 2026-10-11

Internal `src/model/record-members.ts` and closed `spec/core/record-members-inspection.schema.json` inspect original0.7 membership with operation version0.1.0. Existing UMF membership validation supplies target resolution, explicit Field role and single Record ownership checks. An explicit Record with absent members is missing; an authored empty list is known and retained as an explicit declaration. Ordered qualified references retain every opaque qualifier. UNKNOWN_KEY_QUALIFIER paths under the exact members pointer produce partial meaning. Non-Record roles remain inapplicable; invalid authored membership is rejected by original document admission before inspection. Exact copied source, requested identity, pointer and unverified provenance accompany every result. This is an internal semantic owner, without public export, native enforcement or authenticated author/issuer authority.

Host/browser `record-members-owner-inspection/178e4ea1-7ebc-4132-ab77-a334b052834b/receipt.json` retains516 exact source/config/package preimages, one Bun test/38 assertions, strict selected typing exit0 and37 unique Chromium153.0.8010.12 cases. The corpus distinguishes missing/empty/ordered/qualified membership and partial unknown qualifiers, cross-module same-name resolution, original/result copy isolation and non-Record roles. Missing/non-Field/duplicate/multiply owned targets, malformed identity/version, getter access and inconsistent closed-result states refuse. Closed-result schema checks shape only; the operation supplies concrete source/path/meaning correspondence. Local runtime/dependencies remain explicit non-hermetic premises.

`tools/security/prove-record-members-owner-correspondence.py` retains22 fresh-context Z3 4.15.4 queries (10UNSAT/12SAT) with518 exact preimages in `record-members-owner-correspondence/1f21215f-e253-4ea6-9548-f5e02092b242/proof.json`. Conditional state/context/faithful ordered opaque-list/source/closed-result/exact unknown-path guards exclude declaration suppression, absent or non-Record invention, partial-as-known substitution, crossed identity, opaque loss and changed unknown paths. Erased-guard controls admit the corresponding failure. Partial-as-known requires erasing both state and exact-path guards to remain schema-valid; state-only erasure still refuses because closed known results require empty unknown paths. Known/partial/missing/non-Record witnesses are populated, and valid correspondence permits absent issuer authority/enforcement. Original source admission, state equations and faithful list/source carriers are premises; this does not prove concrete JSON/JavaScript/schema refinement, target resolution/single ownership, exact empty-list encoding or native enforcement.

REPORT-ASSERTION-CLOSURE and US-056-AC1/AC2/AC10 gain an upstream membership inspection prerequisite. Next pin and compose this owner in Truss, compare its complete result before state filtering, retain empty declarations and each member occurrence without replacing logical membership by dataset containment or relationship incidence. Record-type reference and arbitrary extension interpretation remain separate owners. No accepted backend case is promoted; acceptance remains26/132 and the full goal remains active.

Astra review added an authored reversed-order member control and duplicate qualified identity with distinct opaque qualifiers, avoiding sorted-input and schema-only duplicate blind spots. A separate faithful ordered unknown-path carrier and isolated erased-path guard also extend the conditional model. Host a174fe04 and formal48fcedb5 remain historical before these feedback changes; their original bytes are preserved.

Final formal1f21215f includes the known-empty/partial-nonempty result-schema relationship. Formal5ad9453d is historical: its state-only partial-as-known counterexample retained nonempty paths and could not satisfy that concrete schema relationship. Astra identified this precision defect; corrected22-query evidence distinguishes schema refusal from the explicit two-guard erasure counterexample.


## Truss original membership report composition — 2026-10-11

Truss builds/loads a separate record-members owner from exact UMF5ddc656273e1965efa0187f3090d165d45225dcd. Historical c45 Record/declaration/Field and94d0a99e scalar owners remain independently pinned. Optional membership observations have their own actual bundle/revision profile and configured ordered coverage. Every original0.7 result is compared in full before filtering: copied original source, exact requested identity/pointer, operation/version, role/presence/ordered references/opaque qualifiers/exact unknown paths and unverified provenance. Original0.8 is explicitly unavailable. Source-identity profile0.5.0 retains one declaration duty even for an empty list, plus each actual ordered member occurrence. Entries join exact original byte spans; membershipMeanings retain actual owner pins and frozen unknown-path arrays. Completeness/enforcement/interpretation qualification remain false/none.

Preparation now retains missing membership explicitly as missing, preserving inspectable absence instead of requiring an array at declaration collection. Derived fields[] is a correspondence projection with that separate status, not an empty membership assertion. TypeScript default home selection and new-cohort staging refuse any missing membership before native I/O. A genuine empty declaration remains eligible for the private new-cohort component. The existing Python packaged bridge still uses older declaration collection that refuses missing membership; Python staging has not adopted the new marker/guard or been rebuilt/qualified by this checkpoint. Any bridge adoption must implement the same explicit original-membership guard before native staging; do not combine this source change with that older packaged qualification.

Final Truss host `original-occurrence-inventory/ae5c7e87-96b6-4f88-af81-9240d82edde0/receipt.json` retains716 current selected inputs, all five actual bundle/entry/manifest preimages and package/configuration premises. Nine suites pass96 tests/1081 assertions with strict typing exit0. Six new tests cover reverse ordered qualified references, opaque qualifiers, exact declaration/member byte spans, actual independent owner pin, absence/empty/non-Record distinctions, original0.8 unavailable coverage, synthetic-native-row private composition and cloned/cross-preparation custody. Twenty-two controlled loaded result substitutions refuse before filtering; a meaning-key-order positive remains valid. Missing membership refuses home selection/staging with zero connection calls. Astra found a mutable derived unknown-path array; final retention freezes it and mutation/isolation assertions pass. Host0ea56e3b retains the initial missing-members preparation/typing failures; ca3f6302 retained96/1076 host passes but an entry typing failure; bfa0e9b8 predates the immutability fix. These predecessor bytes remain historical evidence.

Final Truss `record-members-native-cohort/88bcc8b6-591e-47a1-953f-53cf0c0989b6/receipt.json` captures798 current preimages and205 actual PostgreSQL17.9 observations, preserving the prior195 staging/cut/observer/refusal checks and four scalar checks. Four membership observations verify both declaration/member duties, the independent owner pin, every configured element call and retained original source/unqualified status. All five report composition sites forward the owner. The populated two-Record witness retains17 core entries and33 configured owner calls. Two additional actual empty-Record checks use a separate original source preparation, original native prestate/input admission and transaction; one native type and zero properties stage, while the original empty membership declaration remains a duty. The transaction rolls back and the exact newly created named/labeled fixture is removed with cleanup exit0. Runner execution binds all five bundle directories to host captures and rechecks source/configuration absence. Native167f4df9 is pre-immutability/empty witness;70f8fe4a retains an empty-witness SAVEPOINT-outside-transaction failure with completed cleanup. Final witness uses its own BEGIN/admission/rollback. Actual component custody remains administrative/unqualified, not ordinary-person security or accepted publication.

The upstream22-query membership proof in UMF `record-members-owner-correspondence/1f21215f-e253-4ea6-9548-f5e02092b242` remains conditional owner evidence (10UNSAT/12SAT), with source admission and faithful carrier/classifier/schema premises. Its source pins do not qualify this new Truss mapping or native enforcement; the new host/native observations provide separate concrete evidence. REPORT-ASSERTION-CLOSURE and US-056-AC1/AC2/AC10 gain membership original-source/report prerequisites only. Record-type reference/extension/native family interpretation, authenticated owner/cut/callable authority, accepted persistence/publication/finalizer and protected data enforcement remain open. Acceptance remains26/132; full goal active.

Concurrent Truss main586f1b75 Python revision-obligation work is preserved. Its newly added unused catalog-completion/revision-obligation.sql is outside this cohort's executed snapshot; none of its qualification is inferred here. Existing captured host/native input bytes are rechecked after fast-forward.

A later concurrent Truss8d4d21d0 Python original-declaration index producer is preserved by a non-force merge. All716 host/798 native captured inputs remain current/exact after merge; the new unused catalog-report/absent-binding-index-declarations.sql and Python components are outside the executed snapshot and receive no qualification here. Astra's final host/native audits report no remaining scoped blocker.


## Original core reference links and separate type authority — 2026-10-11

CONTRACT-040 requires verified Field/Record kind declarations and the explicit record-type authoring receipt before a role establishes an authored type assertion. A bare imported record-type string does not supply that receipt. CONTRACT-001 separately admits direct core references with exact qualified target existence, including repeated links and arbitrary roles. These meanings cannot be collapsed into a generic value-type constraint.

Internal `src/model/reference-links.ts` and closed `spec/core/reference-links-inspection.schema.json` inspect original0.7 direct core links with operation version0.1.0. Missing references and an explicit empty list remain distinct. Each original occurrence retains its index/pointer, full role/reference/opaque qualifier content, exact resolved target identity/path and source-admitted kind presence/value. UNKNOWN_CORE_FIELD paths under that reference are retained. All links carry typeAssertion unverified, with copied original source/requested identity and unverified provenance. Source validation refuses unresolved/duplicate identities. Only direct links are projected; cyclic/self/mutual references terminate without recursive expansion. No public export, authored type authority, complete semantic-family inventory or native enforcement is supplied.

Final host/browser `reference-links-owner-inspection/4f0e1468-1158-4af0-ab99-d7a48349d57a/receipt.json` retains518 current source/config/package preimages, one Bun test/43 assertions, strict selected typing exit0 and42 unique Chromium153.0.8010.12 cases. Independently expected ordered target/index/path projections use nonlexical roles and distinct unsorted cross-module targets with a repeated link, catching role or target sorting. Controls cover same-name cross-module targets, unknown/absent target kind, opaque qualifier paths/copy isolation, direct self/mutual cycles, repeated occurrence identity, missing/empty distinction and exact qualified owner context. A scalar Field plus raw record-type link and a record-type role targeting a Field remain plain unverified links; no authored type constraint is invented. Getter/malformed identity/version/unresolved/duplicate target refusal and closed-result type-authority/provenance/extra-field controls pass. Schema shape does not itself prove source/target correspondence; the operation computes it.

`tools/security/prove-reference-links-owner-correspondence.py` retains30 fresh-context Z3 4.15.4 queries (12UNSAT/18SAT) and520 exact source/host-receipt preimages in `reference-links-owner-correspondence/7607301d-cce6-44c9-aacd-6f315ece81a3/proof.json`. Conditional presence/ordered opaque-link list/context/selected original occurrence/qualified target/path/kind/unknown-path/source guards exclude substitution. Erased-guard controls retain the other coordinates. Two distinct links reversed at equal length and identical population isolate order from omission; identical repeated links separately show why original occurrence index remains required. Missing, explicit empty and populated witnesses are consistent. A separate required downstream verified-receipt gate excludes admitted type without verified receipt, while bare record-type role plus Record target admits a model with no receipt and no type authority. Erasing that receipt gate allows erroneous downstream promotion. That gate is an obligation sanity check, not implemented receipt ingestion.

Admitted source/unique resolved targets, faithful ordered list/source/path/kind carriers and their JSON correspondence remain premises. The selected occurrence is arbitrary within a populated list; closed_result is an abstract shape coordinate, with the actual unverified typeAssertion literal checked separately in host/schema/browser evidence. This is not concrete JavaScript/schema/JSON pointer/compiler refinement, authenticated author/issuer, recursive graph traversal, verified type receipt integration or native enforcement. Host a7c02290 retains the initial future-kind/member-role fixture conflict and typing failure. Host63e46fdc/d922f010 and proofs b7cbdf54/c1b29b32/28a0351a are historical before final distinct-target/order controls and final proof capture; original evidence bytes are preserved.

REPORT-ASSERTION-CLOSURE and US-056-AC1/AC2/AC10 gain a generic core-link inventory prerequisite with an explicit type-authority boundary. Next Truss integration must pin this owner, compare complete results before filtering, retain every original link occurrence/empty declaration, and keep unverified links separate from authored record-type assertion duties. Original verified authoring-receipt ingestion, arbitrary extension/native families, accepted report authority/persistence/publication/finalizer and protected data enforcement remain open. Acceptance remains26/132; the full goal is active.


## Generic reference-link consumer/native evidence and remaining type gate — 2026-10-11

For REPORT-ASSERTION-CLOSURE/US-056-AC1/AC2/AC10, Truss final host22b44ef2 passes102 tests/1200 assertions/strict0 with720 retained inputs. Controls compare the entire original owner result before filtering; reject harmful order sorting even with recalculated occurrence metadata; prevent loaded owners mutating retained request identities; preserve repeated qualified targets, opaque qualifier paths, empty/absent distinctions and exact original byte spans. Generic links join separate occurrence/declaration collections and never become authored type constraint entries.

Actual PostgreSQL17.9 `reference-links-native-cohort/acf8e27d-014a-4810-94c7-d2492cfabc87` retains807 preimages/210 checks with cleanup0. All205 prior scalar/membership/cut/refusal checks remain required once. Four new checks verify ordered Record links B,A,B plus RecordB explicit empty declaration, exact independent UMF9545 revision/bundle, every configured reference call (37 total) and original byte joins without invented type assertions (17 unchanged constraint entries). All six composition sites forward the owner. A fifth new control requires the original c45 preparation's INVALID_DOCUMENT/KEY_EQUALITY refusal for raw record-type links on the actual key Field, before catalog admission. The failed initial f986ecda and209-check predecessor09451b81 remain historical rather than concealed.

This supplies selected private native report/source correspondence only. Required next tests must separately compose verified Field/Record kind and record-type authoring receipts, exact original source transition/provenance and admitted receipt issuer; bare role/target matching must never substitute for them. Qualify the key equality profile independently rather than assuming generic-link preservation resolves it. Native business-data/type enforcement, complete assertion/native family inventory, authenticated current cut/callable authority and accepted persistence/publication/finalizer remain required. The upstream30-query conditional owner proof does not prove Truss consumer or native enforcement. Acceptance remains26/132; no backend case is promoted.


## Exact-current type-receipt consistency evidence and consumer gates — 2026-10-11

For REPORT-ASSERTION-CLOSURE and US-056-AC1/AC2/AC10, original0.7/v6 `inspect-core-record-type-receipt`0.1.0 reuses existing kind/type authoring receipt recomputation, full current-target comparison and exact qualified owner/link/Record correspondence. Final host5ae0c4cf retains520 inputs, one Bun test/61 assertions, strict0 and60 real Chromium153.0.8010.12 cases. Required controls exercise actual missing-kind Field/Record transitions with renewed context; individually valid stale Field/foreign Record receipts; full source/receipt opaque/order/context substitution; same-named cross-module owners/targets; exact appended occurrence; getter/copy isolation; and schema rejection of wrong role/kind or fabricated authority/enforcement. Missing receipts and raw role strings remain unavailable, never automatically adopted.

Conditional proof9e58486d retains522 inputs/46 fresh-context Z3 4.15.4 queries (21UNSAT/25SAT). Whole models are reference-list/remaining-context pairs; source-copy guards cover both. Existing owner verifier behavior, source/path admission and faithful decomposition remain premises. Structural/value guard erasures describe abstract logical packets, not isolated concrete schema bypasses. Consistency does not imply authenticated issuer or protected admission; the separate authority obligation remains unimplemented. Prior host54622097/schema failure10b23185 and proofs6b829628/541fba9d/1098c889 are historical with their earlier scope limitations.

Consumer/native tests must retain original receipt artifact bytes/hash and exact original current document identity, compare the entire owner result before creating any duty, refuse same-content/different-document or stale/copied/crossed receipt custody, and retain original Field/Record/type authoring provenance without replacing it with producer manifest custody. A valid consistency observation must still expose issuerAuthority unverified and enforcement none; actual installed issuer/authority requires separate qualification. Multiple earlier receipts cannot be silently reused after a later model edit; receipt-chain reconciliation is still unavailable. No protected native/backend acceptance case is promoted; full26/132 remains unchanged.


## Explicit type receipt journal reconciliation — 2026-10-11

Run bun tools/security/check-record-type-journal.ts for host/strict typing/real Chromium evidence and the separately pinned Z3 runner tools/security/prove-record-type-journal-correspondence.py for conditional bounded-prefix evidence. Final host52ff1fd0 has522 inputs/47cases/48assertions; formale541930c has524 inputs/76queries(37UNSAT39SAT). Require multiple typed Fields, actual separate kind transitions, complete base and final-context checks, a32-event positive/33refusal, independently valid crossed-context event refusal, final Record and Field invalidation, imported bare roles with zero type entries, copy/getter controls and schema refusal of actual kind inspection events. Idempotent events are legitimate and remain retained.

Astra's feedback closes the schema branch/identity collision/witness nonvacuity gaps within this component. Bounded faithful-model/owner-verifier/final-retention predicates remain proof premises; shape tests and fresh-context solver replay cannot establish authenticated history or actual backend journal ingress. Existing exact-current inspection remains unchanged and an earlier receipt still refuses there. Truss104aa0fc native receipt-sidecar qualification is separately exact-current, not journal adoption. REPORT-ASSERTION-CLOSURE and US-056-AC1/AC2/AC10 receive prerequisites only; acceptance stays26/132 and all backend security cases remain governed by their original required positive support.


## Truss multi-Field journal consumer/native checkpoint — 2026-10-11

Truss mainaba57561 independently pins UMF e71613d9 journal inspection beside all historical owners. Private original-byte requests retain closed version0.1 whole journal artifacts (base and explicit ordered events), with current taken from the original prepared document. Complete owner results are compared before use; frozen type entries bind original event indices/pointers and exact qualified current reference bytes. Individual raw event slices are not separately stored; their original bytes remain in the whole retained artifact. Ninth optional private report argument enforces exact-preparation issuance before SQL. No core.recordType constraint entries, issuer authority, accepted/public admission or enforcement are added.

Final Truss host original-occurrence-inventory/84531857 retains732 exact inputs/eight bundle-entry-manifest triples and115 tests/1418 assertions/12files with strict typing exit0. Controls include mixed kind/type indices[1,3], cross-module same-name Records, opaque preservation, stale exact-current receipt refusal, kind-only pre-base bare roles, wrong/duplicate/lossy/gapped/crossed journals, complete loaded-output substitutions including an added type, immutable argument/copy isolation and cloned/crossed/falsy custody refusal before SQL. The private ledger preserves4MiB checked accounting; exact/+1/invalid-count controls are ledger primitive evidence only. A large actual owner-valid journal reaches an earlier scanner work refusal; no whole-pipeline population reaching only4MiB or shared operation heap/text/CPU admission is established. Historical typed host failures a0042f5c/12b58cef retain logs but not full failed-input snapshots;3f005572 predates final controls.

Final type-journals-native-cohort/00ff5a21 retains819 exact inputs and222 exercising PostgreSQL17.9 checks: all prior216 plus six named journal checks exactly once. Actual original staging yields three Records/two properties, exact schema_doc source text, whole request/journal bytes, independent owner profile and original event indices1/3/current reference bytes. Copied/crossed/falsy sidecars refuse before SQL; rollback removes catalog/property/document effects and retained journal consistency cannot authorize an ended report cut. Exact owned loopback fixture cleanup exits0. Astra independently verifies host/native pins, archives, outcomes and authority scope.54be2d9d is historical pre-final predicate/mixed-index evidence. An inherited exact-receipt non-promotion check used the wrong nested ruleName path; the final receipt/journal checks use the actual top-level field and injected-type negatives. Concurrent Truss6106084d/251a55e0 row-touch work is preserved; its new unused observe.sql/Python components are outside this executed snapshot. Every732/819 retained preimage remains exact after merge.

Upstream owner host52ff1fd0 and conditional proofe541930c remain separate evidence with faithful model/owner/final-retention premises; they do not prove this consumer mapping or backend enforcement. REPORT-ASSERTION-CLOSURE and US-056-AC1/AC2/AC10 receive journal ingress/native correspondence prerequisites only. Acceptance remains26/132 and the goal remains active. Next complete semantic/native family inventory and original type duty allocation while separately retaining authenticated issuer/current callable/cut authority, accepted persistence/publication/finalizer and protected data enforcement obligations.


### Same-key original-value source controls

B08, B09 and B11 for every backend must cover source interpretation, not only native
field types and selected key populations (US-056-AC6/AC7/AC9). Start from a
qualified ordinary caller whose protected predicate has an independently expected
nonempty result. Preserve each selected eligible key exactly once and every
required native domain/non-NULL carrier, then substitute a value expression that
creates a match and one that suppresses a match. Both changes must invalidate
admission before populated and empty application queries; restoration must
recover the exact original oracle result. Keep excluded installer mutations
separate from ordinary caller attempts to alter or replace the source.

Also mutate a transitive value-producing callable/cast or backing carrier and
relevant source owner/privileges/configuration without changing the outer field
names/types. Require current inventory/refusal under the held authority cut,
including an interleaving after initial admission and before final release.
Retain a positive authorized data update and an oracle for its new data cut;
a blanket rejection of all data changes is not faithful query execution. Raw
PostgreSQL view controls do not substitute for actual Truss/Ashlar property and
edge carriers or raw Delta expressions. These are required controls within the
existing cases; no additional passing case or reduced backend scope is implied.


The PostgreSQL source-census candidate must retain numeric OID aliases beside
native display names. Change a preexisting aggregate transition reference between
same-named overloads while retaining every pg_proc row; unaugmented catalog JSON
may remain identical. Require current-source refusal before application execution;
an inconsistent injected signature is a corruption control, never an admitted
aggregate. Also change an existing aggregate initial value, parameter ACL and
event-trigger enabled mapping independently of routine bodies. Include native
per-section exact-row and one-over boundaries, serialization overflow and complete
restoration. These are observer prerequisites; they do not prove complete native
catalog/JSON refinement, external executable custody, runtime GUC correspondence
or the final-release writer protocol. An explicit interior ABA countermodel must
remain beside endpoint-comparison positives; production admission requires the
held-cut protocol specified by CONTRACT-063.


### Complete inventory transport controls

B08/B09/B11 must independently qualify any partitioned private source-inventory transport (US-056-AC6/AC7/AC9/AC10). Exercise an image larger than one admitted response, exact chunk and image boundaries, a multibyte UTF-8 scalar crossing a chunk boundary, contiguous ordinals, exact total width, native descriptor/command/transaction correspondence and end-of-cursor. Missing, duplicated, reordered, malformed, inconsistent, oversized or prematurely terminated chunks must publish no accepted prefix. A well-shaped fabricated frame countercontrol must remain explicit: shape/coverage does not authenticate source custody.

Retain the actual pre-parser native frames and exact source/fixture/build closure. Every qualifying build must occur after its inputs are frozen and retain before/after checks. A materialized snapshot is an observation cut, not proof of the later execution/authority cut. Test caller-transaction refusal with actual uncommitted work and a preserved caller cursor; only the caller's later rollback may remove them. Fail the private journal at final native COMMIT completion and require no image release plus discarded transport. Cleanup must independently verify owned removal/absence; unknown fixture state cannot pass. These are transport prerequisites within the existing cases, not new accepted backend cases.

### Original Python Unix-socket census prerequisite — 2026-10-11

Truss final native packet `python-source-census/158f4a96-b643-479f-a107-3b6bf9e1d3ce` retains130 observations,124 exact frozen source inputs,1614 installed binary/library hashes and twelve synthetic host tests. Exact captured Python modules execute in a fresh worker against installed PostgreSQL16.15 pgserver binaries with TCP disabled; pg8000 1.31.5 original AF_UNIX transport and native-operation/result/deadline/outbound custody capture six complete images and two complete NULL refusals. The10,939,897-byte baseline spans2671 original4096-byte chunks; retained original Q and all T/D*/C/Z frames reconstruct it. Native data changes leave source stable, routine body changes differ, restoration matches, foreign/oversized inventories refuse, and lost local publication cannot replay. Post-detach retained original image/request/frames match exactly. Owned fixture stop0/status3/socket absence qualifies teardown. Astra reviews source freezing and raw reconstruction. Administrative raw captures remain private evidence, not authorized user disclosure.

Final [conditional formal packet](../../04-build/evidence/security/python-census-chunk-formal/81074bec-8953-4372-98a5-70bf877363c6/proof.json) retains eight Z34.15.4 queries (five UNSAT/three SAT), exact4096/16MiB constant checks, six source inputs and fresh-context replay. Separate truthful native chunks and actual assembler-copy premises establish conditional byte correspondence; arithmetic establishes partition and bounded advancement. Exact protocol, original-call provenance, UTF8/native SQL/custody refinement, full semantic observation and source/provider/issuer authentication remain unproved. SAT controls demonstrate that forged shape-complete bytes and truthful but stale captured source do not establish current execution authority. The nonrewinding1GiB bookkeeping ceiling is not whole allocator/heap/CPU assurance.

CONTRACT-063/STP-056 B08/B09/B11 and US-056-AC6/AC7/AC9/AC10 receive prerequisites only. No accepted backend case is added. Protected provider/issuer composition, complete cooperative operation handback, held source/authority cut and actual graph/backend enforcement remain required for the unchanged132-case goal. Historical earlier native and formal packets remain immutable and separately scoped.

Fresh full gate `acceptance-runs/f1e59950-1f2b-43b0-bd2a-606fc9bbe5dc` executes all26 registered cases successfully and correctly exits1 for106 missing executable bindings among132 required cases/28 criteria. Native/raw receipts and original per-case stdout/stderr/timing/run IDs are retained. No new census prerequisite is counted as backend enforcement. The goal remains active.

### Catalog source-cut feasibility and publication constraints — 2026-10-11

Truss final administrative native `python-catalog-cut/03c0a9ed-455a-49f4-b8ff-6356ea14c8ee` retains exact frozen worker/SQL/module preimages, native installed PostgreSQL16.15 binary/library digests, private source images, actual lock rows, type-sensitive expected/observed checks and owned Unix fixture teardown. It is materialized administrative pg8000 output, not the protected bounded NativeCall receiver. Catalog ShareLocks block seven future routine/role-default/membership/owner/column/policy/foreign-route writes (55P03), but do not drain an already applied uncommitted catalog change. All43 locks can be acquired before the first census while an active pending writer has no retained pg_proc RowExclusiveLock; that writer commits, the repeatable-read image stays333 and actual routine execution returns444. A preexisting snapshot also remains stale after lock acquisition. Ordinary data writes are not protected by catalog locks.

A participating transaction advisory barrier separately retains an independently observed pending reader ShareLock, drains it after writer commit, allows a fresh post-barrier READ COMMITTED source and execution555, blocks a new participating writer, and permits it after reader release. A nonparticipating administrative writer bypasses it. A second database takes the same key, commits shared-role membership, changes the first database's census and changes native pg_has_role false to true while the first reader still holds its barrier. Complete participation and actual cross-database/shared-catalog scope are missing obligations, not proven by the prototype. The fixed probe key is not an admitted installation/generation key.

Final [conditional ordering packet](../../04-build/evidence/security/catalog-cut-ordering-formal/2e805ec4-991f-4c9f-a3d1-4d83c2b59d35/proof.json) retains six Z34.15.4 queries (two UNSAT/four SAT), frozen inputs and fresh-context replay. It models one source commit and one independent fact publication. Fresh post-barrier snapshots plus complete commit-time exclusion imply modeled current correspondence; old snapshots, pending catalog commits, early release and source-only protection of independent authority retain counterexamples. Faithful observation/current execution, native barrier ownership, complete writer coverage and release remain premises. This is not arbitrary multiple-transition/ABA, SQL/driver/cached-call refinement, authenticated provider/issuer or complete operation handback proof.

CONTRACT-063, TD-056 and TD-057 now explicitly require pending-writer drain, commit/abort-lifetime participation, post-barrier snapshot freshness, all relevant source/data/authority scopes, actual callable/plan correspondence and hold through final protected disclosure. STP-056 B09/B11/B12 and US-056-AC7/AC9/AC10 plus lifecycle revocation/drain cases must exercise these controls before positive qualification. No backend case is promoted. Existing full gate f1e59950 still has26/132 accepted executions and106 missing bindings; the contract source pin changed and a fresh full gate is required. The full objective stays active. Next implement the original held-cut producer with native transaction-lifetime writer participation and fresh observation, retaining explicit refusal for unknown producer/snapshot/cross-database coverage.

Final fresh full gate `acceptance-runs/128142e3-af16-42d7-9b5b-de03a9cb1253` executes all26 registered cases successfully;106 missing bindings among132 required/28 criteria still make exit1. All973 per-case source references match after the CONTRACT-063 update. No prototype or counterexample is promoted to backend enforcement. Prior f1e59950 is historical for the earlier contract version. The full goal remains active.

### Required B11/B12 history controls — 2026-10-11

US-056-AC9/AC10 retain the original B11/B12 cases. Add these schedules inside each backend implementation's original runner, not as replacement acceptance cases: admit a source, change it, execute, then restore identical source bytes; prior qualification must not authorize the intervening execution. A before/after image comparison alone is insufficient. Separately compare a truthful generation, commit a relevant change before actual use, and require held-cut exclusion or refusal. Exercise final release after execution: a source/authority writer must remain blocked until the last protected disclosure, not only until SQL completion. Unknown writer, generation, authority-provider or native callable correspondence must refuse before output.

Truss native `python-catalog-cut/8faf405c-05eb-47a0-b2a2-e7353f70f0c7` provides a concrete administrative two-commit ABA witness: byte-identical endpoint images and intermediate777 execution. Its ordinary application-data mutation demonstrates source census omission only; the fixture data is not an actual authorization provider. UMF [history proof](../../04-build/evidence/security/catalog-cut-history-formal/a3f69385-9520-43ec-8c54-3dc11a460862/proof.json) checks an arbitrary-step conditional finite-history invariant and final-disclosure interval, with coupled ABA/check-use and missing-coverage counterexamples. These uncited component experiments are prerequisites; they do not satisfy the required original backend runner's AC citations, ordinary protected calls, independent oracle or native authority/publication evidence. No132-case registry binding or story completion changes. Full acceptance remains26/132,106 missing.

### Required original acquisition lifetime controls — 2026-10-11

B11/B12/L03 must bind actual original acquisition and transaction/savepoint custody, not a returned xid/PID tuple. Exercise autocommit, rollback to a savepoint preceding acquisition with parent xid already assigned, and same-transaction epoch issuance. Require invalidation/refusal before protected use after guard loss/change, and exclude relevant writers through final disclosure. Separately exercise pending issuer commit/abort drain before fresh native snapshot, inherited REPEATABLE READ/SERIALIZABLE, READ ONLY, elevated invoker and stale/mismatched generation refusal. Preserve complete original bounded request/response frames and lost-reply retention without replay. A historical decoded tuple alone does not establish the held interval.

Truss private fresh-epoch packet0db20a3f-49d5-47a9-bd0c-d98c6b99c567 exercises native lifetime countercontrols and83 component observations, with maximum selected native response and original Q/T/D/C/Z. Administrative synthetic evidence and historical response-only custody do not replace the original protected backend runner, authenticated authority, ordinary business calls or complete cleanup/handback matrix. US-056-AC9/AC10 receive prerequisite evidence only. Full acceptance remains26/132,106 missing; no binding or completion promotion.

### Acquisition ancestry and guard induction — 2026-10-11

B11/B12/L03 require original scope identity, not savepoint name/depth. Acquire inside an original savepoint, release it and retain the lock under the parent; later rollback across that parent must invalidate. Rollback to a savepoint created after acquisition must preserve the lock if the native scope survives. Rollback before acquisition followed by recreating a same-name/same-depth savepoint must never restore the old acquisition. Commit, rollback, failed control/unknown native completion, generation replacement and lost original boundary/session custody must close admission before another protected use. Unknown native ancestry refuses; no synthetically copied coordinate reauthorizes.

During an admitted protected interval, same-transaction epoch issuance must refuse before effects or invalidate admission before a deliberately authorized lifecycle change; parent xid equality is insufficient. Participating external writers must remain excluded through final disclosure. Native SQL source/profile/authentication and full writer closure remain separate obligations. Require original completion evidence and unchanged epoch on refusal. A guard check followed by an unguarded effect/disclosure does not satisfy these cases.

[Conditional lifetime proof](../../04-build/evidence/security/epoch-acquisition-lifetime-formal/073f51ce-6c8e-43d6-b03d-33633bba8175/proof.json) checks16 formulas (seven UNSAT/nine SAT), including arbitrary-event preservation, release/rollback-after positive witnesses, same-xid rollback/self-change and recreated-depth/nonparticipant counterexamples. The native classification/implementation is a premise; this is not an implemented guard, original protected runner, concurrency proof or acceptance binding. US-056-AC9/AC10 and lifecycle revocation remain open;26/132 accepted,106 missing.

### Required native settlement and original guard-use controls — 2026-10-11

For B11/B12/L03, pause an original rollback after its native response but before host lifecycle settlement. Require no positive liveness claim during the in-flight call; independently prove whether the native lock survived, then require the appropriate settled ancestry result. Repeat with lost/incomplete control reply while transaction status remains T: admission must close even if the lock remains held, and unknown settlement must not trigger automatic native replay. Copied acquisition, replaced original ledger root/pending session and exhausted capacity refuse without partial publication. A failed ordinary native call must invalidate before invocation, just as a successful same-writer source change does.

An instantaneous `live()` result must never authorize a later unguarded operation. The original protected dispatcher must bind check, native use and final disclosure to the same surviving source/authority acquisition under the admitted concurrency protocol. Truss 162755fe supplies302 component observations,16 host controls,28 existing native regressions and seven original response captures; it does not implement that protected check/use/disclosure composition or authenticate the provider. Refreshed conditional formal0e3dbcb5 retains16 blueprint laws, not refinement of the live component. US-056-AC9/AC10 remain open; no registry binding changes and full acceptance stays26/132,106 missing.

### Original release archive cut regression obligation — 2026-10-11

For Truss B11/B12/L03, require original configured release bytes to stay uniquely selected through the declared protected use boundary. Exercise a second matching archive INSERT as well as UPDATE/DELETE; row-level lock evidence alone does not establish phantom exclusion. A preexisting archive table writer and row locker must refuse under the selected bounded acquisition profile. Establish old REPEATABLE READ and SERIALIZABLE snapshots, commit a matching insert from an independent connection, show the old count differs from current, and require selection refusal before returned policy bytes. Verify exact isolation refusal provenance, including READ ONLY.

Retain native RELEASE/reparent, later rollback preservation, rollback across acquisition with unchanged parent xid and transaction-end release. The final twelve-test Trussc870eec9 component and four-failure omitted-table-lockcc13998c control qualify the private native archive selector only. Conditional UMF04cc4ef2 analysis assumes freshness and external exclusion. Whole-source/current-authority stability, same-writer exclusion, original host acquisition use, scan/resource accounting, authenticated capture, and final report publication must still be established by the actual backend runner before these required case IDs pass. No acceptance case is added, removed or promoted.

### B10 native catalog/statistics observation obligations — 2026-10-11

For all four backend B10 cases, exercise ordinary actor access to actual native
catalog/statistics/plan/error and alternate-endpoint channels in addition to denied
private row/count operations. Vary the actual private population without changing
public resource outcomes and compare every declared untrusted observable. Include
an analyzed-table cardinality control and applicable table/index size or equivalent
native metadata. Distinguish physical aggregate statistics from logical association
counts; do not infer graph coverage from a flat relation. Preserve original oracle
and source/channel inventories. Test fixture counts alone cannot certify complete
native observation coverage or noninterference.

Truss native private ACL exclusion is insufficient: its ordinary catalog-only
role observes pg_class.reltuples changing1→2 while direct private SELECT/count
still refuse42501. A positive mediated profile must prove private executor/
receiver credential custody and deny every alternate untrusted SQL/diagnostic
route. A direct SQL profile must independently qualify all native diagnostic/
catalog/callable restrictions. Merely naming a route mediated or asserting a
configuration boolean is not a tested enforcement boundary. This tightens test
interpretation under CONTRACT-063 and US-056-AC8; B10 remains required and unbound,
and26/132 acceptance is unchanged.

Retained native counterexample and integrated composition: [Truss main3bce4c77 evidence](https://github.com/DocumentDrivenDX/truss/blob/3bce4c777d5c9b631482084bd792337e18e2f27a/docs/helix/04-build/evidence/python-psycopg-epoch-cut/ed2ea7b9-ad94-40ed-b12d-84e346e20a7e/receipt.json). Its184-method component pass does not establish hidden-fact observation isolation.

### Closed command/receiver boundary qualification tests — 2026-10-11

For B04/B05/B10/B12, explicit table/catalog/routine ACL denials must be paired
with native command controls. Truss87e4b672 supplies a fixed opaque-definer
EXPLAIN ANALYZE BUFFERS counterexample after catalog SELECT/EXECUTE revocation:
same output and one row, shared hits1→304 under private growth. This is not an
exact cardinality oracle or qualified policy runtime. Include executing EXPLAIN,
COPY, prepared/cached commands, user-owned wrappers/operators/types, errors/logs,
stream/cursor and alternate credential/endpoint paths applicable to the selected
profile. Do not claim complete closure from this finite list.

For a mediated profile, exercise the original full Weft query interface and its
complete source/security/execution obligations. Do not require a separate
UMF/Truss SQL allowlist or blanket SQL/EXPLAIN/DDL rejection. Exercise refusal of
unbound private-executor commands, caller actor/authority flags, decoder callbacks,
copied handles and alternate direct access while retaining original authorized
semantic outcomes. Qualify every selected native command observable and authority
boundary; inability to enforce one remains an implementation gap, not authority
to redefine the product query surface.
Capture independent actual routing/credential/native endpoint inventories before
and after adversarial changes. Require the native receiver and original trusted
semantic producer to enforce the same source/current-authority/publication cut;
private executor handles and cells must never become user outputs. TD-056 exits
C01–C07 sequence these prerequisites without adding/removing case IDs or accepting
caller flags as evidence. All original132 cases remain required;26 pass and106
remain unbound. B10 and complete protected observation isolation remain open.


## Current result and physical component coverage — 2026-10-12

Weft mainfdb2a3e's original Rust run passes257 unit,68 security-admission and3
literal tests. The source pins were independently matched to current files; this
is verification of the retained run, not a new rerun. The following supersedes
only the older component-gap descriptions; the original backend cases remain open.

| Control | Current exercising evidence | Still required at each native backend |
| --- | --- | --- |
| R08 active withholding |24 supplied-fact controls across active/false mask, value/null/absence and four candidate cells. Active Withheld accepts only its value-free cell. | Authenticated original facts; installed mask/query behavior; bag/retained/history/diagnostic bypass controls; final protected publication. |
| R09 exact presence | Optional declarations require Original and Absent; all six value/null/absence substitutions and omitted presence metadata refuse. | Actual carrier/codec/presence correspondence; native null/absence/transform/withheld controls at ordinary API and SQL routes; historical/source mappings. |
| R11 bounded issuance | Shared ledger now accounts for opaque numeric spelling; physical declarations test depth, per-operation and aggregate limits. | Native workload/resource/refusal evidence and no partial output/effects; external immutable evidence tied to exact source/build. |
| R13 physical declaration structure | Unique installation/execution IDs; bounded nonempty NUL-free SQL; contiguous parameters; typed provenance shape;512 operations and16384-slot boundaries. | Original SQL/parameter origin/domain correspondence, complete capabilities and obligations, actual native installation/DDL/effects/rollback/current authority. |

R13 is a component control, not a new acceptance case or an SQL feature allowlist.
Its checker admits shape only; even nonempty nonsyntactic SQL may pass shape and
must fail its later actual backend/native admission. Successful shape, cell or
supplied-fact checks issue no execution authority and public security compilation
remains blocked. Supplied-truth checks do not establish original value or absence.

Next integration controls: mutate SQL and parameter provenance after shape checks;
substitute a same-shaped operation from another original query/target/action;
change native function/role/mapping source before first effects and final release;
remove a selected capability's obligation; fail mid-installation; and retry after
unknown settlement. Require refusal/rollback under the original actual host/native
protocol. Caller-produced coverage flags, matching labels, endpoint hashes or a
pure check result cannot replace that protocol.

`../../04-build/evidence/security/weft-component-coverage-20261012/` retains the
current original run and control mapping. No B07/B09/B12/B15/B16 or lifecycle case
is accepted from it. All132 cases remain required. Databricks workspace/catalog
and actual ordinary identities for Ashlar/Delta are unresolved; do not simulate
those roles with an excluded administrator or claim local PostgreSQL proves them.


### Current compiler refusal witness — 2026-10-12

The older activation-compiler-boundary.py/witness remains historical evidence: it
uses the stale owner checkout and an older transport. A separate current witness
now builds the actual compiler from exact main40b812c and executes nine original
requests through ordinary/security registration boundaries. Real registration
reachability, missing registration, supported mask source, unsupported path/mask,
prohibited original-field filtering and invalid report/history inputs retain
exact callback observations and refusal codes. All protected requests emit no
SQL/parameters/plan and never invoke the registered backend's lower callback.

Run `python3 tools/security/current-compiler-boundary.py --weft-root <checkout>
--expected-weft-commit <exact-commit> --output <receipt-directory>`. The script
requires a clean tracked compiler source at that exact commit, freezes declared
repository/build/witness/binary inputs and checks them unchanged after all cases.
The private witness forwards exact requestJson bytes to the actual compiler.
`../../04-build/evidence/security/current-compiler-boundary-20261012/receipt.json`
retains exact requests/results, original build logs, source digests and preimages.
Pinned build/runtime inputs are observed premises; external Cargo/toolchain
closure and held source/authority lifetime are not proved.

This is current compiler-refusal component evidence for B09/B12 and AC7/AC10
prerequisites, not a native preservation runner or admitted lowering path. The
original native B09 runner must use current original preparation inputs before
obtaining an installer, retain prior inventory and ordinary results across each
refusal, and cover actual history/composition and partial installation controls.
No old receipt is rewritten and no original case is promoted. All132 required
cases and106 missing executable bindings remain in scope.


### Source-current native refusal preservation — 2026-10-12

`tools/security/current-native-refusals.py` freshly executes the nine pinned
current-main compiler cases while the existing owned PostgreSQL17.9 raw fixture
is protected. Each original response retains exact factory/lower observations
and diagnostics, no executable output, unchanged complete captured inventory/
authority facts, and exact independently authored ordinary-actor resource IDs.
Three actual TCP SCRAM actor connections per case retain original session/current
user, native PID and ROLE=none. The excluded administrator reads all five resources
as a separate negative control. All82 observations pass.

The harness validates the original compiler observation digest and exact nine-case
population/expectations before creating its labelled disposable container. Three
tampered-artifact/population/expectation controls refuse before the native phase.
The final owned-label/removal/absence check passes and retains Docker's exact
response. Prior database-default and case-sensitive absence-check harness defects
remain separately recorded; neither is counted as a passing native run.
Receipt: `../../04-build/evidence/security/current-native-refusals-20261012/receipt.json`.
Native source preimages are retained; original compiler preimages are referenced
from the existing current-main witness archive without another large duplicate.

Run `python3 tools/security/current-native-refusals.py --compiler-receipt
<current-compiler-receipt> --output <receipt-directory>` against the isolated local
Docker runtime. Existing receipt pins must match before original native execution.
This is B09/B12 and AC7/AC10 prerequisite evidence, not candidate installation,
admitted source-to-native semantics, actual history/composition, partial policy
activation or final publication lifetime. No original backend case is promoted.
All132 cases and106 missing executable bindings remain required.


### Native receipt finalization failure controls — 2026-10-12

The current refusal harness now retains native workStatus separately from cleanup.
A successful native run with unverified cleanup receives
`native-passed-cleanup-unverified`, never the accepted passed status. Cleanup
transport/ownership/removal failures return evidence rather than replacing the
original native exception or preventing receipt serialization. Only an exact
owned-container absence response can verify completion; prefix-name responses
refuse. Frozen reviewed cleanup source is compiled directly, without relying on
an unrelated imported module.

Four failure-path tests pass, including foreign ownership, transport/removal
uncertainty, wrong/prefix names, original failure retention and no-creation paths.
The final source-native replay again passes82 observations and actual owned
removal/absence. Receipt:
`../../04-build/evidence/security/native-receipt-finalization-20261012/receipt.json`.
This corrects receipt truthfulness for B12/AC10 prerequisites; it does not qualify
full activation/lifetime or promote an original backend case.


### PostgreSQL 18 column-privilege qualification procedure (2026-10-15)

P01 executes `tests/security/native/pg18-column-withhold.py` against the exact
PostgreSQL 18.6 image digest in its independent oracle. Three fresh ordinary TCP
SCRAM identities retain their original membership-filtered row sets. Only
id/label/public-note columns are granted through an ordinary inherited reader
role; secret/audit columns have no ordinary or PUBLIC SELECT, and no ordinary
table SELECT exists. Null remains a native permitted value. Direct, mixed,
whole-row, empty, LIMIT 0, expressions, filter/order/group/join/aggregate, COPY,
prepared execution and invoker-view access to withheld columns must refuse the
entire statement with SQLSTATE 42501 and no result rows or per-cell disposition.

The excluded installer separately grants table, column, inherited table, PUBLIC
column, pg_read_all_data and owner-view routes. The original ordinary identity
must actually disclose the independent secret oracle under each weakened route;
restoration must recover denial and exact permitted rows. These are retained
negative controls, never ordinary profile paths. Pin engine/image/client builds,
source digests, role/membership/ACL/policy inventories and authentication controls;
cleanup only the generated container with the matching ownership label. Original
P01 assertions/criteria/60s timeout remain unchanged. This is fixed native raw
carrier qualification only: all other cases remain separately required and no
17.9 receipt is promoted to PostgreSQL18 or complete backend qualification.


### Additive PostgreSQL 18 replay of existing native cases (2026-10-15)

M2/B-SFP-007 replays the original fourteen accepted raw cases B01–B07, B11,
B13–B16 and L01/L02 using separate sources under
`tests/security/native/pg18-replay/`. Exact PostgreSQL18.6 image/server/client
builds are observed afresh. All original17.9 runners, oracles and individual
receipts remain byte-identical; prior evidence and the mechanical mapping are
retained under `evidence/security/pg18-replay-20261015/`. Only execution/source/
evidence bindings change. Every original assertion, criterion and timeout remains.

The replay retains the original actual driver paths (Bun SQL for B05; inventoried
pg8.16.3 and original Truss runtime for identity/scale/writes), immutable hash
collision strings and expected hash, all1k/100k/1M scale populations/plans and
1ms timeout/recovery vectors, and all original read/write/field/effect/journal
expectations. Engine declarations change only in additive18 oracles. A version
upgrade never changes expected data to match an observed failure. Single-statement
permission/timeout/domain errors require exit3, empty stdout and exact native
primary SQLSTATE; intentional multi-error recovery retains its distinct protocol.
Native image qualification precedes SQL. Ownership-checked container and anonymous
volume cleanup precedes receipt publication; inventory digests include cleanup.

This is fresh engine-version evidence for the declared original fixed vectors.
It does not complete M2 or any full backend profile: additional field-protection
procedures, remaining P/B/L cases, native current-authority/effect custody and
actual Truss/Ashlar/Delta consumers remain required. Never infer18 evidence from
an old17.9 receipt. The full158-case gate remains authoritative for actual execution.


### Fixed native assignment-intent component — 2026-10-15

Original pg-raw.P04 remains unbound under its unchanged assertion and60s deadline.
The retained PostgreSQL18.6 source-bound component exercises800 selected checks:
original and blind positives; separate ordinary-object/Field negatives; transformed
and withheld mask-output/unrelated assignments; no-op and NULL/int64 cases;
actual same-session masked/withheld guesses including NULL; complete selected
business-row/effect checks; all-nine effective owner/carrier privileges; absent
Resource Keys; nonvacuous UPDATE-only versus old/new/aliased/whole-row RETURNING;
strict public error channels; and removed-guard equality/preimage counterexamples.

Both logical guards consume captured native Staff facts and Resource before
values. Their existing unchanged-Field semantics remain intact. Native explicit
assignment intent is stricter: check authorization before hidden equality, return
only acknowledgment to authorized callers, and disclose no affected count.
The exact supported authored source must be admitted before fixed SQL installation;
substituted/unknown source refuses. Actual catalog premises and exact routine body
are asserted. No general compiler or source/authority/lifecycle refinement follows.

Seven conditional response-only formulas replay5UNSAT/2SAT, with NULL/SQL/timing/
locking refinement excluded. Native finite NULL controls are separate evidence.
Evidence and failed initial runs are retained in
`../../04-build/evidence/security/pg18-mask-write-20261015/`.
Independent final implementation review and the original binding/full gate remain
required. The last whole gate is still43 accepted/115 unbound of158 required,
34 criteria; the shared implementation goal remains active.


### Fixed P04 profile accepted — 2026-10-15

The original pg-raw.P04 binding now passes freshly:807 governed observations in
41.2s under the unchanged60s deadline. Independent Astra replay passes806 checks,
39 diagnostic/source controls, five actual native weakenings and13 binding checks.
All158 original assertions, allocations and deadlines are preserved; only P04's
execution/evidence/source metadata changes. The full gate reaccepts all43 earlier
cases and accepts P04, yielding44 accepted/114 required unbound/158 cases and34
criteria. P03/B08 and the full shared implementation goal remain open.

The earlier planned/component paragraphs describe intermediate checkpoints.
The final evidence packet includes exact source/runtime pins, role/DDL premises,
full business-state witnesses for refusal phases, native counterexamples,
conditional formal formulas, independent archive and fresh gate. This qualifies
only the exact authored PG18.6 raw profile. Privileged-role probes are the named
owner/read-all routes and effective privileges, with fresh trusted bootstrap/no
extra memberships as a premise; continuous role/DDL closure is not proved.

A general mutation producer still must retain actual explicit assignment Field
intent independently of before/after equality. It cannot infer intent from a
changed-Field set or use a logical no-op permit as native assignment authority.
General source lowering and current-authority/lifecycle integration remain
required beyond this fixed native binding. No SQL refinement theorem follows
from the seven response-only conditional formulas.


### Planned P07 native archive verification — 2026-10-15

Preserve the original P07 assertion, US-056-AC7 allocation and60s limit. Use real
PostgreSQL18.6 Anonymizer provider labels in an owned immutable-image fixture;
never fabricate pg_seclabel rows or call authored text native evidence. Assert
complete native local/shared label capture and exact provider/object/subobject/
UTF8 identity against an independent fixture oracle. Test existing source owners
in Bun and Chromium on original JSON/YAML round trips, future opaque native data,
actual interpretation refusal and zero dispatch. Native ordinary masked output,
base/column write denial and protected definitions/ACL/canonical state must remain
exact before/after; excluded original reads demonstrate that labels are metadata,
not permission or independently qualified enforcement. Include missing/extra/
changed-row and authority-flag substitution controls. Retain unverified native
archive obligation, exact engine/extension/binary/runtime pins, independent review
and verified cleanup. Formal applicability is implementation correspondence,
not a newly claimed SQL/serialization theorem. P07 remains unbound pending evidence.


### Native SECURITY LABEL archive correspondence — 2026-10-15

The fixed PostgreSQL18.6/Anonymizer3.2.3 archive spike captures complete local
and shared native label populations in one SQL snapshot, preserves exact
identity and UTF-8 bytes through existing protection source/catalog owners and
JSON/YAML, and exercises actual interpretation refusal. Native labels remain
opaque data; their authority/enforced flags never grant authority. Ordinary
masked reads and selected protected home data, DDL, ACLs, routines, triggers,
inheritance and role memberships remain unchanged. Dynamic masking stays off.

Astra Ultra's final scoped review has no remaining blocker:45 native component
observations,103 Bun/Chromium controls,42 pure capture/diagnostic controls and
17 binding checks pass. Seven actual native weakenings are detected across
explicitly retained source stages. No new calculus or implementation-refinement
theorem is claimed. Generic native masking, compiler activation, current-writer
closure and lifecycle admission remain outside this fixed archive result.

Original P07's assertion, acceptance criterion and60s deadline are preserved;
all other157 case definitions are exact. The fresh governed gate and final
browser receipt are recorded in `evidence/security/pg18-native-archive-20261015/`.


### Native actor preflight evidence integrity — 2026-10-15

Exercise pending-before-CLI, preexisting-success invalidation, stage-specific partial failures, unknown counts, malformed response/configuration and redaction with synthetic non-credential fixtures. Check aliases, duplicate ordinary actors, one-actor insufficiency and mismatched contexts. Use actual owned subprocess termination and overlapping processes to verify pending visibility, working-directory-independent canonical output and latest-pending-attempt publication; older success must not overwrite newer failure, and a terminal attempt may not republish. Retain source-drift and evidence-write failure controls. Test malformed host text before URL normalization, including controls/space and credentials/query/fragment material. No synthetic actor supplies native identity/grant evidence.

Independently retain one live native observation outcome using configured profiles, including sanitized failure; never reuse historical success after an incomplete attempt. Two independent non-installer principals, a dedicated disposable namespace/compute and real SQL/grant inventories remain required for original Delta/Ashlar backend cases. This POSIX host-tool work changes no semantic/browser kernel and closes no original native acceptance case.

### Private computation-driver integration acceptance — 2026-10-15

The TD-056 private computation child is implemented and tested through the actual
Truss Python pipe. Native DB-derived current-Subject/fact capture and release
integration remain unfinished. Preserve original B08/B12
and lifecycle assertions; component tests cannot promote them.

| Required check | Acceptance link | Evidence needed before native admission |
| --- | --- | --- |
| Locally issued extension semantics | US-056-AC1/AC2/AC7 | Original installed factory accepts only its closed selection; serialized/copied handles and unknown/extra packages refuse without staging |
| Exact private original handle, source closure and caller/Subject cut | US-056-AC1/AC2/AC10 | Native capture plus genuine child compilation; fabricated source/hash/handle and alternate caller controls refuse |
| Designated primary action equals original owner read action | US-056-AC1/AC6 | A different weaker read-purpose action with otherwise valid owner/cut pins refuses before planning or staging |
| Source-derived provisional modes, independent of the mode-free Weft operand ledger | US-056-AC6/AC7 | Original inspector/base constraint drives the scan union; actual selected routes must agree; hidden-original-only Fields never require unselected public rendering |
| Original read cells, eligible row identity/order and route/action association | US-056-AC6 | Actual Weft occurrences, full population before filters/LIMIT, typed cell/Key correspondence, wrong/unknown/missing action and mixed-domain controls |
| Empty population dependencies | US-056-AC6/AC7 | No shortcut around original scoped rule/action/source validation, including field-free COUNT |
| Practical input/output, deadline and process/staging limits | US-056-AC7 | Exact profile boundaries and failure cleanup; original batch ledger unchanged; independent route ledgers do not establish aggregate work or heap bounds |
| Untouched refusal/unknown/absence/null/literal transport | US-056-AC6/AC10 | Byte/token and typed identity checks; no denial-to-empty or unknown-to-permit normalization |
| Child loss, malformed/truncated/duplicate/reordered/late reply and replay | US-056-AC7/AC10 | No private staging consumption or ordinary output from incomplete/mismatched replies; next operation freshly admitted |
| Authentic held context through SQL/decode/release and revocation | US-057-AC1/AC2/AC3/AC7 | Native concurrent schedules, actual driver/role identity, guard/capture/release and failure evidence |

Require actual raw and graph capture fixtures and native source inventories;
copying the raw fixture does not qualify graph storage. Databricks/Ashlar need
independent principals, native compute/publication and current-authority evidence.
No row is passed by this table; all named missing tests remain required.

### Independent current-source native scalar edges — 2026-10-15

The finite physical oracle passes17 actual current-query SQL cases and4 original-boundary refusals on PostgreSQL18.6. Require exact code/stage for negative inputs, original text/OID/domain checks, negative SQL sensitivity and owned container/volume absence. These conditional stage-value cases do not replace native action/issuer/sideband/release acceptance. See the [retained packet](../../04-build/evidence/security/current-scalar-native-edges-20261015/README.md).

### Private computation child implementation — 2026-10-15

The private Bun child now implements original source compilation, route inspection
and atomic batch plus route evaluation through the actual Truss Python pipe.
The final ABI uses big-endian uint32 framing and nested `initialize.sources` with
all six closed fields. `extensionSelection` is null or exactly the local actions
0.1.0 selection; the original factory issues the opaque handle. `sourceReceipt`
is SHA256 of the exact initialization header plus payload, solely correlation.
Each child accepts exactly initialize, inspect-routes, evaluate, with unique
bounded request IDs and identical owner/ordered routes. Failure is terminal;
original semantic refusals remain untouched private results. No database
credentials, public server, native issuer or guarded release is added.

The builder discovers the original dependency closure, pins before the actual
build, verifies the same closure and post-build pins, and retains original
third-party license notices. Independent Astra controls and real pipe tests are
retained in [the child packet](../../04-build/evidence/security/current-query-child-20261015/README.md).
Native current-Subject/fact capture, primary-action correspondence, typed Weft
contributor lineage and held-context release remain required integration work.
No backend acceptance case is promoted.

### Actual compiler packet and original child correspondence — 2026-10-15

Five actual typed Weft packet cases pass original UMF source inspection, atomic
read/action/scan evaluation and route selection over the supplied original
fixture cut. Exact populations/Cells and empty-tuple COUNT scans are checked;
inactive assignment denies without rendering. This is conditional computation
evidence, not SQL/native authorization, contributor lineage or guarded release.
All original backend cases remain required and acceptance stays 45/158.
See [retained interop evidence](../../04-build/evidence/security/weft-current-child-20261015/README.md).

### Separate live-original integer SUM source profile — 2026-10-15

The new original fixture `live-original-integer-sum-source.json` selects aggregate
original-authorized mode in its ontology and read-mask catalog, under distinct
policy/ontology/catalog/owner/cut revisions. Its required signed64 salary remains
a live original Field; ordinary read rendering stays the String `[private]`.
The exact separate `query-original-salary-sum` action has original-authorized
purpose and Project-membership requirements. The old prohibited SUM source and
unsupported compiler factory remain unchanged. Fixture metadata never issues a
compiler designation or action grant.

`required: ['nullity']` is only a necessary scalar presence/null-vs-absence
dependency. It proves neither additive transform preservation nor scalar/native
admission. The selected profile also requires exact live original domain/codec,
current independent action and read eligibility for every contributing resource,
actual typed compiler provenance/contributor identities, exact arbitrary-precision
integer accumulation, nullable scalar NULL on empty input, and guarded release.
Source route selection alone cannot discharge those obligations. Disclosed or
transformed SUM, Decimal and other domains remain required future work; this
first live-original capability does not narrow the full objective.

Semantic tests must retain active permit and String mask, inactive deny, missing
action permit, missing dependency coverage even for empty resources, absent-live
input and unchanged old-source refusal controls. Native acceptance additionally
requires overflow beyond signed64 accumulation, negative/cancelling values, empty
and grouped-empty NULL distinction, exact contributor bags and concurrent
revocation/source changes. No backend acceptance case is promoted by this source.

The corpus also renders salary to verify the independent read mask. A SUM-only
query does not select that public Cell and must not require unselected rendering;
its hidden original operand still requires exact read/action/presence admission.

### Independent native fact-to-child component replay — 2026-10-15

Original Truss37511eb8 tests pass from an isolated 1,124-file tracked snapshot on
PG18.6: native six-object/five-type capture, original UMF Key receipts, original
child, exact r1permit/r2deny and integerToken9007199254740993. Both original tests
and owned runtime/PID/directory cleanup pass. This contributes component evidence
to US-056-AC2/AC6/AC7; it closes no native query case. Installer capture and
diagnostic owner/cut with a separately observed ordinary Subject do not prove
authenticated same-held-context admission. Registered owner/Weft binding, original
occurrence/action/projection checks, exact typed staging/contributor bags and
current guard/revocation/release remain required, as do raw/graph and other
backend/principal cases. Acceptance stays 45/158 accepted, 113 unimplemented.
See [the original replay packet](../../04-build/evidence/security/truss-current-facts-replay-20261015/README.md).

### Public guarded-query replay and alternate-read gap — 2026-10-15

Original Truss9a495 public workflow passes with ordinary Subject, registered
source, exact original child/CQP, masked projection, signed64 predicate, public
budgets and final two-host checks. Independent native probing also confirms
granted query_objects returns both permitted and denied raw Resource values
to that ordinary actor. Registration is not global protected-source activation.
CONTRACT-063 / US-056-AC5 remains unmet until alternate native/public reads are
closed or equivalently guarded; raw-table SELECT denial alone is insufficient.
No backend case promoted; 45/158 accepted,113 unimplemented unchanged.
See [original replay, Astra review and exact reproduction](../../04-build/evidence/security/truss-current-query-replay-20261015/README.md).

### Actual explicit SUM packet / original policy interoperability — 2026-10-15

Five supplied-cut cases plus two producer controls pass with exact new Weft
capability and unchanged original UMF child. Whole typed operations, independent
SUM action, global/grouped nullability, live original salary origin, branch
indices and raw-only rendering independence are checked. This contributes to
US-056-AC2/AC6 semantic correspondence only; no native aggregate guard or
backend case is promoted. Acceptance45/158,113 unimplemented unchanged.
See [scoped evidence and review](../../04-build/evidence/security/weft-sum-child-20261015/README.md).

### External delegation closure counterexample — 2026-10-15

Independent native testing of in-progress activation confirms a pre-existing
PUBLIC-callable outside-schema SECURITY DEFINER function owned by runtime owner
can read all six objects after truss-only grant lockdown, while ordinary raw
SELECT is false and the positive guarded query still passes. Denied Resource
rawsalary and hidden Assignment facts escape. This keeps US-056-AC5/AC8 and
B04/B05/B10/B14 open; CONTRACT-063 requires complete delegated authority closure.
Truss is implementing external routine/view admission checks; no verified fix
or backend promotion is inferred. See [exact counterexample](../../04-build/evidence/security/truss-external-delegation-20261015/README.md).

### Independent explicit protected activation replays — 2026-10-15

Exact committed Truss123cd2ec/privateABI2wheel and edebb67f/standardCI0.4.33ABI2
cohorts each pass four native public workflows. Masked exact predicates and empty
populations work; legacy data facades/regrant paths refuse. Privileged external
definers, transitive column-granted views and unenrolled elevated roles refuse
activation; finalCIcohort also rejects external internal-routine attachments.
This closes exercised namespace-only paths under trusted activation/DDL
quiescence, not complete native writer/effect/lifecycle or managed deployment
qualification. Existing B04/B05/B06/B10/B11/B14/L12 procedures are expanded; all
30 Truss cases remain required. No case promoted:45/158 accepted,113 unimplemented.
See [separate exact source/wheel cohorts](../../04-build/evidence/security/truss-protected-query-replay-20261015/README.md).

### Published compiler artifact correspondence — 2026-10-15

Actual public Weft0.4.33ARM archive8ea8 differs from testedCIarchivedfe0, but all
five member payloads are byte-identical. Original Trussad794577 selects its
explicit published ABI2 manifest and refuses retained CI selection;467 tracked
source files and original UMF assets correspond. Official release API asset
digests/sizes match local public wheel and checksums. This is artifact/consumer
correspondence only: no database rerun, Linux/aggregate/native authority or
release-readiness promotion. Earlier CI native receipt remains immutable.
Acceptance45/158,113 unimplemented unchanged. See [exact evidence](../../04-build/evidence/security/published-weft-cohort-20261015/README.md).

## Native presence/provenance prerequisite controls — 2026-10-16

These exercising component controls map to US-056-AC6 and supplement, never replace, pg-raw.P03/B07/B08. Keep all original required cases and operator/actor/bypass expectations unchanged.

| Control | Exercising source | Required observation |
| --- | --- | --- |
| CP01 issued SQL and real driver data | `tools/security/pg18-current-presence-oracle.py` | Four actual issued bounded PostgreSQL programs match the Rust checker over complete captured fixture rows; actual NULL refuses even when FALSE/LIMIT0 hides results. |
| CP02 native presence | same | Explicit native column presence distinguishes null/absence; scalar-only current frame cannot express the distinction. JSONB key existence independently distinguishes missing key from explicit JSON null. Neither codec is automatically admitted. |
| CP03 disclosure provenance | same | Native original five declared outcomes retain column/revision, disposition, payload presence, selection, output domain and exact transform; original null and transformed null stay distinct. |
| CP04 negative controls | same | Wrong original document/revision, inconsistent payload flag, missing/unexpected transform and invalid public null/domain/transform metadata refuse. Plain nullable payload collapses four distinct outcomes. |
| CP05 closed producer | same | Derived optional Token source refuses the current required-only lineage producer before application SQL; no fallback or fabricated native permission. |
| CP06 algebra | `tools/security/prove-disclosure-carrier.py` | Conditional left/right inverse, injectivity and malformed-record refusal have UNSAT violations; all four variants have SAT inhabitants and erasure controls yield SAT counterexamples. |
| CP07 custody and cleanup | native source above | Pin actual engine/image, original fixture/packet/wheel/native module/shim and source bytes; retain failures; verify owned label, removal and subsequent absence. Never publish success when cleanup is unverified. |
| CP08 explicit policy-selected presence | `tools/security/query-presence-policy-oracle.ts` | On the explicit optional queryable model, a separate Token disclosure preserves String/null/absence under the original project-membership requirement; undisclosed, unreported, incomplete and stale states refuse, and inactive assignment, mismatched subject/project links and complete absent associations return no eligible rows. Supplied logical cuts never confer native authority. |

Use the pinned disposable PostgreSQL 18.6 image from the original P-cases and isolated explicit output paths. Excluded-admin execution tests a physical/codec boundary, not ordinary-principal authorization, native transformation execution or actual source/caller/current-cut admission. Preserve exact artifact/codec/fixture identities so supplied declared cells cannot be relabeled as actual policy decisions. Browser portability is unaffected: these tools remain outside the browser library.

### Canonical disclosure-selection provenance component — 2026-10-16

The private logical-disclosure-selection0.1 producer must preserve exact qualified resource identities, actual scoped rule truth, all winning source occurrences and the first selected transform occurrence in canonical policy order. Exercise both flat and graph witnesses, nonzero disclosure indices, duplicate contributors, conflicting transforms, withholding dominance without original-value projection, explicit unprotected fallback, missing protected directives, denied/empty populations, hostile/stale input and shared-budget exhaustion. Original action/render/rule-scan shapes must remain unchanged. Real Chromium must match Bun without host globals. Source-selection evidence never grants native authority, executes transforms or substitutes for original P03/B08 cases.


### Atomic canonical disclosure batch controls — 2026-10-16

`tests/security/catalog-disclosure-batch-corpus.ts` and
`catalog-disclosure-batch.test.ts` cite `@covers US-056-AC6` and
`@covers US-056-AC10`. Exercise actual canonical execution, then independently
inspect and JSON/YAML round-trip every successful0.2 batch: exact source/resource
correspondence; original/null/absence/withholding/transformed-null; all six pure
function classes and exact signed/decimal/date/Unicode values; nonzero and
duplicate source positions; differing transform conflict; inactive directives;
flat and graph witnesses; stored-token original/output identity; denied rows in
complete census but absent from released batch; empty and field-free populations;
unsupported inline refusal with old behavior preserved; later invalid output and
shared-budget exhaustion clearing every result field; stale/malformed sources
and hostile getters refusing without invocation. Test transport counts and
literal boundaries and prove produced metadata survives the original public
codec. Real Chromium must match Bun without host globals or external requests.
These component checks supplement original P03/B08 and do not promote a backend
case or prove native custody/operator/release behavior.

### Actual atomic producer presence handoff — 2026-10-16

Supplement AC6/AC10 component evidence with the actual private WithinOperation producer on the explicitly authored optional Resource source. Preserve the original salary-only policy as a negative; separate original Token, withheld Token and null-presentation policies retain distinct content revisions. Exercise String, original null, absence, withholding, actual pure transformed null and unreported presence under project-membership permit, inactive/foreign/missing relationship denial, incomplete coverage and stale generation. Assert exact census versus permitted resources/rows, stored Token carrier, public V2 inspection and both original codecs. Retain input/source snapshots, exact source UTF-8, actual batch JSON, full inspection verdict and refused atomic-cleared outputs for compiler/native transport composition.

These are supplied-cut producer controls, not authenticated native facts, physical compiler execution, query-operator permissions or guarded release. No existing required backend case changes status; native transport must independently preserve exact header, occurrences, resource correspondence and all five states before any admitted profile may use it.
